<?php

echo date("%2\F")

?>
