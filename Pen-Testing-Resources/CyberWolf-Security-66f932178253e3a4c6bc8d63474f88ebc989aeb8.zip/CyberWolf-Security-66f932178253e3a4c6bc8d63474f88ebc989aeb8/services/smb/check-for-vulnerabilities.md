# Check for vulnerabilities

`nmap --script smb-vuln* -p 139,445`
