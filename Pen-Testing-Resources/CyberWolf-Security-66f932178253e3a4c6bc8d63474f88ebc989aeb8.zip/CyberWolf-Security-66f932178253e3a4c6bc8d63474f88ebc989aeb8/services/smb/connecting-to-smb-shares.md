# Connecting to SMB Shares

### List SMB shares

```
smbclient -L [IP]
```

### Connect to smb share

```
smbclient \\\\[ip]\\[share name]
```

`rpcclient -U "" -N [ip]`

`enum4linux -a <ip>`

```
/usr/bin/winexe -U mad01/user123%abcABC1234 //172.18.2.50 ipconfig
```

