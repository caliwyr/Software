# Create an SMB Share

```
sudo impacket-smbserver share . -smb2support
```

