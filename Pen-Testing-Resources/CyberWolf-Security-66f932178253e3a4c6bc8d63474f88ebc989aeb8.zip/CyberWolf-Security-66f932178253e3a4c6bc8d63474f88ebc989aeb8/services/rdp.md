# RDP

### Tools to connect to RDP

```
xfreerdp /v:[IP] /u:administrator
```
