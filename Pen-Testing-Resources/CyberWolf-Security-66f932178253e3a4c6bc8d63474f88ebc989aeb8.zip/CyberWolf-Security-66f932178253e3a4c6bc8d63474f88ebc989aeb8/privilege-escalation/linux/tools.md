# Tools

### PEAS-ng

{% embed url="https://github.com/carlospolop/PEASS-ng" %}
