# Useful commands

### Check to see what sudo rights a user has access too

```
sudo -l
```
