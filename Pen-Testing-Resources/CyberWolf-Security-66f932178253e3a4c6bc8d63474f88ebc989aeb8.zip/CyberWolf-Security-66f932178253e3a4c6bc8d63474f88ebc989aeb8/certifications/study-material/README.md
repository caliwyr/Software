# Study Material

### Flash cards

{% embed url="https://www.chegg.com/flashcards/jo1-4bbd77cb-4050-4cb0-be85-ea9d01b52b66/deck" %}

{% embed url="https://quizlet.com/search?query=cpsa&type=sets" %}

{% embed url="https://quizlet.com/355066589/crest-cpsa-flash-cards" %}
