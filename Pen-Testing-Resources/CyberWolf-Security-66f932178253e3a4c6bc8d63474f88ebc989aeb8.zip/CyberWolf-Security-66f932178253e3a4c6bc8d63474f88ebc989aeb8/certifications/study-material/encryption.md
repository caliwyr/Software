# Encryption

### Diffie-Hellman

{% embed url="https://www.youtube.com/watch?index=2&list=PLfTqF38ausbOqRQBkFMFm9A-umOaSOzPe&v=NmM9HA2MQGI" %}
