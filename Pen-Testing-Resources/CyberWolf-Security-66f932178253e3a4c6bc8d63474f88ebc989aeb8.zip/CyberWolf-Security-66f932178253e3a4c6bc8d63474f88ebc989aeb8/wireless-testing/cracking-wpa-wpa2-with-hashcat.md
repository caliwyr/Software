# Cracking WPA/WPA2 with Hashcat

.\hashcat.exe -m 22000 .\wpa-to-crack .\rockyou.txt

