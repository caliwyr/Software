---
cover: .gitbook/assets/Cyber Wolf Youtube Channel Art-security (1).png
coverY: 0
---

# Home

This book book has been created as a place to store testing notes, descriptions and useful resources that I use on a regular bases, in the hopes it will be of some use to others also. \
\
Please note, that as these are 'notes' they may not be complete and in some cases out of date or even be the best way of doing something. Please take this book with a pinch of salt and if you wish to contribute to anything then please get in touch and I can add them here with credits to the author.
