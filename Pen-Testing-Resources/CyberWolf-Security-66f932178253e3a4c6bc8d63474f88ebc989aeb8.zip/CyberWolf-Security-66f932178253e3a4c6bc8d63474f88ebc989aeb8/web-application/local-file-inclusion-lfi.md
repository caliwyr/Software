# Local File Inclusion (LFI)

### LFI Fuzzing list

{% embed url="https://raw.githubusercontent.com/danielmiessler/SecLists/master/Fuzzing/LFI/LFI-Jhaddix.txt" %}

