# WPScan

```
wpscan --url http://backdoor.htb/ --api-token 9k7wzdqH7sgiV0k9glyPrFa26VqC7minprBzSsCaDsM --enumerate p,u --plugins-detection aggressive
```

