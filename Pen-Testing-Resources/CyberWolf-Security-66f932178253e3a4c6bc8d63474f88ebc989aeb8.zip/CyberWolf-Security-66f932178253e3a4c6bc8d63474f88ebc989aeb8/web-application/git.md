# GIT

Show a previous revision

```
git diff HEAD~2
```
