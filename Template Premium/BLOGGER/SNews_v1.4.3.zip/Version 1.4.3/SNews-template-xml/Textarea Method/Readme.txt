This version using textarea tag to reduce load time. 
but i don't know this method good for SEO. 
because i don't get any info about textarea make SEO down or not.
I just create it to reduce request image on main Recent Post area and make it available to use Summary Length too.