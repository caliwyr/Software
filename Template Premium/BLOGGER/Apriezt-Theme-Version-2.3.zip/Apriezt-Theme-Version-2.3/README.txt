Version 2.0 Have New Script Code
Please Read Documentation File to see How To Install it

Version 2.3
Added:
Recommended Post
Complex Widget by Labels Style
Spot.IM Comment
Font Awesome version 4.5
Jquary version 1.11.3

Fixed:
Schema.org Struckture
Improve Pagespeed

Version 2.2
Added:
- 4 New Widget Style (blogpost,halfpost,bigpost,simplepost)
- 3 New Adsense Area
- Widget by Label support Ajax Page Number
- option to disable/enable autoplay

Version 2.1
Added:
- 3 New Section Area
- Change Default Setting for Breakline, Excerpt, and Ads below the title
- Fixed Gallery Type

Version 2.0
Recode All Script
Added:
- Shortcode [youtube,dailymotion,maps,soundcloud,image,tab,accordion, etc..]
- Post Pagination
- Lock Content
- Featured Post Content
- Custom Title and Sub Title support in Post
- Ads below title
- Related Post Style (Carousel,Simple,and First Big)
- Social Counter
- 10+ Widget by Label Style
- and More..

Fixed:
- Post Schema.org Format
- Improve SEO


Version 1.2
Fixed/Change:
- Summary Script (Added youtube playicon)
- Recent Post by Tag Script (Added youtube playicon)
- Related Post Script (Added youtube playicon)
- Page navigation script (Added youtube playicon)
- Lightweight version (added unveil jQuery (Lazyload image))

Version 1.1:
Fixed/Change : 
- Summary Script
- Page navigation script
- Recent Post by Tag Script
- Related Post Script 
- Featured Post Script
- CSS bugs

Added:
- Support Mega Menu
- Lightweight version (inside lightweight folder)
- New meta tag (Support Facebook, Twitter, Google+)