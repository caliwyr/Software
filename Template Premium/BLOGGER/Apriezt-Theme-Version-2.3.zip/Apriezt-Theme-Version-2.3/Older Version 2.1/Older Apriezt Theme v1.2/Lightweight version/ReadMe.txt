Lightweight version is use different Slider script and remove some features.


- Slider use Owlcarousel



- Remove featured and Script:
  
  - Remove Featured Post (featuredpost1 and featuredpost2).
  
  - Remove custom scrollbar on Recent Post by Tag  
 
  - Remove Camera Slide Script and Auto resize Script



- Added features
  
  - Lazy load image (unveil jQuery) on Recent Post by Tag
  


- Manual Featured post same effect like Slider 2

