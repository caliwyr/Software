Name: Templar Themes
Author: Taufik Nurhidayat
Url: https://www.nurhidayat.web.id
Published: 15 August 2020
Documentations: https://www.nurhidayat.web.id/2020/08/pengaturan-dan-setting-template-blogger.html
Themes Url: https://templar-themes.blogspot.com

Baca dulu License sebelum memakai. Dilarang keras menghapus credit link.
Read the License before use it. Don't remove credit link.

Features:
    -Lazysizes
    -Bootstrap v5 with customization
    -Automatic TOC (can change custom id)
    -Widget Ver: 2
    -Layout Ver: 3
    -Blogger Template Version: v1.3.0
    -Adsense Ready
    -Fast load
    -Responsive
    -Related Articles
    -Seo Friendly (it is teory)
    -Pass Rich Search Results
    -Using SVG Icons
