/*
-----------------------------------------------
Blogger Template Style
Theme Name		: SEOFastBlogger Pro
Description		: Responsive, SEO, Fast and Optimize Blogger Templates
Version			: 1.0
Author			: Gian MR
Author URL     	: http://www.gianmr.com/
Theme URL      	: http://www.gianmr.com/2016/02/seofastblogger-responsive-blogger-template.html
Created Date   	: Januari 19, 2016
License        	: http://www.gianmr.com/p/terms-of-use.html#template-license
----------------------------------------------- */

Tutorial konfigurasi:
http://www.gianmr.com/p/cara-konfigurasi-template-seofastblogger.html

Link download:
http://www.gianmr.com/2016/02/seofastblogger-responsive-blogger-template.html

Semoga berkah template nya dan bermanfaat buat blog anda.

Salam Hangat...

Gian MR