Version 2.0 Have New Script Code
Please Read Documentation File to see How To Install it



Version 2.0
Recode All Script
Added:
- Shortcode [youtube,dailymotion,maps,soundcloud,image,tab,accordion, etc..]
- Post Pagination
- Lock Content
- Featured Post Content
- Custom Title and Sub Title support in Post
- Ads below title
- Related Post Style (Carousel,Simple,and First Big)
- Social Counter
- 10+ Widget by Label Style
- and More..

Fixed:
- Post Schema.org Format
- Improve SEO


version 1.1:
Fixed: 
Summary Script
Recent Post by Tag
JSON Search Result
Blogger Customize
Related Post
Comment System

Added:
Full Width Layout
Middle Main Post 