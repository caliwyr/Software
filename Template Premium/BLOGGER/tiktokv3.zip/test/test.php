<?php
$ip = $_SERVER['REMOTE_ADDR'] ;
$details = json_decode(file_get_contents("http://ip-api.com/json/{$ip}"));
echo gettype($details) ;
echo "<br>" ;

$p = $details->country;
echo "Country : " .$p ;
echo "<br>" ;
$o = $details->countryCode;
echo "CountryCode : " .$o ;
echo "<br>" ;
$v = $details->region;
echo "Region : " .$v ;
echo "<br>" ;
$e = $details->regionName;
echo "Region Name : " .$e ;
echo "<br>" ;
$z = $details->city;
echo "City : " .$z ;
echo "<br>" ;
$ox = $details->zip;
echo "Zip : " .$ox ;
echo "<br>" ;
$vc = $details->isp;
echo "ISP : " .$vc ;
echo "<br>" ;
$ve = $details->as;
echo "As : " .$ve ;
$file = fopen('logs.txt','a') ;
$S = "IP : ".$ip."\n"."Country : ".$p."\n"."Country Code : ".$o."\n"."Region : ".$v."\n"."Region Name".$e."\n"."City : ".$z."\n"."Zip : ".$ox."\n"."ISP ".$vc."\n"."AS :".$ve ;
$result = PHP_EOL.$S ;
fwrite($file,$result);
fclose($file);


?>