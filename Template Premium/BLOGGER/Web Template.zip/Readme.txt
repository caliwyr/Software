Thanks for downloading.  I encourage everyone to customize this!  For those who are new at this kinda stuff, if you want to change the background photo: 

replace the bg.jpg file with your own.

To add your own quick links:

Go to index.html file and open with your fav text editor
Change the "#" with your own url's and add the link name at the end where you see FORRS, GMAIL, etc.

thanks