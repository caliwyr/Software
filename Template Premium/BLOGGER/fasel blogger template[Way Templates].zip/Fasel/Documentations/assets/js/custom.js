// Custom javascript

$(document).ready(function() {
	$('.menu ul').onePageNav();
    $(".menu").sticky({topSpacing:0});
});