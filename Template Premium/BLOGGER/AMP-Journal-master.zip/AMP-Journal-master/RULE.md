# RULES

## Do Not

- Do Not Remove Attribute Information
- Do Not Sell, Because It's Free

## Do

- Modify Without Remove Attribute Information