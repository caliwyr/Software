# ⚡ AMP Journal
Template AMP ⚡ For Blogger

![valid-amp](valid-amp.png)

## Feature
- ⚡ Fast
- ✅ Valid Amp
- 🌓 Dark / Light Mode
- 💬 Default Comment Blogger
- 🔎 SEO
- ⭐ Rich Attribute
## DEMO
[CLICK HERE](https://useamp.blogspot.com)
## Built With
- CSS Spectre For AMP > https://github.com/niutech/amp-spectre
## License
This project is licensed under the [MIT](LICENSE) License and My [RULE](RULE.md)