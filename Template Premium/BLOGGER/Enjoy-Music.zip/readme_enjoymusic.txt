
================================================
=== Enjoy Music MP3 Script & Youtube Grabber ===
================================================

Upload the script into root directory.
Until this step, the script already to use. 

================================================

DEMO : https://enjoymusic.dlyt.xyz

================================================

Config : configure.php

================================================

ADS Setting : 
insert your ad script into ADS folder
------------------------------------------------
728.php			: Top Page
728b.php			: Bottom Page
300.php			: Download Page
popup.php			: Popup

===============================================

Inject keyword & Auto Sitemap : map.txt
*keyword contents per line
*for words separated by a minus sign (-)

===============================================

Eror? Custom : .htaccess / robots.txt

===============================================
