<?php
$key = ""; // no need youtube api key
$site_name = "ENJOY MUSIC"; // site name
$home_title = "ENJOY MUSIC - Download and Streaming Music MP3 Video"; // home page title
$home_des = "Music and Videos Download Support multipal formats "; // home page description
$pop_des = "iTunes Pop - Download and Streaming Music MP3 Video "; // genre pop page description
$blues_des = "iTunes Blues - Download and Streaming Music MP3 Video "; // genre blues page description
$rock_des = "iTunes Rock - Download and Streaming Music MP3 Video "; // genre Rock page description
$reggae_des = "iTunes Reggae - Download and Streaming Music MP3 Video "; // genre reggae page description
$hiphop_des = "iTunes Hip-Hop - Download and Streaming Music MP3 Video "; // genre Hip-Hop page description
$keywords = "Youtube, Videos, Downloader, Support, multipal, formats "; // home page keywords 
$search_before = "Download";// keword beafore search tearm
$search_after = "Enjoy Music & Video Song"; // keword after search tearm
$home_trand = "us";  // country
$genre_trand = "genre=34";   //all Music  = https://itunes.apple.com/us/genre/music/id34
$fake_download = "#";  //fake download link
$email_contact = "matanedev@gmail.com"; //email Contact
?>
