<?php

/**
 * Template Name: User notification
 *
 * @package Kiranime
 */

$queried = new WP_Query([
    'post_type' => 'notification',
    'post_status' => 'publish',
    'author' => get_current_user_id(),
]);

get_header('single');?>
<?php get_template_part('template-parts/component', 'user-heading')?>
<div class="lg:w-9/12 w-full mx-auto">
    <h2 class="text-2xl px-5 lg:px-0 leading-10 font-medium mb-5 flex items-center gap-4">
        <svg class="w-7 h-7" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
            <path fill="currentColor"
                d="M224 512c35.32 0 63.97-28.65 63.97-64H160.03c0 35.35 28.65 64 63.97 64zm215.39-149.71c-19.32-20.76-55.47-51.99-55.47-154.29 0-77.7-54.48-139.9-127.94-155.16V32c0-17.67-14.32-32-31.98-32s-31.98 14.33-31.98 32v20.84C118.56 68.1 64.08 130.3 64.08 208c0 102.3-36.15 133.53-55.47 154.29-6 6.45-8.66 14.16-8.61 21.71.11 16.4 12.98 32 32.1 32h383.8c19.12 0 32-15.6 32.1-32 .05-7.55-2.61-15.27-8.61-21.71z" />
        </svg>
        Notification
    </h2>
    <div id="notification" class="my-5">
        <?php while ($queried->have_posts()): $queried->the_post();?>
        <?php $meta = get_post_meta(get_the_ID(), 'notification_update', true);?>
        <?php $meta = $meta ? (array) json_decode($meta) : [];?>
        <?php
    $results = kiranime_get_anime_data_for_notification($meta);
    ?>
        <div>
            <?php foreach ($results as $notif): ?>
            <div class="relative pl-32 w-full p-5 bg-overlay mb-2 bg-opacity-75 group">
                <div
                    class="bg-darker bg-opacity-20 absolute inset-0 group-hover:bg-opacity-0 group-hover:pointer-events-none z-10">

                </div>
                <a href="<?php echo $notif['url'] ?>" class="w-28 absolute inset-y-0 left-0 overflow-hidden">
                    <img src="<?php echo get_the_post_thumbnail_url($notif['anime_id'], 'trending-image') ?>"
                        class="absolute inset-0 " alt="<?php echo $notif['title'] ?>">
                </a>
                <div class="text-xs mb-1"><?php echo $notif['published'] ?></div>
                <div class="mb-5 font-medium text-xl leading-normal">
                    <a href="<?php echo $notif['url'] ?>"><span
                            class="text-sky-400"><?php echo $notif['title'] ?></span> -
                        Episode <?php echo $notif['number'] ?> Available NOW!</a>
                </div>
                <div class="text-sm">Click <a href="<?php echo $notif['url'] ?>">here</a> to watch it now.
                </div>
            </div>
            <?php endforeach;?>
        </div>
        <?php endwhile;?>
    </div>
</div>

<?php get_footer();?>