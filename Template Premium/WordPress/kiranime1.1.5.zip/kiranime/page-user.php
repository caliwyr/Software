<?php

/**
 * Template Name: User
 *
 * @package Kiranime
 */

wp_redirect('/user/profile');