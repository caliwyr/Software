<?php get_header();
$homepage_nonce = wp_create_nonce('kiranime_homepage_nonce');
?>
<script>
const homepageNonce = "<?php echo $homepage_nonce; ?>";
</script>
<!-- Spotlight start -->
<div class="w-full sm:mt-17 sm:mb-5 lg:h-500 bg-sky-500 bg-opacity-0 flex items-center relative justify-center">
    <div class="swiper swiper-spotlight">
        <!-- Additional required wrapper -->
        <div class="swiper-wrapper">
            <!-- Slides -->
            <?php get_template_part('template-parts/component', 'spotlight')?>
        </div>
        <!-- If we need pagination -->
        <div class="swiper-pagination"></div>
    </div>
    <div class="swiper-navigation absolute bottom-5 right-5 z-10 hidden sm:block">
        <div class="mb-2 bg-primary rounded-sm shadow-sm p-2 nav-next hover:bg-sky-600" tabindex="0" role="button"
            aria-label="Next slide">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 192 512" class="w-6 h-6">
                <path fill="currentColor"
                    d="M187.8 264.5L41 412.5c-4.7 4.7-12.3 4.7-17 0L4.2 392.7c-4.7-4.7-4.7-12.3 0-17L122.7 256 4.2 136.3c-4.7-4.7-4.7-12.3 0-17L24 99.5c4.7-4.7 12.3-4.7 17 0l146.8 148c4.7 4.7 4.7 12.3 0 17z" />
            </svg>
        </div>
        <div class="bg-primary rounded-sm shadow-sm p-2 nav-prev hover:bg-sky-600" tabindex="0" role="button"
            aria-label="Previous slide">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 192 512" class="w-6 h-6">
                <path fill="currentColor"
                    d="M4.2 247.5L151 99.5c4.7-4.7 12.3-4.7 17 0l19.8 19.8c4.7 4.7 4.7 12.3 0 17L69.3 256l118.5 119.7c4.7 4.7 4.7 12.3 0 17L168 412.5c-4.7 4.7-12.3 4.7-17 0L4.2 264.5c-4.7-4.7-4.7-12.3 0-17z" />
            </svg>
        </div>
    </div>
</div>
<!-- Spotlight End -->

<!-- Trending start -->
<div class="p-4 text-xl lg:text-xl leading-4 lg:leading-10 lg:mt-5 font-semibold text-sky-500">
    Trending
</div>
<div class="sm:px-4 px-0 mt-2 md:flex justify-between w-full pb-10"
    style="background: linear-gradient(0deg,#121315 0,rgba(18,19,21,0) 99%);">
    <div class="swiper swiper-trending">
        <div class="swiper-wrapper">
            <!-- Slides -->
            <?php get_template_part('template-parts/component', 'trending')?>
        </div>
        <div class="swiper-pagination"></div>
    </div>
    <div class="swiper-navigation ml-5 md:grid hidden">
        <div class="mb-2 bg-gray-700 rounded-sm shadow-sm p-2 trending-nav-next hover:bg-sky-600 flex items-center justify-center"
            tabindex="0" role="button" aria-label="Next slide">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 192 512" class="w-6 h-6">
                <path fill="currentColor"
                    d="M187.8 264.5L41 412.5c-4.7 4.7-12.3 4.7-17 0L4.2 392.7c-4.7-4.7-4.7-12.3 0-17L122.7 256 4.2 136.3c-4.7-4.7-4.7-12.3 0-17L24 99.5c4.7-4.7 12.3-4.7 17 0l146.8 148c4.7 4.7 4.7 12.3 0 17z" />
            </svg>
        </div>
        <div class="bg-gray-700 rounded-sm shadow-sm p-2 trending-nav-prev hover:bg-sky-600 flex items-center justify-center"
            tabindex="0" role="button" aria-label="Previous slide">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 192 512" class="w-6 h-6">
                <path fill="currentColor"
                    d="M4.2 247.5L151 99.5c4.7-4.7 12.3-4.7 17 0l19.8 19.8c4.7 4.7 4.7 12.3 0 17L69.3 256l118.5 119.7c4.7 4.7 4.7 12.3 0 17L168 412.5c-4.7 4.7-12.3 4.7-17 0L4.2 264.5c-4.7-4.7-4.7-12.3 0-17z" />
            </svg>
        </div>
    </div>
</div>
<!-- Trending End -->
<div class="inline-block mb-5 bg-darkest w-full ">
    <div class="px-4">
        <div class="py-5 px-0 relative flex items-center gap-5">
            <div class="block text-xs pl-0 lg:pl-5 py-1 relative lg:border-l-2 border-sky-400">
                <span class="text-sm font-semibold text-sky-400">Share <?php echo get_bloginfo('name'); ?></span>
                <p class="mb-0">to your friends</p>
            </div>
            <?php $code = get_option('__o_share');if ($code) {echo do_shortcode($code);}
;?>
        </div>
    </div>
</div>
<!-- Start Ads 1 -->
<?php if (get_option('__b_after_trending')) {?>
<div class="container flex items-center justify-center max-w-full h-auto my-5">
    <?php echo get_option('__b_after_trending') ?>
</div>
<?php }?>
<!-- End Ads -->

<!-- Start Featured -->
<section role="grid"
    class="sm:px-4 lg:px-5 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-y-5 w-full px-5 gap-x-7 my-2 sm:my-5 lg:my-10">
    <?php
$top_airing = kiranime_get_anime_featured();
$popular_airing = kiranime_get_anime_featured('popular');
$favorite = kiranime_get_anime_featured('favorite');
?>

    <div class="min-h-300 w-full bg-secondary rounded-sm shadow drop-shadow z-0 hover:z-40">
        <div class="p-4 text-base leading-4 font-medium text-sky-500">
            Top Airing
        </div>
        <div>
            <ul class="m-0 p-0">
                <?php if ($top_airing->have_posts()): while ($top_airing->have_posts()): $top_airing->the_post();?>
                <?php get_template_part('template-parts/component', 'featured');?>
                <?php endwhile;endif;?>
            </ul>
        </div>
        <div class="w-full">
            <a class=" p-4 text-white text-opacity-90 bg-opacity-10 bg-white hover:bg-opacity-30 font-light flex items-center justify-center gap-2 "
                href="/top-airing">
                View more
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512" class="w-5 h-5">
                    <path fill="currentColor"
                        d="M224.3 273l-136 136c-9.4 9.4-24.6 9.4-33.9 0l-22.6-22.6c-9.4-9.4-9.4-24.6 0-33.9l96.4-96.4-96.4-96.4c-9.4-9.4-9.4-24.6 0-33.9L54.3 103c9.4-9.4 24.6-9.4 33.9 0l136 136c9.5 9.4 9.5 24.6.1 34z" />
                </svg>
            </a>
        </div>
    </div>
    <div class="min-h-300 w-full bg-secondary rounded-sm shadow drop-shadow z-0 hover:z-40">
        <div class="p-4 text-base leading-4 font-medium text-sky-500">
            Most Popular
        </div>
        <div>
            <ul class="m-0 p-0">
                <?php if ($popular_airing->have_posts()): while ($popular_airing->have_posts()): $popular_airing->the_post();?>
                <?php get_template_part('template-parts/component', 'featured');?>
                <?php endwhile;endif;?>
            </ul>
        </div>
        <div class="w-full">
            <a class=" p-4 text-white text-opacity-90 bg-opacity-10 bg-white hover:bg-opacity-30 font-light flex items-center justify-center gap-2 "
                href="/most-popular">
                View more
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512" class="w-5 h-5">
                    <path fill="currentColor"
                        d="M224.3 273l-136 136c-9.4 9.4-24.6 9.4-33.9 0l-22.6-22.6c-9.4-9.4-9.4-24.6 0-33.9l96.4-96.4-96.4-96.4c-9.4-9.4-9.4-24.6 0-33.9L54.3 103c9.4-9.4 24.6-9.4 33.9 0l136 136c9.5 9.4 9.5 24.6.1 34z" />
                </svg>
            </a>
        </div>
    </div>
    <div class="min-h-300 w-full bg-secondary rounded-sm shadow drop-shadow z-0 hover:z-40">
        <div class="p-4 text-base leading-4 font-medium text-sky-500">
            Most Favorite
        </div>
        <div>
            <ul class="m-0 p-0">
                <?php if ($favorite->have_posts()): while ($favorite->have_posts()): $favorite->the_post();?>
                <?php get_template_part('template-parts/component', 'featured');?>
                <?php endwhile;endif;?>
            </ul>
        </div>
        <div class="w-full">
            <a class=" p-4 text-white text-opacity-90 bg-opacity-10 bg-white hover:bg-opacity-30 font-light flex items-center justify-center gap-2 "
                href="/favorite">
                View more
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512" class="w-5 h-5">
                    <path fill="currentColor"
                        d="M224.3 273l-136 136c-9.4 9.4-24.6 9.4-33.9 0l-22.6-22.6c-9.4-9.4-9.4-24.6 0-33.9l96.4-96.4-96.4-96.4c-9.4-9.4-9.4-24.6 0-33.9L54.3 103c9.4-9.4 24.6-9.4 33.9 0l136 136c9.5 9.4 9.5 24.6.1 34z" />
                </svg>
            </a>
        </div>
    </div>
    <?php get_template_part('template-parts/component', 'featured-news')?>
</section>
<?php $afe = get_option('__b_after_featured') ? get_option('__b_after_featured') : false;if ($afe): ?>
<div class="container flex items-center justify-center max-w-full h-auto my-5">
    <?php echo $afe ?>
</div>
<?php endif;?>
<!-- End Featured -->
<div class="lg:flex justify-between md:px-5 gap-5 sm:px-4">
    <section class="lg:w-9/12 w-full">
        <div class="w-full mb-4 flex items-center justify-between px-4 sm:px-0">
            <div class="mr-4">
                <h2 class="text-2xl leading-10 font-semibold p-0 m-0 text-sky-400">Latest Episode</h2>
            </div>
            <div class="text-sm font-normal text-opacity-75">
                <a class="flex items-center gap-2" href="/latest-update">
                    View more
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512" class="w-5 h-5 inline-block">
                        <path fill="currentColor"
                            d="M224.3 273l-136 136c-9.4 9.4-24.6 9.4-33.9 0l-22.6-22.6c-9.4-9.4-9.4-24.6 0-33.9l96.4-96.4-96.4-96.4c-9.4-9.4-9.4-24.6 0-33.9L54.3 103c9.4-9.4 24.6-9.4 33.9 0l136 136c9.5 9.4 9.5 24.6.1 34z" />
                    </svg>
                </a>
            </div>
        </div>
        <!-- Start Latest id="latest-anime" -->
        <div
            class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 xl:grid-cols-6 gap-2 sm:gap-4 lg:gap-5 justify-evenly w-full flex-auto">
            <?php
$per_page = get_option('__c_latest') ? get_option('__c_latest') : 12;
$latest = new WP_Query([
    'post_type' => 'anime',
    'post_status' => 'publish',
    'order' => 'DESC',
    'orderby' => 'meta_value_num',
    'meta_key' => 'kiranime_anime_updated',
    'posts_per_page' => $per_page,
    'no_found_rows' => true,
    'tax_query' => [
        [
            'taxonomy' => 'status',
            'field' => 'slug',
            'terms' => ['airing', 'completed'],
        ],
    ],
]);

if ($latest->have_posts()): while ($latest->have_posts()): $latest->the_post();
        ?>
            <?php get_template_part('template-parts/component', 'grid-display')?>
            <?php endwhile;endif;?>
        </div>
        <!-- End Latest -->
        <!-- Start Newly Added Anime -->

        <div class="w-full mb-4 flex items-center justify-between mt-10 px-4 sm:px-0">
            <div class="mr-4">
                <h2 class="text-2xl leading-10 font-semibold p-0 m-0 text-sky-400">Newly Added</h2>
            </div>
            <div class="text-sm font-normal text-opacity-75">
                <a class="flex items-center gap-2" href="/recently-added">
                    View more
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512" class="w-5 h-5 inline-block">
                        <path fill="currentColor"
                            d="M224.3 273l-136 136c-9.4 9.4-24.6 9.4-33.9 0l-22.6-22.6c-9.4-9.4-9.4-24.6 0-33.9l96.4-96.4-96.4-96.4c-9.4-9.4-9.4-24.6 0-33.9L54.3 103c9.4-9.4 24.6-9.4 33.9 0l136 136c9.5 9.4 9.5 24.6.1 34z" />
                    </svg>
                </a>
            </div>
        </div>
        <!--  id="new-anime" -->
        <div role="main"
            class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 xl:grid-cols-6 gap-2 sm:gap-4 lg:gap-5 justify-evenly w-full flex-auto">
            <?php
$per_page = get_option('__c_new_anime') ? get_option('__c_new_anime') : 16;
$new_animes = new WP_Query([
    'post_type' => 'anime',
    'post_status' => 'publish',
    'order' => 'DESC',
    'posts_per_page' => $per_page,
    'tax_query' => [
        [
            'taxonomy' => 'status',
            'field' => 'slug',
            'terms' => ['airing', 'completed'],
        ],
    ],
]);if ($new_animes->have_posts()): while ($new_animes->have_posts()): $new_animes->the_post();
        ?>
            <?php get_template_part('template-parts/component', 'grid-display')?>
            <?php endwhile;endif;?>
        </div>
        <!-- End Newly Added Anime -->
        <!-- Scheduled Anime Start -->
        <div class="w-full mb-4 flex items-center justify-between mt-10 px-4 sm:px-0">
            <div class="mr-4">
                <h2 class="text-2xl leading-10 font-semibold p-0 m-0 text-sky-400">Scheduled Anime</h2>
            </div>
        </div>
        <div id="scheduled-anime" class="bg-overlay rounded-sm shadow drop-shadow-sm"></div>
        <!-- Scheduled Anime End -->
        <!-- Upcomming Anime Start  id="upcomming-anime" -->
        <div class="w-full mb-4 flex items-center justify-between mt-10 px-4 sm:px-0">
            <div class="mr-4">
                <h2 class="text-2xl leading-10 font-semibold p-0 m-0 text-sky-400">Upcomming Anime</h2>
            </div>
            <div class="text-sm font-normal text-opacity-75">
                <a class="flex items-center gap-2" href="/upcomming-anime">
                    View more
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512" class="w-5 h-5 inline-block">
                        <path fill="currentColor"
                            d="M224.3 273l-136 136c-9.4 9.4-24.6 9.4-33.9 0l-22.6-22.6c-9.4-9.4-9.4-24.6 0-33.9l96.4-96.4-96.4-96.4c-9.4-9.4-9.4-24.6 0-33.9L54.3 103c9.4-9.4 24.6-9.4 33.9 0l136 136c9.5 9.4 9.5 24.6.1 34z" />
                    </svg>
                </a>
            </div>
        </div>
        <div
            class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 xl:grid-cols-6 gap-2 sm:gap-4 lg:gap-5 justify-evenly w-full flex-auto">
            <?php
$per_page = get_option('__c_upcomming') ? get_option('__c_upcomming') : 16;
$upcomming = new WP_Query([
    'post_type' => 'anime',
    'post_status' => 'publish',
    'order' => 'DESC',
    'orderby' => 'date',
    'posts_per_page' => $per_page,
    'tax_query' => [
        [
            'taxonomy' => 'status',
            'field' => 'slug',
            'terms' => 'upcomming',
        ],
    ],
]);if ($upcomming->have_posts()): while ($upcomming->have_posts()): $upcomming->the_post();
        ?>
            <?php get_template_part('template-parts/component', 'grid-display')?>
            <?php endwhile;endif;?>
        </div>
    </section>
    <aside class="w-full lg:w-3/12 flex-shrink-0 min-h-300 pr-5">
        <?php if (is_active_sidebar('homepage-sidebar')): dynamic_sidebar('homepage-sidebar');endif;?>
    </aside>
</div>

<?php
get_footer();