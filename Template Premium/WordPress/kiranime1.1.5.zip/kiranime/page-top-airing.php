<?php

/**
 * Template Name: Top airing anime archive
 *
 * @package Kiranime
 */

get_header('single');
$page = (get_query_var('paged')) ? get_query_var('paged') : 1;
$per_page = 24;
$posts = new WP_Query([
    'post_type' => 'anime',
    'post_status' => 'publish',
    'order' => 'DESC',
    'posts_per_page' => $per_page,
    'orderby' => 'meta_value_num',
    'meta_key' => date('mY') . '_kiranime_views',
    'tax_query' => [
        [
            'taxonomy' => 'status',
            'field' => 'slug',
            'terms' => ['airing'],
        ],
    ],
]);?>
<div class="mt-17 inline-block mb-5 bg-darkest w-full">
    <div class="px-4">
        <div class="py-5 px-0 relative flex items-center gap-5">
            <div class="block text-xs pl-5 py-1 relative border-l-2 border-sky-400">
                <span class="text-sm font-semibold text-sky-400">Share <?php echo get_bloginfo('name'); ?></span>
                <p class="mb-0">to your friends</p>
            </div>
            <?php $code = get_option('__o_share');if ($code) {echo do_shortcode($code);}
;?>
        </div>
    </div>
</div>
<div class="mb-17 grid grid-cols-12 px-5 mx-auto w-full gap-5">
    <section class="col-span-full lg:col-span-9">
        <h3 class="mb-4 text-2xl font-semibold leading-10 text-sky-400">Top Airing Anime</h3>
        <div class="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-6 gap-5">
            <?php if ($posts->have_posts()): while ($posts->have_posts()): $posts->the_post();
        ?>
            <div class="col-span-1">
                <?php get_template_part('template-parts/component', 'archive')?>
            </div>
            <?php endwhile;endif;?>
        </div>
        <?php
echo paginate_links(array(
    'base' => str_replace(999999999, '%#%', esc_url(get_pagenum_link(999999999))),
    'total' => $posts->max_num_pages,
    'current' => max(1, get_query_var('paged')),
    'format' => '?paged=%#%',
    'show_all' => false,
    'type' => 'list',
    'end_size' => 2,
    'mid_size' => 1,
    'prev_next' => false,
    'add_args' => false,
    'add_fragment' => '',
));
?>
    </section>
    <aside class="col-span-full lg:col-span-3 ">
        <?php if (is_active_sidebar('archive-sidebar')): dynamic_sidebar('archive-sidebar');endif;?>
    </aside>
</div>

<?php get_footer()?>