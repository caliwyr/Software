<div
    class="relative z-50 h-auto p-8 py-10 overflow-hidden bg-primary border-b-2 border-secondary rounded-lg shadow-2xl px-7">
    <input type="hidden" name="register_nonce" value="<?php echo wp_create_nonce('ajax-register-nonce') ?>">
    <h3 class="mb-6 text-2xl font-medium text-center">Register New Account</h3>
    <input type="text" name="register_username"
        class="block w-full px-4 py-3 mb-4 border  border-transparent border-secondary rounded-lg focus:ring focus:ring-sky-500 focus:outline-none text-primary"
        placeholder="Username">
    <input type="email" name="register_email"
        class="block w-full px-4 py-3 mb-4 border  border-transparent border-secondary rounded-lg focus:ring focus:ring-sky-500 focus:outline-none text-primary"
        placeholder="Email">
    <input type="password" name="register_password" autocomplete="off"
        class="block w-full px-4 py-3 mb-4 border  border-transparent border-secondary rounded-lg focus:ring focus:ring-sky-500 focus:outline-none text-primary"
        placeholder="Password">
    <input type="password" name="register_confirm_password" autocomplete="off"
        class="block w-full px-4 py-3 mb-4 border  border-transparent border-secondary rounded-lg focus:ring focus:ring-sky-500 focus:outline-none text-primary"
        placeholder="Confirm Password">
    <div class="block">
        <button data-register-button class="w-full px-3 py-4 font-medium text-white bg-sky-600 rounded-lg">
            Sign up
        </button>
    </div>
    <p data-register-error-info class="w-full mt-4 text-sm text-center text-rose-500"></p>
    <p class="w-full mt-4 text-sm text-center text-gray-400">Already have an account? <button data-to-login-button
            class="text-sky-500 underline">Log in here</button></p>
</div>