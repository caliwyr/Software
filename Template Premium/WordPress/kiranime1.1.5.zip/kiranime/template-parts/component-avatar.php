<?php

$avatars = kiranime_get_avatar_list();
$chibi = $avatars['chibi'];
$dragonball = $avatars['dragonball'];
$onepiece = $avatars['onepiece'];
$current = kiranime_get_user_avatar(get_current_user_id());

?>

<div class="w-full h-full">
    <div class="flex items-center justify-around text-sm font-light">
        <span data-selectable-type-id="1" onclick="changeSelectableType(1)"
            class="selected-avatar-type py-2 px-4">#DragonBall</span>
        <span data-selectable-type-id="2" onclick="changeSelectableType(2)" class="avatar py-2 px-4">#Chibi</span>
        <span data-selectable-type-id="3" onclick="changeSelectableType(3)" class="avatar py-2 px-4">#One Piece</span>
    </div>
    <div data-selected-id="1"
        class="mt-5 grid-cols-3 justify-around active-avatar-display max-h-56 overflow-y-scroll gap-5">
        <?php foreach ($dragonball as $c): ?>
        <img onclick="setMyAvatar('<?php echo $c; ?>')" data-avatar-url="<?php echo $c ?>" src="<?php echo $c ?>"
            class="cursor-pointer w-24 h-24 hover:scale-100 mx-auto col-span-1 rounded-full hover:shadow-lg relative after:absolute after:inset-0 after:bg-overlay after:bg-opacity-25 hover:after:bg-opacity-0 <?php if ($c == $current) {echo 'selected-avatar';} else {echo 'avatar-image';}?>">
        <?php endforeach;?>
    </div>
    <div data-selected-id="2" class="mt-5 grid-cols-3 justify-around avatar-display max-h-56 overflow-y-scroll gap-5">
        <?php foreach ($chibi as $c): ?>
        <img onclick="setMyAvatar('<?php echo $c; ?>')" data-avatar-url="<?php echo $c ?>" src="<?php echo $c ?>"
            class="cursor-pointer w-24 h-24 hover:scale-100 mx-auto col-span-1 rounded-full hover:shadow-lg relative after:absolute after:inset-0 after:bg-overlay after:bg-opacity-25 hover:after:bg-opacity-0 <?php if ($c == $current) {echo 'selected-avatar';} else {echo 'avatar-image';}?>">
        <?php endforeach;?>
    </div>

    <div data-selected-id="3" class="mt-5 grid-cols-3 justify-around avatar-display max-h-56 overflow-y-scroll gap-5">
        <?php foreach ($onepiece as $c): ?>
        <img onclick="setMyAvatar('<?php echo $c; ?>')" data-avatar-url="<?php echo $c ?>" src="<?php echo $c ?>"
            class="cursor-pointer w-24 h-24 hover:scale-100 mx-auto col-span-1 rounded-full hover:shadow-lg relative after:absolute after:inset-0 after:bg-overlay after:bg-opacity-25 hover:after:bg-opacity-0 <?php if ($c == $current) {echo 'selected-avatar';} else {echo 'avatar-image';}?>">
        <?php endforeach;?>
    </div>
</div>
<script>
let currentImg = "<?php echo $current; ?>";
const tabs = document.querySelectorAll('[data-selectable-type-id]');
const contents = document.querySelectorAll('[data-selected-id]');
const element = document.querySelector('[data-avatar-select-wrapper]');
const closer = document.querySelector('[data-close-avatar-select]');
const trigger = document.querySelector('[data-change-avatar]');

if (element) {
    closer.addEventListener('click', () => {
        element.classList.add('hidden');
    })
}
trigger.addEventListener('click', () => {
    element.classList.remove('hidden');
    element.classList.add('flex')
})
const changeSelectableType = (index) => {
    tabs.forEach(e => {
        e.classList.remove('selected-avatar-type');
        e.classList.add('avatar');
    });
    contents.forEach(e => {
        e.classList.remove('active-avatar-display');
        e.classList.add('avatar-display');
    })

    document.querySelector(`[data-selectable-type-id="${index}"]`).classList.add('selected-avatar-type')
    document.querySelector(`[data-selectable-type-id="${index}"]`).classList.remove('avatar')
    document.querySelector(`[data-selected-id="${index}"]`).classList.toggle('active-avatar-display')
}

const setMyAvatar = (avatar) => {
    const body = new FormData();
    body.append('action', 'kiranime_change_avatar');
    body.append('avatar', avatar);

    fetch(ajaxUrl, {
        body,
        method: 'POST'
    }).then(e => e.json()).then(e => {
        document.querySelector('[data-current-avatar]').setAttribute('src', avatar);
        document.querySelector(`[data-avatar-url="${avatar}"]`).classList.add('selected-avatar');
        document.querySelector(`[data-avatar-url="${avatar}"]`).classList.remove('avatar-image');
        document.querySelector(`[data-avatar-url="${currentImg}"]`).classList.remove('selected-image');
        document.querySelector(`[data-avatar-url="${currentImg}"]`).classList.add('avatar-image');

        currentImg = avatar;
    })
}
</script>