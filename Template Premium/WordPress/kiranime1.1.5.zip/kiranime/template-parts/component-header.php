<?php
$uid = get_current_user_id();
$uif = get_userdata($uid);?>
<div class="pl-4 sm:px-5 md:px-4 relative w-full flex items-center justify-between h-full">
    <div class="relative w-full flex items-center h-full">
        <div data-sidebar-trigger class="cursor-pointer">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" class="w-6 h-6">
                <path fill="currentColor"
                    d="M16 132h416c8.837 0 16-7.163 16-16V76c0-8.837-7.163-16-16-16H16C7.163 60 0 67.163 0 76v40c0 8.837 7.163 16 16 16zm0 160h416c8.837 0 16-7.163 16-16v-40c0-8.837-7.163-16-16-16H16c-8.837 0-16 7.163-16 16v40c0 8.837 7.163 16 16 16zm0 160h416c8.837 0 16-7.163 16-16v-40c0-8.837-7.163-16-16-16H16c-8.837 0-16 7.163-16 16v40c0 8.837 7.163 16 16 16z" />
            </svg>
        </div>
        <a href="/" id="logo" class="md:ml-16 ml-8 mr-8 block">
            <?php if (get_theme_mod('custom_logo')) {?>
            <img src="<?php $image = wp_get_attachment_image_src(get_theme_mod('custom_logo'));
    echo $image['0']?>" alt="<?php echo get_bloginfo('name') ?>">
            <?php } else {
    echo get_bloginfo('name');
}?>
        </a>
        <div id="search" class="hidden lg:block">
            <div class="search-content relative">
                <form action="/search" method="GET" autocomplete="off" class="relative">
                    <a href="/filter"
                        class="absolute top-2 right-2 text-xs bg-primary bg-opacity-80 px-2 py-1 rounded-sm">Filter</a>

                    <input type="text" data-search-ajax-input
                        class="bg-white rounded-none shadow-sm text-gray-800 font-normal h-10 leading-normal m-0 overflow-visible py-2 pr-20 pl-4 transition-all duration-150 ease-in-out focus:shadow w-full focus:outline-none"
                        name="keyword" placeholder="Search anime...">
                    <button type="submit" class="absolute top-2 right-14 px-2 py-1 w-max text-primary">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" class="w-4 h-4">
                            <path fill="currentColor"
                                d="M505 442.7L405.3 343c-4.5-4.5-10.6-7-17-7H372c27.6-35.3 44-79.7 44-128C416 93.1 322.9 0 208 0S0 93.1 0 208s93.1 208 208 208c48.3 0 92.7-16.4 128-44v16.3c0 6.4 2.5 12.5 7 17l99.7 99.7c9.4 9.4 24.6 9.4 33.9 0l28.3-28.3c9.4-9.4 9.4-24.6.1-34zM208 336c-70.7 0-128-57.2-128-128 0-70.7 57.2-128 128-128 70.7 0 128 57.2 128 128 0 70.7-57.2 128-128 128z" />
                        </svg>
                    </button>
                </form>
                <div class="bg-tertiary shadow-lg absolute top-10 inset-x-0 z-10 list-none hidden"
                    data-search-ajax-result>
                    <div class="loading-relative" id="search-loading" style="display: none;">
                        <div class="loading">
                            <div class="span1"></div>
                            <div class="span2"></div>
                            <div class="span3"></div>
                        </div>
                    </div>
                    <div data-search-result-area>

                    </div>
                    <a data-search-view-all href=""
                        class="flex items-center justify-center w-full p-4 bg-sky-600 text-base">
                        View all results <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512"
                            class="w-4 h-4 ml-2 inline-block">
                            <path fill="currentColor"
                                d="M224.3 273l-136 136c-9.4 9.4-24.6 9.4-33.9 0l-22.6-22.6c-9.4-9.4-9.4-24.6 0-33.9l96.4-96.4-96.4-96.4c-9.4-9.4-9.4-24.6 0-33.9L54.3 103c9.4-9.4 24.6-9.4 33.9 0l136 136c9.5 9.4 9.5 24.6.1 34z" />
                        </svg></i>
                    </a>
                </div>
            </div>
        </div>
        <div class="ml-8 hidden lg:flex items-center gap-2">
            <?php $socials = kiranime_get_social_links();foreach ($socials as $key => $val): ?>
            <?php if ($key == "telegram"): ?>
            <div class="w-10 h-10 flex items-center justify-center rounded-sm" style="background: #08c;">
                <a href="<?php echo $val['link'] ?>" target="_blank">
                    <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5" viewBox="0 0 448 512">
                        <path fill="currentColor"
                            d="M446.7 98.6l-67.6 318.8c-5.1 22.5-18.4 28.1-37.3 17.5l-103-75.9-49.7 47.8c-5.5 5.5-10.1 10.1-20.7 10.1l7.4-104.9 190.9-172.5c8.3-7.4-1.8-11.5-12.9-4.1L117.8 284 16.2 252.2c-22.1-6.9-22.5-22.1 4.6-32.7L418.2 66.4c18.4-6.9 34.5 4.1 28.5 32.2z" />
                    </svg>
                </a>
            </div>
            <?php endif;?>
            <?php if ($key == 'discord'): ?>
            <div class="w-10 h-10 flex items-center justify-center rounded-sm" style="background: #6f85d5;">
                <a href="<?php echo $val['link'] ?>" target="_blank">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" class="w-5 h-5">
                        <path fill="currentColor"
                            d="M297.216 243.2c0 15.616-11.52 28.416-26.112 28.416-14.336 0-26.112-12.8-26.112-28.416s11.52-28.416 26.112-28.416c14.592 0 26.112 12.8 26.112 28.416zm-119.552-28.416c-14.592 0-26.112 12.8-26.112 28.416s11.776 28.416 26.112 28.416c14.592 0 26.112-12.8 26.112-28.416.256-15.616-11.52-28.416-26.112-28.416zM448 52.736V512c-64.494-56.994-43.868-38.128-118.784-107.776l13.568 47.36H52.48C23.552 451.584 0 428.032 0 398.848V52.736C0 23.552 23.552 0 52.48 0h343.04C424.448 0 448 23.552 448 52.736zm-72.96 242.688c0-82.432-36.864-149.248-36.864-149.248-36.864-27.648-71.936-26.88-71.936-26.88l-3.584 4.096c43.52 13.312 63.744 32.512 63.744 32.512-60.811-33.329-132.244-33.335-191.232-7.424-9.472 4.352-15.104 7.424-15.104 7.424s21.248-20.224 67.328-33.536l-2.56-3.072s-35.072-.768-71.936 26.88c0 0-36.864 66.816-36.864 149.248 0 0 21.504 37.12 78.08 38.912 0 0 9.472-11.52 17.152-21.248-32.512-9.728-44.8-30.208-44.8-30.208 3.766 2.636 9.976 6.053 10.496 6.4 43.21 24.198 104.588 32.126 159.744 8.96 8.96-3.328 18.944-8.192 29.44-15.104 0 0-12.8 20.992-46.336 30.464 7.68 9.728 16.896 20.736 16.896 20.736 56.576-1.792 78.336-38.912 78.336-38.912z" />
                    </svg>
                </a>
            </div>
            <?php endif;?>
            <?php if ($key == 'reddit'): ?>
            <div class="w-10 h-10 flex items-center justify-center rounded-sm" style="background: #ff3c1f;">
                <a href="<?php echo $val['link'] ?>" target="_blank">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" class="w-5 h-5">
                        <path fill="currentColor"
                            d="M201.5 305.5c-13.8 0-24.9-11.1-24.9-24.6 0-13.8 11.1-24.9 24.9-24.9 13.6 0 24.6 11.1 24.6 24.9 0 13.6-11.1 24.6-24.6 24.6zM504 256c0 137-111 248-248 248S8 393 8 256 119 8 256 8s248 111 248 248zm-132.3-41.2c-9.4 0-17.7 3.9-23.8 10-22.4-15.5-52.6-25.5-86.1-26.6l17.4-78.3 55.4 12.5c0 13.6 11.1 24.6 24.6 24.6 13.8 0 24.9-11.3 24.9-24.9s-11.1-24.9-24.9-24.9c-9.7 0-18 5.8-22.1 13.8l-61.2-13.6c-3-.8-6.1 1.4-6.9 4.4l-19.1 86.4c-33.2 1.4-63.1 11.3-85.5 26.8-6.1-6.4-14.7-10.2-24.1-10.2-34.9 0-46.3 46.9-14.4 62.8-1.1 5-1.7 10.2-1.7 15.5 0 52.6 59.2 95.2 132 95.2 73.1 0 132.3-42.6 132.3-95.2 0-5.3-.6-10.8-1.9-15.8 31.3-16 19.8-62.5-14.9-62.5zM302.8 331c-18.2 18.2-76.1 17.9-93.6 0-2.2-2.2-6.1-2.2-8.3 0-2.5 2.5-2.5 6.4 0 8.6 22.8 22.8 87.3 22.8 110.2 0 2.5-2.2 2.5-6.1 0-8.6-2.2-2.2-6.1-2.2-8.3 0zm7.7-75c-13.6 0-24.6 11.1-24.6 24.9 0 13.6 11.1 24.6 24.6 24.6 13.8 0 24.9-11.1 24.9-24.6 0-13.8-11-24.9-24.9-24.9z" />
                    </svg>
                </a>
            </div>
            <?php endif;?>
            <?php endforeach;?>
        </div>
    </div>
    <?php if (!is_user_logged_in()) {?>
    <span data-login-toggle
        class="block justify-self-end absolute right-4 md:mr-4 top-1/2 transform -translate-y-1/2 rounded-sm bg-sky-600 md:px-5 md:py-3 px-3 py-2 cursor-pointer">Login</span>
    <?php } else {?>
    <div class="w-40 flex items-center justify-end lg:justify-start gap-1 lg:gap-5">
        <div class="relative w-max">
            <div dropdown-notification-trigger
                class="w-10 h-10 relative leading-10 cursor-pointer rounded-full bg-opacity-0 lg:bg-opacity-10 bg-white flex items-center justify-center">
                <div notification-number
                    class="hidden rounded-full absolute -top-1 -right-1 bg-rose-600 items-center justify-center overflow-hidden w-5 h-5 text-xs font-medium px-1">
                    0
                </div>
                <svg class="w-7 h-7 sm: lg:w-4 lg:h-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                    <path fill="currentColor"
                        d="M224 512c35.32 0 63.97-28.65 63.97-64H160.03c0 35.35 28.65 64 63.97 64zm215.39-149.71c-19.32-20.76-55.47-51.99-55.47-154.29 0-77.7-54.48-139.9-127.94-155.16V32c0-17.67-14.32-32-31.98-32s-31.98 14.33-31.98 32v20.84C118.56 68.1 64.08 130.3 64.08 208c0 102.3-36.15 133.53-55.47 154.29-6 6.45-8.66 14.16-8.61 21.71.11 16.4 12.98 32 32.1 32h383.8c19.12 0 32-15.6 32.1-32 .05-7.55-2.61-15.27-8.61-21.71z" />
                </svg>
            </div>
            <div dropdown-notification-content="0"
                class="w-72 h-auto transform transition-all duration-200 absolute top-full left-auto right-0 bg-overlay rounded shadow-lg -translate-y-full opacity-0 pointer-events-none"
                aria-labelledby="noti-list">
                <input type="hidden" name="notif-ids" value="">
                <div set-all-notification-read class="block w-full mb-2 bg-black bg-opacity-20">
                    <a class="flex items-center gap-2 justify-center w-full bg px-4 py-2  hover:text-sky-400 cursor-pointer"
                        data-position="dropdown">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" class="w-3 h-3">
                            <path fill="currentColor"
                                d="M173.898 439.404l-166.4-166.4c-9.997-9.997-9.997-26.206 0-36.204l36.203-36.204c9.997-9.998 26.207-9.998 36.204 0L192 312.69 432.095 72.596c9.997-9.997 26.207-9.997 36.204 0l36.203 36.204c9.997 9.997 9.997 26.206 0 36.204l-294.4 294.401c-9.998 9.997-26.207 9.997-36.204-.001z" />
                        </svg> Mark all as read</a>
                </div>
                <div notification-content-area class="max-h-52 overflow-y-auto overflow-x-hidden"></div>
                <a class="block rounded-b-md shadow-md bg-secondary w-full px-4 py-2 text-sm" href="/user/notification">
                    <div class="text-center  hover:text-sky-300">View all</div>
                </a>

            </div>
        </div>
        <div class="w-max relative">
            <img class="w-10 h-10 relative leading-10 rounded-full bg-white bg-opacity-10 flex items-center justify-center cursor-pointer"
                data-user-menu-dropdown src="<?php echo kiranime_get_user_avatar(get_current_user_id()); ?>" />
            <div user-menu-content user-menu-state="0"
                class="w-80 h-auto overflow-x-hidden transform transition-all duration-150 absolute top-full left-auto right-0 bg-secondary rounded-xl shadow-lg -translate-y-full opacity-0 pointer-events-none"
                style="transform: translate3d(-10px, 10px, 0px);">
                <div class="py-3 px-4">
                    <div class="w-full">
                        <div class="w-full text-sm font-semibold text-sky-400 leading-9">
                            <strong current-username><?php if ($uif) {echo $uif->display_name;}?></strong>
                        </div>
                        <div class="w-full text-xs font-light text-gray-200"><?php if ($uif) {echo $uif->user_email;}?>
                        </div>
                    </div>
                </div>
                <div class="mt-1 mx-3 space-y-1">
                    <a class="px-4 py-3 flex items-center hover:text-sky-400 gap-2 font-medium text-xs bg-overlay bg-opacity-20 rounded-xl"
                        href="/user/profile">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" class="w-4 h-4">
                            <path fill="currentColor"
                                d="M224 256c70.7 0 128-57.3 128-128S294.7 0 224 0 96 57.3 96 128s57.3 128 128 128zm89.6 32h-16.7c-22.2 10.2-46.9 16-72.9 16s-50.6-5.8-72.9-16h-16.7C60.2 288 0 348.2 0 422.4V464c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48v-41.6c0-74.2-60.2-134.4-134.4-134.4z" />
                        </svg>
                        Profile</a>
                    <a class="px-4 py-3 flex items-center hover:text-sky-400 gap-2 font-medium text-xs bg-overlay bg-opacity-20 rounded-xl"
                        href="/user/continue-watching">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" class="w-4 h-4">
                            <path fill="currentColor"
                                d="M504 255.531c.253 136.64-111.18 248.372-247.82 248.468-59.015.042-113.223-20.53-155.822-54.911-11.077-8.94-11.905-25.541-1.839-35.607l11.267-11.267c8.609-8.609 22.353-9.551 31.891-1.984C173.062 425.135 212.781 440 256 440c101.705 0 184-82.311 184-184 0-101.705-82.311-184-184-184-48.814 0-93.149 18.969-126.068 49.932l50.754 50.754c10.08 10.08 2.941 27.314-11.313 27.314H24c-8.837 0-16-7.163-16-16V38.627c0-14.254 17.234-21.393 27.314-11.314l49.372 49.372C129.209 34.136 189.552 8 256 8c136.81 0 247.747 110.78 248 247.531zm-180.912 78.784l9.823-12.63c8.138-10.463 6.253-25.542-4.21-33.679L288 256.349V152c0-13.255-10.745-24-24-24h-16c-13.255 0-24 10.745-24 24v135.651l65.409 50.874c10.463 8.137 25.541 6.253 33.679-4.21z" />
                        </svg>
                        Continue Watching</a>
                    <a class="px-4 py-3 flex items-center hover:text-sky-400 gap-2 font-medium text-xs bg-overlay bg-opacity-20 rounded-xl"
                        href="/user/watch-list">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" class="w-4 h-4">
                            <path fill="currentColor"
                                d="M462.3 62.6C407.5 15.9 326 24.3 275.7 76.2L256 96.5l-19.7-20.3C186.1 24.3 104.5 15.9 49.7 62.6c-62.8 53.6-66.1 149.8-9.9 207.9l193.5 199.8c12.5 12.9 32.8 12.9 45.3 0l193.5-199.8c56.3-58.1 53-154.3-9.8-207.9z" />
                        </svg>
                        Watch List</a>
                    <a class="px-4 py-3 flex items-center hover:text-sky-400 gap-2 font-medium text-xs bg-overlay bg-opacity-20 rounded-xl"
                        href="/user/notification">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" class="w-4 h-4">
                            <path fill="currentColor"
                                d="M224 512c35.32 0 63.97-28.65 63.97-64H160.03c0 35.35 28.65 64 63.97 64zm215.39-149.71c-19.32-20.76-55.47-51.99-55.47-154.29 0-77.7-54.48-139.9-127.94-155.16V32c0-17.67-14.32-32-31.98-32s-31.98 14.33-31.98 32v20.84C118.56 68.1 64.08 130.3 64.08 208c0 102.3-36.15 133.53-55.47 154.29-6 6.45-8.66 14.16-8.61 21.71.11 16.4 12.98 32 32.1 32h383.8c19.12 0 32-15.6 32.1-32 .05-7.55-2.61-15.27-8.61-21.71z" />
                        </svg>
                        Notification</a>
                    <a class="px-4 py-3 flex items-center hover:text-sky-400 gap-2 font-medium text-xs bg-overlay bg-opacity-20 rounded-xl"
                        href="/user/mal">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" class="w-4 h-4">
                            <path fill="currentColor"
                                d="M16 288c-8.8 0-16 7.2-16 16v32c0 8.8 7.2 16 16 16h112v-64zm489-183L407.1 7c-4.5-4.5-10.6-7-17-7H384v128h128v-6.1c0-6.3-2.5-12.4-7-16.9zm-153 31V0H152c-13.3 0-24 10.7-24 24v264h128v-65.2c0-14.3 17.3-21.4 27.4-11.3L379 308c6.6 6.7 6.6 17.4 0 24l-95.7 96.4c-10.1 10.1-27.4 3-27.4-11.3V352H128v136c0 13.3 10.7 24 24 24h336c13.3 0 24-10.7 24-24V160H376c-13.2 0-24-10.8-24-24z" />
                        </svg>
                        MAL Import</a>
                    <a class="px-4 py-3 flex items-center hover:text-sky-400 gap-2 font-medium text-xs bg-overlay bg-opacity-20 rounded-xl"
                        href="/user/setting">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" class="w-4 h-4">
                            <path fill="currentColor"
                                d="M487.4 315.7l-42.6-24.6c4.3-23.2 4.3-47 0-70.2l42.6-24.6c4.9-2.8 7.1-8.6 5.5-14-11.1-35.6-30-67.8-54.7-94.6-3.8-4.1-10-5.1-14.8-2.3L380.8 110c-17.9-15.4-38.5-27.3-60.8-35.1V25.8c0-5.6-3.9-10.5-9.4-11.7-36.7-8.2-74.3-7.8-109.2 0-5.5 1.2-9.4 6.1-9.4 11.7V75c-22.2 7.9-42.8 19.8-60.8 35.1L88.7 85.5c-4.9-2.8-11-1.9-14.8 2.3-24.7 26.7-43.6 58.9-54.7 94.6-1.7 5.4.6 11.2 5.5 14L67.3 221c-4.3 23.2-4.3 47 0 70.2l-42.6 24.6c-4.9 2.8-7.1 8.6-5.5 14 11.1 35.6 30 67.8 54.7 94.6 3.8 4.1 10 5.1 14.8 2.3l42.6-24.6c17.9 15.4 38.5 27.3 60.8 35.1v49.2c0 5.6 3.9 10.5 9.4 11.7 36.7 8.2 74.3 7.8 109.2 0 5.5-1.2 9.4-6.1 9.4-11.7v-49.2c22.2-7.9 42.8-19.8 60.8-35.1l42.6 24.6c4.9 2.8 11 1.9 14.8-2.3 24.7-26.7 43.6-58.9 54.7-94.6 1.5-5.5-.7-11.3-5.6-14.1zM256 336c-44.1 0-80-35.9-80-80s35.9-80 80-80 80 35.9 80 80-35.9 80-80 80z" />
                        </svg>
                        Settings</a>
                </div>
                <a logout-trigger
                    class="p-5 hover:text-sky-400 flex w-full items-center justify-end gap-2 font-medium text-xs rounded-md"
                    href="#">Logout
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" class="w-4 h-4">
                        <path fill="currentColor"
                            d="M190.5 66.9l22.2-22.2c9.4-9.4 24.6-9.4 33.9 0L441 239c9.4 9.4 9.4 24.6 0 33.9L246.6 467.3c-9.4 9.4-24.6 9.4-33.9 0l-22.2-22.2c-9.5-9.5-9.3-25 .4-34.3L311.4 296H24c-13.3 0-24-10.7-24-24v-32c0-13.3 10.7-24 24-24h287.4L190.9 101.2c-9.8-9.3-10-24.8-.4-34.3z" />
                    </svg>
                </a>
            </div>
        </div>
    </div>
    <?php }?>
    <button mobile-search-trigger
        class="absolute block lg:hidden top-1/2 transform -translate-y-1/2 <?php if (is_user_logged_in()) {echo 'right-24';} else {echo 'right-20';}?> px-2 py-1 w-max ">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" class="w-5 h-5">
            <path fill="currentColor"
                d="M505 442.7L405.3 343c-4.5-4.5-10.6-7-17-7H372c27.6-35.3 44-79.7 44-128C416 93.1 322.9 0 208 0S0 93.1 0 208s93.1 208 208 208c48.3 0 92.7-16.4 128-44v16.3c0 6.4 2.5 12.5 7 17l99.7 99.7c9.4 9.4 24.6 9.4 33.9 0l28.3-28.3c9.4-9.4 9.4-24.6.1-34zM208 336c-70.7 0-128-57.2-128-128 0-70.7 57.2-128 128-128 70.7 0 128 57.2 128 128 0 70.7-57.2 128-128 128z" />
        </svg>
    </button>
</div>
<div mobile-search-status="0"
    class="w-full pointer-events-none bg-primary bg-opacity-90 pb-2 transform -translate-y-full opacity-0 transition-all duration-200 z-40">
    <div class="relative w-full">
        <form action="/search" autocomplete="off" class="w-full flex items-center justify-around relative">
            <a href="/filter" class="w-10 h-10 rounded-sm flex items-center justify-center bg-overlay"><svg
                    class="w-4 h-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                    <path fill="currentColor"
                        d="M487.976 0H24.028C2.71 0-8.047 25.866 7.058 40.971L192 225.941V432c0 7.831 3.821 15.17 10.237 19.662l80 55.98C298.02 518.69 320 507.493 320 487.98V225.941l184.947-184.97C520.021 25.896 509.338 0 487.976 0z" />
                </svg></a>
            <input mobile-search-input type="text" class="w-10/12 p-2 text-sm rounded-sm text-gray-900" name="keyword"
                placeholder="Search anime...">
            <button type="submit" class="absolute right-5 top-1/2 transform -translate-y-1/2 z-50 text-gray-900">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" class="w-5 h-5">
                    <path fill="currentColor"
                        d="M505 442.7L405.3 343c-4.5-4.5-10.6-7-17-7H372c27.6-35.3 44-79.7 44-128C416 93.1 322.9 0 208 0S0 93.1 0 208s93.1 208 208 208c48.3 0 92.7-16.4 128-44v16.3c0 6.4 2.5 12.5 7 17l99.7 99.7c9.4 9.4 24.6 9.4 33.9 0l28.3-28.3c9.4-9.4 9.4-24.6.1-34zM208 336c-70.7 0-128-57.2-128-128 0-70.7 57.2-128 128-128 70.7 0 128 57.2 128 128 0 70.7-57.2 128-128 128z" />
                </svg>
            </button>
        </form>
        <div class="bg-tertiary shadow-lg absolute top-10 mt-1 inset-x-0 z-10 list-none hidden" mobile-search-result>
            <div mobile-search-result-area>

            </div>
            <a mobile-search-view-all href="" class="flex items-center justify-center w-full p-4 bg-sky-600 text-base">
                View all results <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512"
                    class="w-4 h-4 ml-2 inline-block">
                    <path fill="currentColor"
                        d="M224.3 273l-136 136c-9.4 9.4-24.6 9.4-33.9 0l-22.6-22.6c-9.4-9.4-9.4-24.6 0-33.9l96.4-96.4-96.4-96.4c-9.4-9.4-9.4-24.6 0-33.9L54.3 103c9.4-9.4 24.6-9.4 33.9 0l136 136c9.5 9.4 9.5 24.6.1 34z" />
                </svg></i>
            </a>
        </div>
    </div>
</div>