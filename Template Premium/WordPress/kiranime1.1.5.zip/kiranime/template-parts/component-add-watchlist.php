<?php
$wl = [['key' => 'plan_to_watch', 'name' => 'Plan to Watch'], ['key' => 'watching', 'name' => 'Watching'], ['key' => 'on_hold', 'name' => 'On Hold'], ['key' => 'dropped', 'name' => 'Dropped'], ['key' => 'completed', 'name' => 'Completed'], ['key' => 'remove', 'name' => 'Remove']];
?>
<div class="absolute top-0 left-full h-auto w-max">
    <?php foreach ($wl as $w): ?>
    <span data-watchlist-type="<?php echo $w['key']; ?>" data-watchlist-id="<?php the_ID();?>"
        class="w-full block px-2 py-1 text-xs font-normal text-secondary hover:text-gray-900 hover:bg-secondary hover:bg-opacity-10">
        <?php echo $w['name']; ?>
    </span>
    <?php endforeach;?>
</div>