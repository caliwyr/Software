<?php
function init_kira_remote_thumb()
{
    new kira_remote_thumb();
}

if (is_admin()) {
    add_action('load-post.php', 'init_kira_remote_thumb');
    add_action('load-post-new.php', 'init_kira_remote_thumb');
}

class kira_remote_thumb
{

    /**
     * Hook into the appropriate actions when the kira_remote_thumb is constructed.
     */
    public function __construct()
    {
        add_action('save_post', array($this, 'save'));
    }

    /**
     * Save the meta when the post is saved.
     */
    public function save($post_id)
    {

        /*
         * We need to verify this came from the our screen and with proper authorization,
         * because save_post can be triggered at other times.
         */

        // Check if our nonce is set.
        if (!isset($_POST['kira_remote_thumb_nonce'])) {
            return $post_id;
        }

        $nonce = $_POST['kira_remote_thumb_nonce'];

        // Verify that the nonce is valid.
        if (!wp_verify_nonce($nonce, 'kira_remote_thumb')) {
            return $post_id;
        }

        // If this is an autosave, our form has not been submitted,
        // so we don't want to do anything.
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return $post_id;
        }

        // Check the user's permissions.
        if ('page' == $_POST['post_type']) {

            if (!current_user_can('edit_page', $post_id)) {
                return $post_id;
            }

        } else {

            if (!current_user_can('edit_post', $post_id)) {
                return $post_id;
            }

        }

        /* All good, its safe for us to save the data now. */

        // Sanitize the user input.
        $image = sanitize_text_field($_POST['kiranime_anime_background']);
        $second_img = sanitize_text_field($_POST['kira_remote_thumbnail']);

        $blogurl = get_site_url();
        //Get the remote image and save to uploads directory
        $already_uploaded = strpos($image, $blogurl);
        $featured = strpos($second_img, $blogurl);

        if (!$already_uploaded || $already_uploaded != '0' || !$featured || $featured != '0') {
            return $post_id;
        }
        if ($image) {
            $this->save_metadata($image, 'background');
        }
        if ($second_img) {
            $this->save_metadata($second_img, 'featured');
        }
    }

    public function save_metadata($image, $post_id, $type = 'featured')
    {
        $upload_dir = wp_upload_dir();
        $img_name = time() . '.jpg' . basename($image, '__kira_thumb');
        $img = wp_remote_get($image);
        if (is_wp_error($img)) {
            $error_message = $img->get_error_message();
            add_action('admin_notices', array($this, 'kira_remote_thumb_admin_notice'));
        } else {
            $img = wp_remote_retrieve_body($img);
            $fp = fopen($upload_dir['path'] . '/' . $img_name, 'w');
            fwrite($fp, $img);
            fclose($fp);

            $wp_filetype = wp_check_filetype($img_name, null);
            $attachment = array(
                'post_mime_type' => $wp_filetype['type'],
                'post_title' => preg_replace('/\.[^.]+$/', '', $img_name),
                'post_content' => '',
                'post_status' => 'inherit',
            );

            //require for wp_generate_attachment_metadata which generates image related meta-data also creates thumbs
            require_once ABSPATH . 'wp-admin/includes/image.php';
            $attach_id = wp_insert_attachment($attachment, $upload_dir['path'] . '/' . $img_name, $post_id);
            //Generate post thumbnail of different sizes.
            $attach_data = wp_generate_attachment_metadata($attach_id, $upload_dir['path'] . '/' . $img_name);
            wp_update_attachment_metadata($attach_id, $attach_data);

            if ($type === 'featured') {
                //Set as featured image.
                delete_post_meta($post_id, '_thumbnail_id');
                add_post_meta($post_id, '_thumbnail_id', $attach_id, true);
            } else {
                $attach_url = wp_get_attachment_url($attach_id);
                // update Background image
                delete_post_meta($post_id, 'kiranime_anime_background');
                add_post_meta($post_id, 'kiranime_anime_background', $attach_url);
            }
        }
    }

    /**
     * Admin notice for errors.
     */
    public function kira_remote_thumb_admin_notice()
    {?>
<div class="error">
    <p><?php _e('Error while fetching remote thumbnail! Please try again.', 'kira_remote_thumb');?></p>
</div>
<?php
}
}