<?php
/**
 * Episode information
 *
 * @package kiranime
 */

/**
 * add new metabox to episode cpt
 */

function kiranime_add_episode_metabox()
{
    add_meta_box(
        'kiranime_episode_metabox_parent',
        'Anime Info',
        'kiranime_episode_anime_parent',
        'episode'
    );
    add_meta_box(
        'kiranime_episode_metabox',
        'Episode Information',
        'kiranime_episode_information_meta',
        'episode',
    );
    add_meta_box(
        'kiranime_episode_metabox_player',
        'Player Embed',
        'kiranime_episode_video_player',
        'episode',
    );

}
add_action('add_meta_boxes', 'kiranime_add_episode_metabox');

/**
 * get episode metadata
 */

function kiranime_get_episode_metadata(int $episode_id)
{
    $prefix = 'kiranime_episode_';
    $keys = ['number', 'title', 'duration', 'released', 'parent_id', 'parent_name', 'parent_slug', 'players'];
    $result = [];

    foreach ($keys as $key) {
        $result[$key] = get_post_meta($episode_id, $prefix . $key, true);
    }

    $result['downloads'] = get_post_meta($episode_id, 'kiranime_download_data', true);

    return $result;
}

/**
 * Save metabox upon saving or updating episode
 */

add_action('save_post_episode', 'kiranime_save_episode_metadata', 10, 3);
function kiranime_save_episode_metadata($post_id, $post, $update)
{
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return $post_id;
    }

    $prefix = 'kiranime_episode_';
    $keys = ['number', 'title', 'duration', 'released', 'parent_id', 'parent_name', 'parent_slug'];

    foreach ($keys as $key) {
        $val = isset($_POST) && isset($_POST[$prefix . $key]) ? $_POST[$prefix . $key] : '';
        $mk = $prefix . $key;

        if ($key == 'parent_id' && $val) {
            update_post_meta($val, 'kiranime_anime_updated', time());
            if (!$update) {
                kiranime_notify_user_new_episode($post_id, $val);
            }
        }

        update_post_meta($post_id, $mk, $val);

    }
}

/**
 * episode metabox html
 */

function kiranime_episode_information_meta($post)
{
    $prefix = 'kiranime_episode_';
    $keys = ['number', 'title', 'duration', 'released'];
    $vals = [];

    wp_enqueue_style('kiranime-admin-css', get_stylesheet_directory_uri() . '/css/app.css');
    foreach ($keys as $key) {
        $meta_key = $prefix . $key;
        if ($key == 'released') {
            $vals[$meta_key] = $post->post_date;
        } else {
            $vals[$meta_key] = get_post_meta($post->ID, $meta_key, true);
        }
    }?>

<div class="w-full h-auto bg-white space-y-1">
    <?php foreach ($vals as $key => $val): ?>
    <?php if ($key != $prefix . 'released'): ?>
    <div>
        <span
            class="text-xs font-semibold inline-block py-1 px-2 rounded-t text-sky-600 bg-sky-200 uppercase w-2/12 mr-1 flex-shrink-0">
            <?php echo str_replace($prefix, '', $key); ?>
        </span>
        <div class="mb-3 pt-0 flex-auto">
            <input type="text" placeholder="Episode <?php echo str_replace($prefix, '', $key); ?>"
                name="<?php echo $key; ?>" id="<?php echo $key; ?>" value="<?php echo $val; ?>"
                class="px-3 py-3 placeholder-gray-400 text-blueGray-600 relative bg-white rounded text-sm border-none ring-1 ring-sky-200 shadow outline-none focus:outline-none focus:ring w-full" />
        </div>
    </div>
    <?php endif;?>
    <?php endforeach;?>
</div>
<?php
}

function kiranime_episode_anime_parent($post)
{
    $prefix = 'kiranime_episode_';
    $keys = ['parent_id', 'parent_name', 'parent_slug'];
    $vals = [];

    wp_enqueue_style('kiranime-admin-css', get_stylesheet_directory_uri() . '/css/app.css');
    foreach ($keys as $key) {
        $meta_key = $prefix . $key;

        $vals[$meta_key] = get_post_meta($post->ID, $meta_key, true);
    }?>

<div class="w-full h-auto bg-white space-y-1">
    <div>
        <span
            class="text-xs font-semibold inline-block py-1 px-2 rounded-t text-sky-600 bg-sky-200 uppercase w-2/12 mr-1 flex-shrink-0">
            Anime Name
        </span>
        <div class="mb-3 pt-0 flex-auto relative">
            <input data-anime-name-input type="text" autocomplete="off" name="kiranime_episode_parent_name"
                id="kiranime_episode_parent_name" placeholder="Anime title"
                class="px-3 py-3 placeholder-gray-400 text-blueGray-600 relative bg-white rounded text-sm border-none ring-1 ring-sky-200 shadow outline-none focus:outline-none focus:ring w-full"
                value="<?php echo $vals['kiranime_episode_parent_name']; ?>" />
            <div class="w-full mt-2 p-2 absolute hidden top-full left-0 flex-col gap-2 bg-white z-50"
                data-anime-name-result>

            </div>
            <input type="number" name="kiranime_episode_parent_id"
                value="<?php echo $vals['kiranime_episode_parent_id']; ?>" data-anime-id class="hidden">
            <input type="text" name="kiranime_episode_parent_slug"
                value="<?php echo $vals['kiranime_episode_parent_slug']; ?>" data-anime-slug class="hidden">
        </div>
    </div>


</div>
</div>
<script>
const searchNameInput = document.querySelector('[data-anime-name-input]');
const searchNameResultWrapper = document.querySelector('[data-anime-name-result]');

let list = '';
let searchTimeout;

searchNameInput.addEventListener('input', (e) => {
    const val = e.target.value;
    if (searchTimeout) {
        clearTimeout(searchTimeout);
    };

    searchTimeout = setTimeout(async () => {
        const f = new FormData();
        f.append('action', 'kiranime_get_anime_title');
        f.append('query', val);

        const get = await fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
            method: 'POST',
            body: f
        });

        const {
            data
        } = await get.json();

        if (Array.isArray(data) && data.length > 0) {

            for (const post of data) {
                list += `
            <div data-anime-result-slug="${post.slug}" data-anime-result-id="${post.id}" onclick="setAnimeNameValue(event)" class="text-sm px-3 py-1 hover:bg-sky-600 text-black hover:text-white cursor-pointer">
                ${post.title}
            </div>
        `
            }

            searchNameResultWrapper.innerHTML = list
            searchNameResultWrapper.classList.remove('hidden');
            searchNameResultWrapper.classList.add('flex')
        } else {
            searchNameResultWrapper.innerHTML = `<div>
                No Anime found!
            </div>`
            searchNameResultWrapper.classList.remove('hidden');
            searchNameResultWrapper.classList.add('flex')
        }




    }, 500);

})

function setAnimeNameValue(e) {
    const id = e.srcElement.getAttribute('data-anime-result-id');
    const slug = e.srcElement.getAttribute('data-anime-result-slug');
    const val = e.srcElement.innerText;

    searchNameInput.value = val;
    document.querySelector('[data-anime-id]').value = id;
    document.querySelector('[data-anime-slug]').value = slug
    searchNameResultWrapper.classList.add('hidden');
    searchNameResultWrapper.classList.remove('flex')
}
</script>
<?php
}

/**
 * episode player metabox
 */

function kiranime_episode_video_player($post)
{
    $players = get_post_meta($post->ID, 'kiranime_episode_players', true);
    wp_enqueue_style('kiranime-admin-css', get_stylesheet_directory_uri() . '/css/app.css');
    ?>
<div class="w-full h-auto bg-white">
    <input type="hidden" data-player-nonce value="<?php echo wp_create_nonce('save_kiranime_players') ?>">
    <input type="hidden" data-player-length="<?php echo !empty($players) ? count($players) : 0 ?>">
    <div data-players-wrapper></div>

</div>
<button class="px-3 py-1 outline-none border-none bg-sky-600 text-white rounded-sm" data-add-new-player>Add
    Player</button>
</div>
<div class="hidden pb-2 mb-3 border-b border-sky-200">
    <div>
        <div class="flex items-center w-full justify-between">
            <span
                class="text-xs font-semibold inline-block py-1 px-2 rounded-t text-sky-600 bg-sky-200 uppercase w-2/12 mr-1 flex-shrink-0">
                Type
            </span>
            <span
                class="text-xs font-semibold inline-block py-1 px-2 rounded-t text-rose-600 bg-rose-200 uppercase w-2/12 flex-shrink-0 cursor-pointer">
                Delete This Player
            </span>
        </div>
        <div class="mb-3 pt-0 flex-auto">
            <select name="type" id="type"
                class="px-3 py-3 placeholder-gray-400 text-blueGray-600 relative bg-white rounded text-sm shadow outline-none focus:outline-none focus:ring w-full">
                <option value="SUB">SUB</option>
                <option value="DUB">DUB</option>
            </select>
        </div>
    </div>
    <div>
        <span
            class="text-xs font-semibold inline-block py-1 px-2 rounded-t text-sky-600 bg-sky-200 uppercase w-2/12 mr-1 flex-shrink-0">
            Provider
        </span>
        <div class="mb-3 pt-0 flex-auto">
            <input type="text" placeholder="Placeholder"
                class="px-3 py-3 placeholder-gray-400 text-blueGray-600 relative bg-white rounded text-sm border-none ring-1 ring-sky-200 shadow outline-none focus:outline-none focus:ring w-full" />
        </div>
    </div>
    <div>
        <span
            class="text-xs font-semibold inline-block py-1 px-2 rounded-t text-sky-600 bg-sky-200 uppercase w-2/12 mr-1 flex-shrink-0">
            Embed Code
        </span>
        <div class="mb-3 pt-0 flex-auto">
            <textarea type="text" placeholder="Placeholder"
                class="px-3 py-3 placeholder-gray-400 text-blueGray-600 relative bg-white rounded  text-sm border shadow outline-none focus:outline-none focus:ring w-full"></textarea>
        </div>
    </div>
</div>
<script>
function sanitize(string) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#x27;',
        "/": '&#x2F;',
    };
    const reg = /[&<>"'/]/ig;
    return string.replace(reg, (match) => (map[match]));
}

let players = '<?php echo $players; ?>';
players = players ? JSON.parse(players) : [];
const playerwrapper = document.querySelector('[data-players-wrapper]');
let totalPlayer = [];
const saveButtonPost = document.querySelector('#publish');

document.addEventListener('DOMContentLoaded', () => {
    if (players && players.length > 0) {
        totalPlayer = players;
    } else {
        totalPlayer = [{
            provider: '',
            player: '',
        }]
    }

    setBlockField(totalPlayer);
    setSaveInterval();
});

async function savePlayers() {
    saveButtonPost.setAttribute('disabled', 'true');
    const providers = Array.from(document.querySelectorAll('[data-player-provider]'));
    const players = Array.from(document.querySelectorAll('[data-player-embed]'));
    const types = Array.from(document.querySelectorAll('[data-type-select]'));
    const ajax = document.querySelector('[data-download-ajax]').value;

    if (!providers || !providers[0].value) return;
    const datatosend = [];
    for (const [i, e] of providers.entries()) {
        datatosend.push({
            provider: e.value,
            player: sanitize(players[i].value),
            type: types[i].value
        })
    }
    const nonce = document.querySelector('[data-player-nonce]').value;
    const postId = document.querySelector('#post_ID').value;
    const body = new FormData()
    body.append('action', 'save_kiranime_players');
    body.append('save_nonce', nonce);
    body.append('data', JSON.stringify(datatosend));
    body.append('episode', postId)

    fetch(ajax, {
        body,
        method: 'POST'
    }).then(e => e.json).then(e => {
        saveButtonPost.removeAttribute('disabled');
        setSaveInterval();
    })
}

function setSaveInterval(interval = 30000) {
    setTimeout(() => {
        savePlayers()
    }, interval);
}

document
    .querySelector('[data-add-new-player]')
    .addEventListener('click', (e) => {
        e.preventDefault();
        const providers = Array.from(document.querySelectorAll('[data-player-provider]'));
        const players = Array.from(document.querySelectorAll('[data-player-embed]'));

        const datatosend = [];
        for (const [i, e] of providers.entries()) {
            datatosend.push({
                provider: e.value,
                player: sanitize(players[i].value),
            })
        }

        datatosend.push({
            provider: '',
            player: ''
        })

        rearangeBlock(datatosend);
    });

function setBlockField(players) {
    let addon;

    if (Array.isArray(players) && players.length > 0) {
        for (const [i, e] of players.entries()) {
            const types = e.type ? e.type : 'SUB';
            if (i === 0) {
                addon = /*html*/ `
                <div class="pb-2 mb-3 border-b border-sky-200">
                    <div>
                        <div class="flex items-center w-full justify-between">
                            <span
                                class="text-xs font-semibold inline-block py-1 px-2 rounded-t text-sky-600 bg-sky-200 uppercase w-2/12 mr-1 flex-shrink-0">
                                Type
                            </span>
                        </div>
                        <div class="mb-3 pt-0 flex-auto">
                            <select data-type-select name="type" id="type"
                                class="px-3 py-3 placeholder-gray-400 text-blueGray-600 relative bg-white rounded text-sm shadow outline-none focus:outline-none focus:ring w-full">
                                <option value="SUB" ${types === 'SUB' ? 'selected':''}>SUB</option>
                                <option value="DUB" ${types === 'DUB' ? 'selected':''}>DUB</option>
                            </select>
                        </div>
                    </div>
                    <div>
                        <span
                            class="text-xs font-semibold inline-block py-1 px-2 rounded-t text-sky-600 bg-sky-200 uppercase w-2/12 mr-1 flex-shrink-0">
                            Provider
                        </span>
                        <div class="mb-3 pt-0 flex-auto">
                            <input data-player-provider type="text" placeholder="Server name"
                                class="px-3 py-3 placeholder-gray-400 text-blueGray-600 relative bg-white rounded text-sm border-none ring-1 ring-sky-200 shadow outline-none focus:outline-none focus:ring w-full" value="${e.provider}" />
                        </div>
                    </div>
                    <div>
                        <span
                            class="text-xs font-semibold inline-block py-1 px-2 rounded-t text-sky-600 bg-sky-200 uppercase w-2/12 mr-1 flex-shrink-0">
                            Embed Code
                        </span>
                        <div class="mb-3 pt-0 flex-auto">
                            <textarea onchange="savePlayers()" data-player-embed type="text" placeholder="Embed code"
                                class="px-3 py-3 placeholder-gray-400 text-blueGray-600 relative bg-white rounded  text-sm border shadow outline-none focus:outline-none focus:ring w-full">${e.player}</textarea>
                        </div>
                    </div>
                </div>
            `;

                continue;
            }
            addon += /*html*/ `
            <div class="pb-2 mb-3 border-b border-sky-200">
                <div>
                    <div class="flex items-center w-full justify-between">
                        <span
                            class="text-xs font-semibold inline-block py-1 px-2 rounded-t text-sky-600 bg-sky-200 uppercase w-2/12 mr-1 flex-shrink-0">
                            Type
                        </span>
                        <span onclick="removePlayerBlock(${i})"
                            class="text-xs font-semibold inline-block py-1 px-2 rounded-t text-rose-600 bg-rose-200 uppercase w-2/12 flex-shrink-0 cursor-pointer">
                            Delete This Player
                        </span>
                    </div>
                    <div class="mb-3 pt-0 flex-auto">
                            <select data-type-select name="type" id="type"
                                class="px-3 py-3 placeholder-gray-400 text-blueGray-600 relative bg-white rounded text-sm shadow outline-none focus:outline-none focus:ring w-full">
                                <option value="SUB" ${types === 'SUB' ? 'selected':''}>SUB</option>
                                <option value="DUB" ${types === 'DUB' ? 'selected':''}>DUB</option>
                            </select>
                        </div>
                    </div>
                    <div>
                        <span
                            class="text-xs font-semibold inline-block py-1 px-2 rounded-t text-sky-600 bg-sky-200 uppercase w-2/12 mr-1 flex-shrink-0">
                            Provider
                        </span>
                        <div class="mb-3 pt-0 flex-auto">
                            <input data-player-provider type="text" placeholder="Server name"
                                class="px-3 py-3 placeholder-gray-400 text-blueGray-600 relative bg-white rounded text-sm border-none ring-1 ring-sky-200 shadow outline-none focus:outline-none focus:ring w-full" value="${e.provider}" />
                        </div>
                    </div>
                    <div>
                        <span
                            class="text-xs font-semibold inline-block py-1 px-2 rounded-t text-sky-600 bg-sky-200 uppercase w-2/12 mr-1 flex-shrink-0">
                            Embed Code
                        </span>
                        <div class="mb-3 pt-0 flex-auto">
                            <textarea onchange="savePlayers()" data-player-embed type="text" placeholder="Embed code"
                                class="px-3 py-3 placeholder-gray-400 text-blueGray-600 relative bg-white rounded  text-sm border shadow outline-none focus:outline-none focus:ring w-full">${e.player}</textarea>
                        </div>
                    </div>
                </div>
            `;
        }

        playerwrapper.innerHTML = addon
    }
}

function removePlayerBlock(index) {
    if (totalPlayer.length === 1) return;

    totalPlayer.splice(index, 1);

    rearangeBlock(totalPlayer);
    savePlayers()
}

function rearangeBlock(players) {
    let blocks;
    for (const [i, e] of players.entries()) {
        const types = e.type ? e.type : 'SUB';
        if (i === 0) {
            blocks = /*html*/ `
                <div class="pb-2 mb-3 border-b border-sky-200">
                    <div>
                        <div class="flex items-center w-full justify-between">
                            <span
                                class="text-xs font-semibold inline-block py-1 px-2 rounded-t text-sky-600 bg-sky-200 uppercase w-2/12 mr-1 flex-shrink-0">
                                Type
                            </span>
                        </div>
                        <div class="mb-3 pt-0 flex-auto">
                            <select data-type-select name="type" id="type"
                                class="px-3 py-3 placeholder-gray-400 text-blueGray-600 relative bg-white rounded text-sm shadow outline-none focus:outline-none focus:ring w-full">
                                <option value="SUB" ${types === 'SUB' ? 'selected':''}>SUB</option>
                                <option value="DUB" ${types === 'DUB' ? 'selected':''}>DUB</option>
                            </select>
                        </div>
                    </div>
                    <div>
                        <span
                            class="text-xs font-semibold inline-block py-1 px-2 rounded-t text-sky-600 bg-sky-200 uppercase w-2/12 mr-1 flex-shrink-0">
                            Provider
                        </span>
                        <div class="mb-3 pt-0 flex-auto">
                            <input data-player-provider type="text" placeholder="Server name"
                                class="px-3 py-3 placeholder-gray-400 text-blueGray-600 relative bg-white rounded text-sm border-none ring-1 ring-sky-200 shadow outline-none focus:outline-none focus:ring w-full" value="${e.provider}" />
                        </div>
                    </div>
                    <div>
                        <span
                            class="text-xs font-semibold inline-block py-1 px-2 rounded-t text-sky-600 bg-sky-200 uppercase w-2/12 mr-1 flex-shrink-0">
                            Embed Code
                        </span>
                        <div class="mb-3 pt-0 flex-auto">
                            <textarea onchange="savePlayers()" data-player-embed type="text" placeholder="Embed code"
                                class="px-3 py-3 placeholder-gray-400 text-blueGray-600 relative bg-white rounded  text-sm border shadow outline-none focus:outline-none focus:ring w-full">${e.player}</textarea>
                        </div>
                    </div>
                </div>
            `;

            continue;
        }

        blocks += /*html*/ `
            <div class="pb-2 mb-3 border-b border-sky-200">
                <div>
                    <div class="flex items-center w-full justify-between">
                        <span
                            class="text-xs font-semibold inline-block py-1 px-2 rounded-t text-sky-600 bg-sky-200 uppercase w-2/12 mr-1 flex-shrink-0">
                            Type
                        </span>
                        <span onclick="removePlayerBlock(${i})"
                            class="text-xs font-semibold inline-block py-1 px-2 rounded-t text-rose-600 bg-rose-200 uppercase w-2/12 flex-shrink-0 cursor-pointer">
                            Delete This Player
                        </span>
                    </div>
                    <div class="mb-3 pt-0 flex-auto">
                            <select data-type-select name="type" id="type"
                                class="px-3 py-3 placeholder-gray-400 text-blueGray-600 relative bg-white rounded text-sm shadow outline-none focus:outline-none focus:ring w-full">
                                <option value="SUB" ${types === 'SUB' ? 'selected':''}>SUB</option>
                                <option value="DUB" ${types === 'DUB' ? 'selected':''}>DUB</option>
                            </select>
                        </div>
                    </div>
                    <div>
                        <span
                            class="text-xs font-semibold inline-block py-1 px-2 rounded-t text-sky-600 bg-sky-200 uppercase w-2/12 mr-1 flex-shrink-0">
                            Provider
                        </span>
                        <div class="mb-3 pt-0 flex-auto">
                            <input data-player-provider type="text" placeholder="Server name"
                                class="px-3 py-3 placeholder-gray-400 text-blueGray-600 relative bg-white rounded text-sm border-none ring-1 ring-sky-200 shadow outline-none focus:outline-none focus:ring w-full" value="${e.provider}" />
                        </div>
                    </div>
                    <div>
                        <span
                            class="text-xs font-semibold inline-block py-1 px-2 rounded-t text-sky-600 bg-sky-200 uppercase w-2/12 mr-1 flex-shrink-0">
                            Embed Code
                        </span>
                        <div class="mb-3 pt-0 flex-auto">
                            <textarea onchange="savePlayers()" data-player-embed type="text" placeholder="Embed code"
                                class="px-3 py-3 placeholder-gray-400 text-blueGray-600 relative bg-white rounded  text-sm border shadow outline-none focus:outline-none focus:ring w-full">${e.player}</textarea>
                        </div>
                    </div>
                </div>
            `;
    }

    totalPlayer = players;
    playerwrapper.innerHTML = '';
    playerwrapper.innerHTML = blocks;
    savePlayers();
}
</script>
<?php }

add_action('wp_ajax_save_kiranime_players', 'save_kiranime_players');
function save_kiranime_players()
{
    $params = $_POST;

    if (!$params || !wp_verify_nonce($params['save_nonce'], 'save_kiranime_players')) {
        return wp_send_json_error('Security check failed');
        wp_die();
    }

    $episode_id = $params['episode'];
    $players = stripslashes($params['data']);

    $updated = update_post_meta($episode_id, 'kiranime_episode_players', $players);
    return wp_send_json_success(['data' => $updated]);
    wp_die();
}

function kiranime_get_players(int $episode)
{
    if (!$episode) {
        return;
    }

    $players = get_post_meta($episode, 'kiranime_episode_players', true);
    return $players;
}