<?php

/**
 * set bookmark for specific anime
 */

add_action('wp_ajax_kiranime_add_to_list', 'kiranime_add_to_list');
function kiranime_add_to_list()
{
    $params = $_POST;
    $uid = get_current_user_id();

    if (!wp_verify_nonce($params['nonce'], 'kiranime_user_bookmark')) {
        return wp_send_json_error(['message' => 'Security check failed!']);
        wp_die();
    }

    if (!isset($params['type'])) {
        return wp_send_json_error(['message' => 'type is required!']);
        wp_die();
    }

    if ($params['type'] == 'remove') {
        return kiranime_remove_from_list($params['anime_id'], $params['nonce']);
    }

    $get_current_list = get_post_meta($params['anime_id'], 'bookmark_' . $params['type'] . '_by', false);
    if (in_array($uid, $get_current_list)) {
        return wp_send_json_success(['success' => true, 'message' => 'already added!', 'data' => $get_current_list]);
        wp_die();
    } else {
        $removed = remove_other_bookmark_type($params['type'], $params['anime_id'], $uid);
        $count = (int) get_post_meta($params['anime_id'], 'bookmark_count', true);
        $count = isset($count) ? (int) $count : 0;
        $no_removed = array_filter($removed, function ($val) {
            return $val['status'];
        });
        if (empty($no_removed) || count($no_removed) == 0) {
            update_post_meta($params['anime_id'], 'bookmark_count', $count + 1);
        }

        add_post_meta($params['anime_id'], 'bookmark_' . $params['type'] . '_by', $uid);
        return wp_send_json_success(['message' => 'Anime added to watch list!']);
        wp_die();
    }
}

add_action('wp_ajax_kiranime_remove_from_list', 'kiranime_remove_from_list');
function kiranime_remove_from_list($animeId = null, $nonce = null)
{
    $anime_id = !empty($animeId) ? $animeId : $_POST['anime_id'];
    $uid = get_current_user_id();
    $data_nonce = !empty($nonce) ? $nonce : $_POST['nonce'];
    if (!wp_verify_nonce($data_nonce, 'kiranime_user_bookmark')) {
        return wp_send_json_error(['message' => 'Security check failed!']);
        wp_die();
    }
    $types = ['plan_to_watch', 'watching', 'on_hold', 'completed', 'dropped'];

    foreach ($types as $type) {
        delete_post_meta($anime_id, 'bookmark_' . $type . '_by', $uid);
    }

    $count = (int) get_post_meta($anime_id, 'bookmark_count', true);
    if ($count && $count > 0) {
        update_post_meta($anime_id, 'bookmark_count', $count - 1);
    }
    return wp_send_json_success(['message' => 'anime removed from list!']);
    wp_die();
}

function remove_other_bookmark_type(string $data, int $anime_id, int $uid)
{
    $types = ['plan_to_watch', 'watching', 'on_hold', 'completed', 'dropped'];
    $types = array_filter($types, function ($val) use ($data) {
        return $val != $data;
    });
    $results = [];
    foreach ($types as $type) {
        $results[] = ['status' => delete_post_meta($anime_id, 'bookmark_' . $type . '_by', $uid)];
    }

    return $results;
}

function kiranime_get_user_watch_list(int $page = 1, int $total = 20)
{
    $uid = get_current_user_id();

    $posts = [
        'post_type' => 'anime',
        'post_status' => 'publish',
        'order' => 'DESC',
        'posts_per_page' => $total,
        'paged' => $page,
        'meta_query' => [
            'relation' => 'OR',
        ],
    ];

    $types = ['plan_to_watch', 'watching', 'on_hold', 'completed', 'dropped'];
    foreach ($types as $type) {
        $posts['meta_query'][] = [
            'key' => 'bookmark_' . $type . '_by',
            'value' => $uid,
        ];
    }

    $all = new WP_Query($posts);
    // return $all;

    $results = [];
    foreach ($all->posts as $post) {
        $type = wp_get_post_terms($post->ID, 'type');
        $attr = wp_get_post_terms($post->ID, 'anime_attribute');
        $results[] = [
            'title' => $post->post_title,
            'type' => !is_wp_error($type) && count($type) != 0 ? $type[0] : null,
            'metadata' => kiranime_get_anime_meta($post->ID),
            'featured' => get_the_post_thumbnail_url($post->ID, 'homepage-image'),
            'synopsis' => $post->post_content,
            'name' => $post->post_name,
            'attribute' => !is_wp_error($attr) ? $attr : [],
            'url' => get_the_permalink($post->ID),
            'id' => $post->ID,
        ];
    }

    return ['results' => $results, 'max_page' => $all->max_num_pages];
}

add_action('wp_ajax_kiranime_get_user_watch_list_by_type', 'kiranime_get_user_watch_list_by_type');
function kiranime_get_user_watch_list_by_type(string $datatype = 'plan_to_watch', int $paged = 1, int $perpage = 20)
{
    $uid = get_current_user_id();
    $type = !empty($_POST['type']) ? $_POST['type'] : $datatype;
    $per_page = !empty($_POST['per_page']) ? $_POST['per_page'] : $perpage;
    $page = !empty($_POST['page']) ? $_POST['page'] : $paged;

    if ($type == 'all') {
        $res = kiranime_get_user_watch_list($page, $per_page);
        return wp_send_json_success($res);
        wp_die();
    }

    $posts = [
        'post_type' => 'anime',
        'post_status' => 'publish',
        'order' => 'DESC',
        'orderby' => 'meta_value_num',
        'meta_key' => 'kiranime_anime_updated',
        'posts_per_page' => $per_page,
        'paged' => $page,
        'meta_query' => [
            [
                'key' => 'bookmark_' . $type . '_by',
                'value' => $uid,
                'compare' => '=',
            ],
        ],
    ];

    $all = new WP_Query($posts);

    // return $all;

    $results = [];
    foreach ($all->posts as $post) {
        $type = wp_get_post_terms($post->ID, 'type');
        $attr = wp_get_post_terms($post->ID, 'anime_attribute');
        $results[] = [
            'title' => $post->post_title,
            'type' => !is_wp_error($type) && count($type) != 0 ? $type[0] : null,
            'metadata' => kiranime_get_anime_meta($post->ID),
            'featured' => get_the_post_thumbnail_url($post->ID, 'homepage-image'),
            'synopsis' => $post->post_content,
            'name' => $post->post_name,
            'attribute' => !is_wp_error($attr) ? $attr : [],
            'url' => get_the_permalink($post->ID),
            'id' => $post->ID,
        ];
    }

    if ($_POST['ajax']) {
        return wp_send_json_success(['results' => $results, 'max_page' => $all->max_num_pages, 'current' => $page]);
        wp_die();
    }

    return $results;
}

function kiranime_get_user_list_by_anime(int $anime)
{
    $data = (array) get_post_meta($anime, 'bookmark_watching_by', false);

    return $data;
}