<?php
add_action('add_meta_boxes', 'kira_add_anime_meta_box');
function kira_add_anime_meta_box()
{
    add_meta_box(
        'kiranime_anime_fetch',
        'Fetch Anime Info',
        'kiranime_add_fetch_metabox',
        ['anime', 'movie']
    );
    add_meta_box(
        'kiranime_anime_metabox_id',
        'Anime Informations',
        'kiranime_add_metabox_html',
        ['anime', 'movie']
    );
    add_meta_box(
        'kiranime_download_metabox',
        'Download',
        'kiranime_download_metabox',
        ['anime', 'episode']
    );
}

function kiranime_get_anime_meta(int $post_id, $exclude = null)
{
    $prefix = 'kiranime_anime_';
    $keys = ['spotlight', 'rate', 'native', 'synonyms', 'aired', 'premiered', 'duration', 'episodes', 'score', 'background', 'updated'];

    $result = [];

    foreach ($keys as $key) {
        $meta_key = $prefix . $key;
        $name = ucfirst($key);
        $result[$name] = get_post_meta($post_id, $meta_key, true);
    }

    $result['download'] = get_post_meta($post_id, 'kiranime_download_data', true);

    if ($exclude) {
        $result = array_filter($result, function ($val) use ($exclude) {
            return !in_array(strtolower($val), $exclude);
        }, ARRAY_FILTER_USE_KEY);
    }

    return $result;
}

function kiranime_download_metabox($post)
{
    $downloads = get_post_meta($post->ID, 'kiranime_download_data', true);
    ?>


<div class="w-full h-auto bg-white space-y-1">
    <div id="data-download-wrapper" data-download-class-wrapper class="w-full h-auto bg-white space-y-1">

    </div>
    <div data-add-new-download
        class="w-max cursor-pointer text-xs font-semibold px-5 py-2 text-white rounded-sm bg-sky-600">
        Add Download
    </div>
</div>
<div class="w-0 h-0 bg-rose-600 ">

</div>
<input data-download-nonce type="hidden" name="" value="<?php echo wp_create_nonce('kiranime_save_download_batch') ?>">
<input data-download-ajax type="hidden" name="" value="<?php echo admin_url('admin-ajax.php') ?>">
<script>
const btn = document.querySelector('[data-add-new-download]');
const wrapper = document.getElementById('data-download-wrapper');
const saveButton = document.querySelector('#publish');
let totalData = [];

function deletedl(index) {
    const a = totalData.splice(index, 1);
    setBlockValue(totalData);
    saveDownload();
}

document.addEventListener('DOMContentLoaded', () => {
    const fromwp = <?php echo json_encode($downloads); ?>;

    if (fromwp) {
        totalData = JSON.parse(fromwp);
    } else {
        totalData = [];
    }
    setBlockValue(totalData);
    setTimeout(async () => {
        saveButton.setAttribute('disabled', 'true');
        await saveDownload()
    }, 15000);

})
btn.addEventListener('click', () => {
    totalData.push({
        resolution: '',
        links: [{
                provider: '',
                link: ''
            },
            {
                provider: '',
                link: ''
            },
            {
                provider: '',
                link: ''
            },
            {
                provider: '',
                link: ''
            },
        ]
    })
    setBlockValue(totalData);
    saveDownload()
})

let saveQueue;

function addTimeOut() {
    clearTimeout(saveQueue);
    saveQueue = setTimeout(async () => {
        await saveDownload()
    }, 15000);
}
async function saveDownload() {
    const res = document.querySelectorAll('[data-resolution]');
    const nonce = document.querySelector('[data-download-nonce]').value;
    const ajax = document.querySelector('[data-download-ajax]').value;
    const postId = document.querySelector('#post_ID').value;

    if (!postId) {
        addTimeOut();

        return;
    }
    const dl = [];
    for (const [index, download] of res.entries()) {
        const val = download.value;
        const providers = document.querySelectorAll(`[data-provider-${index}]`);
        const links = document.querySelectorAll(`[data-link-${index}]`);

        const linkprov = [];

        for (const [pi, p] of providers.entries()) {
            linkprov[pi] = {
                provider: p.value,
                link: links[pi].value
            }
        }

        dl.push({
            resolution: val,
            links: linkprov
        })
    }

    const f = new FormData();
    f.append('action', 'kiranime_save_download_batch');
    f.append('data', JSON.stringify(dl));
    f.append('nonce', nonce);
    f.append('id', postId);

    fetch(ajax, {
        body: f,
        method: 'POST'
    }).then(e => e.json()).then(e => saveButton.removeAttribute('disabled'))

    addTimeOut();
}

function setBlockValue(arr) {
    let added = '';
    if (arr && arr.length > 0) {
        for (const [i, d] of arr.entries()) {
            added += /*html*/ `
            <div class="pb-2 mb-3 border-b border-sky-200">
                <div>
                    <div class="flex items-center w-full justify-between">
                        <span
                            class="text-xs font-semibold inline-block py-1 px-2 rounded-t text-sky-600 bg-sky-200 uppercase w-2/12 mr-1 flex-shrink-0">
                            Resolution
                        </span>
                        ${i === '0' ? '':`<span onclick="deletedl(${i})"
                            class="text-xs font-semibold inline-block py-1 px-2 rounded-t text-rose-600 bg-rose-200 uppercase w-2/12 flex-shrink-0 cursor-pointer">
                            Delete
                        </span>`}
                    </div>
                    <div class="mb-3 pt-0 flex-auto">
                            <input data-resolution name="type" type="text" id="type" class=" shadow w-full col-span-1" value="${d.resolution}"/>
                        </div>
                    </div>
                    <div>
                        <span
                            class="text-xs font-semibold inline-block py-1 px-2 rounded-t text-sky-600 bg-sky-200 uppercase w-2/12 mr-1 flex-shrink-0">
                            Provider
                        </span>
                        <div class="mb-3 pt-0 grid lg:grid-cols-5 grid-cols-2">
                            <input data-provider-${i} type="text" name="download_provider_${i}" placeholder="Server name" class="px-3 py-3 placeholder-gray-400 text-blueGray-600 relative bg-white rounded text-sm border-none ring-1 ring-sky-200 shadow outline-none focus:outline-none focus:ring w-full col-span-1" value="${d.links && d.links[0] ? d.links[0].provider : ''}" />
                            <input data-provider-${i} type="text" name="download_provider_${i}" placeholder="Server name" class="px-3 py-3 placeholder-gray-400 text-blueGray-600 relative bg-white rounded text-sm border-none ring-1 ring-sky-200 shadow outline-none focus:outline-none focus:ring w-full col-span-1" value="${d.links && d.links[1] ? d.links[1].provider : ''}" />
                            <input data-provider-${i} type="text" name="download_provider_${i}" placeholder="Server name" class="px-3 py-3 placeholder-gray-400 text-blueGray-600 relative bg-white rounded text-sm border-none ring-1 ring-sky-200 shadow outline-none focus:outline-none focus:ring w-full col-span-1" value="${d.links && d.links[2] ? d.links[2].provider : ''}" />
                            <input data-provider-${i} type="text" name="download_provider_${i}" placeholder="Server name" class="px-3 py-3 placeholder-gray-400 text-blueGray-600 relative bg-white rounded text-sm border-none ring-1 ring-sky-200 shadow outline-none focus:outline-none focus:ring w-full col-span-1" value="${d.links && d.links[3] ? d.links[3].provider : ''}" />
                            <input data-provider-${i} type="text" name="download_provider_${i}" placeholder="Server name" class="px-3 py-3 placeholder-gray-400 text-blueGray-600 relative bg-white rounded text-sm border-none ring-1 ring-sky-200 shadow outline-none focus:outline-none focus:ring w-full col-span-1" value="${d.links && d.links[4] ? d.links[4].provider : ''}" />
                        </div>
                    </div>
                    <div>
                        <span
                            class="text-xs font-semibold inline-block py-1 px-2 rounded-t text-sky-600 bg-sky-200 uppercase w-2/12 mr-1 flex-shrink-0">
                            Download Link
                        </span>
                        <div class="mb-3 pt-0 grid lg:grid-cols-5 grid-cols-2">
                            <input data-link-${i} type="text" name="download_link_${i}" placeholder="Server name" class="px-3 py-3 placeholder-gray-400 text-blueGray-600 relative bg-white rounded text-sm border-none ring-1 ring-sky-200 shadow outline-none focus:outline-none focus:ring w-full col-span-1" value="${d.links && d.links[0] ? d.links[0].link : ''}" />
                            <input data-link-${i} type="text" name="download_link_${i}" placeholder="Server name" class="px-3 py-3 placeholder-gray-400 text-blueGray-600 relative bg-white rounded text-sm border-none ring-1 ring-sky-200 shadow outline-none focus:outline-none focus:ring w-full col-span-1" value="${d.links && d.links[1] ? d.links[1].link : ''}" />
                            <input data-link-${i} type="text" name="download_link_${i}" placeholder="Server name" class="px-3 py-3 placeholder-gray-400 text-blueGray-600 relative bg-white rounded text-sm border-none ring-1 ring-sky-200 shadow outline-none focus:outline-none focus:ring w-full col-span-1" value="${d.links && d.links[2] ? d.links[2].link : ''}" />
                            <input data-link-${i} type="text" name="download_link_${i}" placeholder="Server name" class="px-3 py-3 placeholder-gray-400 text-blueGray-600 relative bg-white rounded text-sm border-none ring-1 ring-sky-200 shadow outline-none focus:outline-none focus:ring w-full col-span-1" value="${d.links && d.links[3] ? d.links[3].link : ''}" />
                            <input data-link-${i} type="text" name="download_link_${i}" placeholder="Server name" class="px-3 py-3 placeholder-gray-400 text-blueGray-600 relative bg-white rounded text-sm border-none ring-1 ring-sky-200 shadow outline-none focus:outline-none focus:ring w-full col-span-1" value="${d.links && d.links[4] ? d.links[4].link : ''}" />
                        </div>
                    </div>
                </div>
            `;
        }
    } else {
        added += /*html*/ `
            <div class="pb-2 mb-3 border-b border-sky-200">
                <div>
                    <div class="flex items-center w-full justify-between">
                        <span
                            class="text-xs font-semibold inline-block py-1 px-2 rounded-t text-sky-600 bg-sky-200 uppercase w-2/12 mr-1 flex-shrink-0">
                            Resolution
                        </span>
                    </div>
                    <div class="mb-3 pt-0 flex-auto">
                            <input data-resolution name="type" type="text" id="type" class="px-3 py-3 placeholder-gray-400 text-blueGray-600 relative bg-white rounded text-sm shadow outline-none focus:outline-none focus:ring w-full" value=""/>
                        </div>
                    </div>
                    <div>
                        <span
                            class="text-xs font-semibold inline-block py-1 px-2 rounded-t text-sky-600 bg-sky-200 uppercase w-2/12 mr-1 flex-shrink-0">
                            Provider
                        </span>
                        <div class="mb-3 pt-0 grid lg:grid-cols-5 grid-cols-2">
                            <input data-provider-0 name="download_provider_0" type="text" placeholder="Server name" class="px-3 py-3 placeholder-gray-400 text-blueGray-600 relative bg-white rounded text-sm border-none ring-1 ring-sky-200 shadow outline-none focus:outline-none focus:ring w-full col-span-1" value="" />
                            <input data-provider-0 name="download_provider_0" type="text" placeholder="Server name" class="px-3 py-3 placeholder-gray-400 text-blueGray-600 relative bg-white rounded text-sm border-none ring-1 ring-sky-200 shadow outline-none focus:outline-none focus:ring w-full col-span-1" value="" />
                            <input data-provider-0 name="download_provider_0" type="text" placeholder="Server name" class="px-3 py-3 placeholder-gray-400 text-blueGray-600 relative bg-white rounded text-sm border-none ring-1 ring-sky-200 shadow outline-none focus:outline-none focus:ring w-full col-span-1" value="" />
                            <input data-provider-0 name="download_provider_0" type="text" placeholder="Server name" class="px-3 py-3 placeholder-gray-400 text-blueGray-600 relative bg-white rounded text-sm border-none ring-1 ring-sky-200 shadow outline-none focus:outline-none focus:ring w-full col-span-1" value="" />
                            <input data-provider-0 name="download_provider_0" type="text" placeholder="Server name" class="px-3 py-3 placeholder-gray-400 text-blueGray-600 relative bg-white rounded text-sm border-none ring-1 ring-sky-200 shadow outline-none focus:outline-none focus:ring w-full col-span-1" value="" />
                        </div>
                    </div>
                    <div>
                        <span
                            class="text-xs font-semibold inline-block py-1 px-2 rounded-t text-sky-600 bg-sky-200 uppercase w-2/12 mr-1 flex-shrink-0">
                            Download Link
                        </span>
                        <div class="mb-3 pt-0 grid lg:grid-cols-5 grid-cols-2">
                            <input data-link-0 type="text" name="download_link_0" placeholder="Download Link" class="px-3 py-3 placeholder-gray-400 text-blueGray-600 relative bg-white rounded text-sm border-none ring-1 ring-sky-200 shadow outline-none focus:outline-none focus:ring w-full col-span-1" value="" />
                            <input data-link-0 type="text" name="download_link_0" placeholder="Download Link" class="px-3 py-3 placeholder-gray-400 text-blueGray-600 relative bg-white rounded text-sm border-none ring-1 ring-sky-200 shadow outline-none focus:outline-none focus:ring w-full col-span-1" value="" />
                            <input data-link-0 type="text" name="download_link_0" placeholder="Download Link" class="px-3 py-3 placeholder-gray-400 text-blueGray-600 relative bg-white rounded text-sm border-none ring-1 ring-sky-200 shadow outline-none focus:outline-none focus:ring w-full col-span-1" value="" />
                            <input data-link-0 type="text" name="download_link_0" placeholder="Download Link" class="px-3 py-3 placeholder-gray-400 text-blueGray-600 relative bg-white rounded text-sm border-none ring-1 ring-sky-200 shadow outline-none focus:outline-none focus:ring w-full col-span-1" value="" />
                            <input data-link-0 type="text" name="download_link_0" placeholder="Download Link" class="px-3 py-3 placeholder-gray-400 text-blueGray-600 relative bg-white rounded text-sm border-none ring-1 ring-sky-200 shadow outline-none focus:outline-none focus:ring w-full col-span-1" value="" />
                        </div>
                    </div>
                </div>
            `;
    }
    wrapper.innerHTML = added;
}
</script>
<?php }

add_action('wp_ajax_kiranime_save_download_batch', 'kiranime_save_download_batch');
function kiranime_save_download_batch()
{
    $params = $_POST;
    if (!wp_verify_nonce($params['nonce'], 'kiranime_save_download_batch')) {
        return wp_send_json_error(['message' => 'Security check fail!']);
        wp_die();
    }

    $dls = stripslashes($params['data']);
    $post_id = $params['id'];

    $updated = update_post_meta($post_id, 'kiranime_download_data', $dls);
    return wp_send_json_success(['data' => $updated]);
    wp_die();

}

add_action('save_post_anime', 'kiranime_save_metadata', 10, 2);
function kiranime_save_metadata($post_id, $post)
{
    $post = get_post($post_id);
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return $post_id;
    }

    $nonce = isset($_POST) && isset($_POST['kiranime_anime_nonce']);
    if (!$nonce || !wp_verify_nonce($_POST['kiranime_anime_nonce'], 'kiranime_anime_save_meta')) {
        return $post_id;
    }

    if (!current_user_can('edit_posts')) {
        return $post_id;
    }

    if ($post && $post->post_type != 'anime') {
        return $post_id;
    }

    $params = $_POST;
    $prefix = 'kiranime_anime_';
    $keys = ['spotlight', 'rate', 'native', 'synonyms', 'aired', 'premiered', 'duration', 'episodes', 'score', 'trailer', 'id', 'service_name'];

    $metas = [
        'kiranime_anime_updated' => time(),
        'bookmark_count' => 0,
    ];

    kiranime_anime_views_add($post_id);

    foreach ($keys as $key) {
        if (isset($params[$prefix . $key])) {
            update_post_meta($post_id, $prefix . $key, $params[$prefix . $key]);
        }
    }

    foreach ($metas as $meta => $value) {
        if (empty(get_post_meta($post_id, $meta, true))) {
            add_post_meta($post_id, $meta, $value);
        }
    }

     /**
     * image auto download for background and featured
     */
    $image =$_POST['kiranime_anime_background'] ? sanitize_text_field($_POST['kiranime_anime_background']) : false;
    $second_img =$_POST['kiranime_anime_featured'] ? sanitize_text_field($_POST['kiranime_anime_featured']) : false;

    $blogurl = get_site_url();
    //Get the remote image and save to uploads directory
    $already_uploaded =strpos($image, $blogurl);
    $featured =strpos($second_img, $blogurl);
    $imgs = [];
    if($image && !$already_uploaded){
        $imgs[] = ['url'=>$image, 'type'=>'background'];
    };
    if($second_img && !$featured){
        $imgs[] = ['url'=>$second_img, 'type'=>'featured'];
    }

    download_images($imgs, $post_id);

    $vote = get_post_meta($post_id, 'kiranime_anime_vote_data', true);

    if (!isset($vote)) {
        add_post_meta($post_id, 'kiranime_anime_vote_data', json_encode([]));
        add_post_meta($post_id, 'kiranime_anime_vote_sum', 0);
    }
}

function download_images($images, $post_id){
    if(!$images){
        return null;
    }
    $upload_dir = wp_upload_dir();
    foreach ($images as $idata) {
        $img_name = time() . '.jpg' . basename($idata['url'], '__kira_thumb');
        $img = wp_remote_get($idata['url']);
        if (is_wp_error($img)) {
            $error_message = $img->get_error_message();
        } else {
            $img = wp_remote_retrieve_body($img);
            $fp = fopen($upload_dir['path'] . '/' . $img_name, 'w');
            fwrite($fp, $img);
            fclose($fp);

            $wp_filetype = wp_check_filetype($img_name, null);
            $attachment = array(
                'post_mime_type' => $wp_filetype['type'],
                'post_title' => preg_replace('/\.[^.]+$/', '', $img_name),
                'post_content' => '',
                'post_status' => 'inherit',
            );

            //require for wp_generate_attachment_metadata which generates image related meta-data also creates thumbs
            require_once ABSPATH . 'wp-admin/includes/image.php';
            $attach_id = wp_insert_attachment($attachment, $upload_dir['path'] . '/' . $img_name, $post_id);
            //Generate post thumbnail of different sizes.
            $attach_data = wp_generate_attachment_metadata($attach_id, $upload_dir['path'] . '/' . $img_name);
            wp_update_attachment_metadata($attach_id, $attach_data);

            if ($idata['type'] === 'featured') {
                //Set as featured image.
                delete_post_meta($post_id, '_thumbnail_id');
                add_post_meta($post_id, '_thumbnail_id', $attach_id, true);
            } else {
                $attach_url = wp_get_attachment_url($attach_id);
                // update Background image
                delete_post_meta($post_id, 'kiranime_anime_background');
                add_post_meta($post_id, 'kiranime_anime_background', $attach_url);
            }
        }
    }
}

function kiranime_add_metabox_html($post)
{
    $prefix = 'kiranime_anime_';
    $keys = ['spotlight', 'rate', 'native', 'synonyms', 'aired', 'premiered', 'duration', 'episodes', 'score', 'trailer', 'featured', 'background'];
    $vals = [];

    wp_enqueue_style('kiranime-admin-css', get_stylesheet_directory_uri() . '/css/app.css');
    foreach ($keys as $key) {
        $meta_key = $prefix . $key;

        $vals[$meta_key] = get_post_meta($post->ID, $meta_key, true);
    }?>

<div class="w-full h-auto bg-white space-y-1">
    <?php wp_nonce_field('kiranime_anime_save_meta', 'kiranime_anime_nonce')?>
    <?php
foreach ($vals as $key => $val): ?>

    <?php if ($key != 'kiranime_anime_spotlight') {?>
    <div class="w-full h-auto p-2 lg:flex items-center space-y-1"
        <?php if($key == 'kiranime_anime_featured'){echo 'style="display:none;"';}?>>
        <label for="<?php echo $key; ?>"
            class="text-xs font-medium uppercase text-gray-800 active:text-gray-900 hover:text-gray-900 focus-within:text-gray-900 min-w-max lg:w-2/12 flex-shrink-0"><?php echo str_replace($prefix, '', $key); ?></label>
        <input type="text" name="<?php echo $key; ?>" id="<?php echo $key; ?>"
            class="px-4 py-2 text-sm font-normal text-gray-900 flex-auto" value="<?php echo $val; ?>">
    </div>
    <?php } else {?>
    <div class="w-full h-auto p-2 lg:flex items-center space-y-1">
        <label for="<?php echo $key; ?>"
            class="text-xs font-medium uppercase text-gray-800 active:text-gray-900 hover:text-gray-900 focus-within:text-gray-900 min-w-max lg:w-2/12 flex-shrink-0"><?php echo str_replace($prefix, '', $key); ?></label>
        <select name="<?php echo $key; ?>" id="<?php echo $key; ?>">
            <?php if (!is_null($val)) {?>
            <option value="true" <?php if ($key == 'true') {echo 'selected';}?>>Yes</option>
            <option value="false" <?php if ($key == 'false') {echo 'selected';}?>>No</option>
            <?php } else {?>
            <option value="true">Yes</option>
            <option value="false" selected>No</option>
            <?php }?>
        </select>
    </div>
    <?php }?>
    <?php endforeach;
    ?>
</div>
<?php
}
function kiranime_add_fetch_metabox($post_id, $post)
{
    $prefix = 'kiranime_anime_';
    $value = '';

    $saved = $post_id ? get_post_meta($post_id, $prefix . 'id', true) : false;
    $server = $post_id ? get_post_meta($post_id, $prefix . 'service_name', true) : false;
    if ($saved) {
        $value = $saved;
    }?>
<div class="w-full h-auto bg-white space-y-1">
    <span data-notifications class="w-full block h-auto p-2 lg:flex items-center space-y-1 text-rose-600">

    </span>
    <div class="w-full h-auto p-2 lg:flex items-center space-y-1">
        <label for="kiranime_anime_service_name"
            class="text-xs font-medium uppercase text-gray-800 active:text-gray-900 hover:text-gray-900 focus-within:text-gray-900 min-w-max lg:w-2/12 flex-shrink-0">Choose
            Service</label>
        <select name="kiranime_anime_service_name" id="kiranime_anime_service_name">
            <option value="tmdb" <?php if ($server == 'tmdb') {echo 'selected';}?>>TMDB</option>
            <option value="mal" <?php if ($server == 'mal' || !$server) {echo 'selected';}?>>MAL</option>
        </select>
    </div>
    <div class="w-full h-auto p-2 lg:flex items-center space-y-1 gap-2">
        <label for="kiranime_anime_id"
            class="text-xs font-medium uppercase text-gray-800 active:text-gray-900 hover:text-gray-900 focus-within:text-gray-900 min-w-max lg:w-2/12 flex-shrink-0">Anime
            ID</label>
        <input type="text" name="kiranime_anime_id" id="kiranime_anime_id"
            class="px-4 py-2 text-sm font-normal text-gray-900 flex-auto lg:w-8/12" value="<?php echo $value; ?>">
        <input type="button" name="get-anime" id="get-anime"
            class="px-4 py-2 text-sm font-normal cursor-pointer lg:w-2/12 text-white bg-sky-600 flex-auto"
            title="Get Anime" value="Get Anime" />
    </div>
</div>
<script>
const keys = JSON.stringify({
    'tmdb': "<?php echo get_option('__a_tmdb'); ?>",
    'mal': `<?php if (get_option('__a_mal')) {echo get_option('__a_mal');} else {echo 'https://api.jikan.moe/v4';}
    ;?>`
})

function getDataObject(obj, path) {
    let undef;
    path = path.split('.');
    while (obj && path[0]) obj = obj[path.shift()] || undef;

    if (obj === undef || path[0]) {
        return undefined;
    }

    return obj;
}
document
    .querySelector('input#get-anime')
    .addEventListener('click', async (e) => {
        e.preventDefault();
        const value = document.querySelector('input#kiranime_anime_id').value;
        const service = document.querySelector('select#kiranime_anime_service_name').value;
        const apis = keys ?
            JSON.parse(keys) : {
                tmdb: null,
                mal: 'https://api.jikan.moe/v4',
            };
        if (!apis[service]) {
            document.querySelector(
                '[data-notifications]'
            ).textContent = `Please make sure you've enter your ${
				service ? service.toUpperCase() : 'Service'
			} API Key in the setting.`;
        }
        let url;
        switch (service) {
            case 'tmdb':
                url = `https://api.themoviedb.org/3/tv/${value}?api_key=${apis[service]}&language=en-US`;
                break;
            case 'mal':
                url = `${apis['mal']}/anime/${value}`;
                break;
        }
        const fieldMatchMAL = {
            rate: 'rating',
            title: 'title',
            native: 'title_japanese',
            aired: ['aired', 'string'],
            premiered: ['season', 'year'],
            duration: 'duration',
            episodes: 'episodes',
            score: 'score',
            synopsis: 'synopsis',
            synonyms: 'title_synonyms',
            trailer: ['trailer', 'embed_url'],
        };
        const fieldMatchTMDB = {
            title: 'name',
            native: 'original_name',
            aired: 'first_air_date',
            duration: 'duration',
            episodes: 'number_of_episodes',
            score: 'vote_average',
            synopsis: 'overview',
            background: 'backdrop_path'
        };
        const prefix = 'kiranime_anime_';
        const data = [];
        try {
            const get = await fetch(url);
            const json = await get.json();
            const fordata = service === 'mal' ? fieldMatchMAL : fieldMatchTMDB;
            const source = service === 'mal' ? json.data : json;
            for (const f of Object.keys(fordata)) {
                const name = f.match(/title|synopsis/gi) ? f : prefix + f;
                if (service === 'mal') {
                    if (f === 'premiered') {
                        data.push({
                            name,
                            value: source[fordata[f][0]] + ' ' + source[fordata[f][1]],
                        });

                        continue;
                    }

                    if (f === 'synonyms') {
                        data.push({
                            name,
                            value: source[fordata[f]].join(', '),
                        });

                        continue;
                    }
                }
                if (typeof fordata[f] === 'string') {
                    data.push({
                        name,
                        value: source[fordata[f]]
                    });
                } else {
                    const d = getDataObject(source, fordata[f].join('.'));
                    data.push({
                        name,
                        value: d,
                    });
                }
            }
            for (const d of data) {
                if (!d.value) continue;
                if (d.name === 'synopsis') {
                    document.querySelector('#content-html').click()
                    document.querySelector('#content').value = d.value
                    continue;
                }
                if (service !== 'tmdb') {
                    if (d.name === 'kiranime_anime_background' || d.name === 'kiranime_anime_featured') {
                        document.querySelector(`input#${d.name}`).value =
                            'https://www.themoviedb.org/t/p/original' + d.value;
                    }
                }
                document.querySelector(`input#${d.name}`).value = d.value;
            }
        } catch (error) {
            document.querySelector(
                '[data-notifications]'
            ).textContent = `Error occured.., I cannot continue. Please send this to the author: ${error}`;
        }
    });
</script>
<?php

}