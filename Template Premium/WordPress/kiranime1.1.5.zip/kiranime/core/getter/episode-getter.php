<?php

/**
 * get latest episodes
 */

function kiranime_get_latest_episode(int $anime_id)
{
    $latest = get_posts([
        'post_type' => 'episode',
        'post_status' => 'publish',
        'order' => 'DESC',
        'orderby' => 'meta_value_num',
        'meta_key' => 'kiranime_episode_number',
        'posts_per_page' => 1,
        'meta_query' => [
            [
                'key' => 'kiranime_episode_parent_id',
                'value' => $anime_id,
            ],
        ],
    ]);

    if (!$latest || count($latest) == 0) {
        return null;
    }

    return [
        "metadata" => kiranime_get_episode_metadata($latest[0]->ID),
        'title' => $latest[0]->post_title,
        'featured' => get_the_post_thumbnail_url($latest[0]->ID, 'episode-image'),
        'url' => "/watch/" . $latest[0]->post_name,
    ];

}

/**
 * Get future episode for scheduled
 *
 * @param bool $getter is this called directly or via ajax request. default false for ajax request.
 * @param int $total total episode to get.
 * @param string $day the day date
 * @param string $month the month
 * @param string $year the year
 *
 * @return Array|json array for direct call. json for ajax request.
 */
function kiranime_get_future_episode(bool $getter = false, string $day = null, string $month = null, string $year = null, int $total = 12)
{
    $params = $_POST;
    $checked_nonce = $params['nonce'] && wp_verify_nonce($params['nonce'], 'kiranime_homepage_nonce');
    if (!$getter && !$checked_nonce) {
        return wp_send_json_error(['message' => 'Security Check failed!']);
        wp_die();
    }
    $day = $day ? $day : date('j');
    $month = $month ? $month : date('n');
    $year = $year ? $year : date('Y');

    $total_posts = isset($params['total']) ? $params['total'] : $total;
    $posts = get_posts([
        'post_type' => 'episode',
        'post_status' => 'future',
        'order' => 'ASC',
        'orderby' => 'date',
        'posts_per_page' => $total_posts,
        'date_query' => [
            [
                'year' => $params['year'] ? $params['year'] : $year,
                'month' => $params['month'] ? $params['month'] : $month,
                'day' => $params['day'] ? $params['day'] : $day,
                'compare' => '=',
            ],
        ],
    ]);

    $result = [];

    foreach ($posts as $post) {
        $result[] = [
            'meta' => kiranime_get_episode_metadata($post->ID),
            'title' => $post->post_title,
            'scheduled' => $post->post_date,
            'id' => $post->ID,
        ];
    }

    if ($getter) {
        return $result;
    } else {
        return wp_send_json_success($result, 200);
        wp_die();
    }

}
add_action('wp_ajax_kiranime_get_future_episode', 'kiranime_get_future_episode');
add_action('wp_ajax_nopriv_kiranime_get_future_episode', 'kiranime_get_future_episode');

/**
 * Get animes episode list
 *
 * @param int $anime anime id
 * @return Array
 */
function kiranime_get_episode_list(int $anime)
{
    $episodes = get_posts([
        'post_type' => 'episode',
        'post_status' => 'publish',
        'order' => 'DESC',
        'orderby' => 'meta_value_num',
        'meta_key' => 'kiranime_episode_number',
        'meta_query' => [
            [
                'key' => 'kiranime_episode_parent_id',
                'value' => $anime,
                'compare' => '=',
            ],
        ],
        'posts_per_page'=> -1
    ]);

    $result = [];
    if ($episodes):
        foreach ($episodes as $episode):
            $result[] = [
                'title' => $episode->post_title,
                'metadata' => kiranime_get_episode_metadata($episode->ID),
                'id' => $episode->ID,
                'url' => get_post_permalink($episode->ID),
            ];
        endforeach;
    endif;

    return $result;
}

function kiranime_get_next_episode($animeId)
{
    if (!$animeId) {
        return false;
    }

    $episode = get_posts([
        'post_type' => 'episode',
        'post_status' => 'future',
        'meta_query' => [
            [
                'key' => 'kiranime_episode_parent_id',
                'value' => $animeId,
                'compare' => '=',
            ],
        ],
        'posts_per_page' => 1,
        'no_found_rows' => true,
    ]);

    if (count($episode) < 0) {
        return false;
    }

    return [
        'scheduled' => isset($episode[0]->post_date_gmt) ? $episode[0]->post_date_gmt : '',
    ];
}