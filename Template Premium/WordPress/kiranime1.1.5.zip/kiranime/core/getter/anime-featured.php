<?php

/**
 * get featured anime
 *
 * @param string $type Featured type. default 'airing'.
 * @param int $total Anime to get. default 7.
 *
 * @return \WP_Query return wp_query object;
 */
function kiranime_get_anime_featured(string $type = 'airing', int $total = 7)
{
    $queries = [
        'airing' => [
            'post_type' => 'anime',
            'post_status' => 'publish',
            'order' => 'DESC',
            'orderby' => 'meta_value_num',
            'meta_key' => date('mY') . '_kiranime_views',
            'posts_per_page' => $total ? $total : 7,
            'no_found_rows' => true,
            'tax_query' => [
                [
                    'taxonomy' => 'status',
                    'field' => 'slug',
                    'terms' => ['airing'],
                ],
            ],
        ],
        'favorite' => [
            'post_type' => 'anime',
            'post_status' => 'publish',
            'order' => 'DESC',
            'orderby' => 'meta_value_num',
            'meta_key' => 'bookmark_count',
            'posts_per_page' => $total ? $total : 7,
            'no_found_rows' => true,
        ],
        'popular' => [
            'post_type' => 'anime',
            'post_status' => 'publish',
            'order' => 'DESC',
            'orderby' => 'meta_value_num',
            'meta_key' => 'total_kiranime_views',
            'posts_per_page' => $total ? $total : 7,
            'no_found_rows' => true,
            'tax_query' => [
                [
                    'taxonomy' => 'status',
                    'field' => 'slug',
                    'terms' => ['airing', 'completed'],
                ],
            ],
        ],
    ];

    return new WP_Query($queries[$type]);
}