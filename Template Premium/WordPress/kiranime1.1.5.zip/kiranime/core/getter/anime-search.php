<?php

/**
 * search anime by title
 */

add_action('wp_ajax_kiranime_get_anime_title', 'kiranime_get_anime_title');
function kiranime_get_anime_title()
{
    global $wpdb;
    $params = $_POST;

    if (!$params['query']) {
        return wp_send_json_success([], 200);
        wp_die();
    }

    $q = $wpdb->prepare("SELECT * FROM $wpdb->posts WHERE `post_title` LIKE %s AND `post_type` = %s", '%' . $wpdb->esc_like($params['query']) . '%', 'anime');

    $posts = $wpdb->get_results($q);

    if (!$posts) {
        return wp_send_json_success([], 200);
        wp_die();
    }

    $result = [];
    foreach ($posts as $post) {
        $result[] = [
            'title' => $post->post_title,
            'id' => $post->ID,
            'slug' => $post->post_name,
        ];
    }

    return wp_send_json_success($result, 200);
    wp_die();

}

function kiranime_get_anime_by_parent_id(int $parent)
{
    $anime = get_post($parent);
    $meta = kiranime_get_anime_meta($parent);
    $type = wp_get_post_terms($parent, 'type');
    $attr = wp_get_post_terms($parent, 'anime_attribute');
    $result = [
        'title' => $anime->post_title,
        'synopsis' => $anime->post_content,
        'url' => get_post_permalink($parent),
        'featured' => get_the_post_thumbnail_url($parent, 'full'),
        'metadata' => $meta,
        'type' => !is_wp_error($type) && count($type) != 0 ? $type[0] : null,
        'attribute' => !is_wp_error($attr) ? $attr : [],
        'episodes' => kiranime_get_episode_list($parent),
        'id' => $anime->ID,
    ];

    return $result;
}

function kiranime_get_anime_by_letter(string $letter, int $page, int $limit)
{
    global $wpdb;

    $params = '';

    if ($letter == '0-9') {
        $params = "^[0-9]";
    } else if ($letter == 'other') {
        $params = "^[^a-zA-Z0-9]";
    } else if ($letter != 'All') {
        $params = "^[" . strtolower($letter) . $letter . "]";
    }

    $currentpage = $page - 1;

    add_filter('posts_where', 'search_title_regex', 10, 2);
    $main = new WP_Query([
        'search_title' => $params,
        'post_type' => 'anime',
        'post_status' => 'publish',
        'order' => 'ASC',
        'orderby' => 'title',
        'posts_per_page' => $limit,
        'paged' => $currentpage,
    ]);
    remove_filter('posts_where', 'search_title_regex', 10, 2);

    return $main;
}

/**
 * regex filter
 */
function search_title_regex($where, $wp_query)
{
    global $wpdb;
    if ($search_term = $wp_query->get('search_title')) {
        $where .= ' AND ' . $wpdb->posts . '.post_title REGEXP ' . "'" . $search_term . "'";
    }
    return $where;
}

add_action('wp_ajax_nopriv_kiranime_ajax_search', 'kiranime_ajax_search');
add_action('wp_ajax_kiranime_ajax_search', 'kiranime_ajax_search');
function kiranime_ajax_search()
{
    $query = isset($_POST) ? $_POST['q'] : '';

    if (!$query) {
        return wp_send_json_success(['status' => false], 200);
        wp_die();
    }

    $search = get_posts([
        'post_type' => 'anime',
        'post_status' => 'publish',
        's' => $query,
        'posts_per_page' => 5,
    ]);
    $data = '';
    foreach ($search as $post) {
        $link = get_post_permalink($post);
        $featured = get_the_post_thumbnail_url($post, 'trending-image');
        $meta = kiranime_get_anime_meta($post->ID);
        $type = wp_get_post_terms($post->ID, 'type');
        $type = is_wp_error($type) ? 'TV' : $type[0]->name;
        $released = isset($meta) && isset($meta['aired']) ? $meta['aired'] : '?';
        $duration = isset($meta) && isset($meta['duration']) ? $meta['duration'] : '24m';
        $en = isset($meta) && isset($meta['native']) ? $meta['native'] : '-';
        $data .= '<a href="' . $link . '" class="w-full p-2 border-b border-dashed border-gray-400 border-opacity-30 flex gap-2">
        <div class="pb-17 relative overflow-hidden w-12 md:w-1/5 flex-shrink-0 flex-grow-0">
            <img alt="' . $post->post_title . '" src="' . $featured . '" class="w-full h-full inset-0 absolute object-cover">
        </div>
        <div class="flex-auto group">
            <h3 class="text-sm font-semibold line-clamp-1 leading-6 group-hover:text-sky-400">' . $post->post_title . '</h3>
            <div class="text-xs text-opacity-90 line-clamp-1">' . $en . '</div>
            <div class="flex items-center gap-1 text-xs">
                <span>' . $released . '</span><i class="dot"></i>' . $type . '<i class="dot"></i><span>' . $duration . '</span>
            </div>
        </div>
    </a>';
    }

    return wp_send_json_success($data);
    wp_die();
}