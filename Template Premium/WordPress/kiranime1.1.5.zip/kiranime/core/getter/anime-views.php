<?php

/**
 * set, get anime views by day, week, month
 *
 * @package kiranime
 */

/**
 * Add anime views.
 */
function kiranime_anime_views_add(int $post_id)
{
    $suffix = '_kiranime_views';
    $screens = [
        'day' => date('dmY') . $suffix,
        'week' => date('WY') . $suffix,
        'month' => date('mY') . $suffix,
        'total' => 'total' . $suffix,
    ];
    foreach ($screens as $screen => $data) {
        if (!get_post_meta($post_id, $data, true)) {
            add_post_meta($post_id, $data, 0);
        } else {
            update_post_meta($post_id, $data, 0);
        }
    }
}

/**
 * get anime views
 *
 * @param int $post_id  The post ID.
 */
function kiranime_anime_views_get(int $post_id, string $type = 'day')
{
    $suffix = '_kiranime_views';
    $meta_key = '';

    if ($type == 'month') {
        $meta_key = date('mY') . $suffix;
    } elseif ($type == 'week') {
        $meta_key = date('WY') . $suffix;
    } elseif ($type == 'day') {
        $meta_key = date('dmY') . $suffix;
    } else {
        $meta_key = 'total' . $suffix;
    }

    if ($meta_key) {
        return get_post_meta($post_id, $meta_key, true);
    } else {
        return false;
    }
}

/**
 * set anime views
 *
 * Will add 1 to current value if exist, create with 1 value if not exist.
 */
add_action('kira_add_view', 'kiranime_anime_views_set', 10, 1);
function kiranime_anime_views_set(int $post_id)
{
    $suffix = '_kiranime_views';
    $dates = [
        'day' => date('dmY') . $suffix,
        'week' => date('WY') . $suffix,
        'month' => date('mY') . $suffix,
        'total' => 'total' . $suffix,
    ];

    foreach ($dates as $date => $value) {
        $current = kiranime_anime_views_get($post_id, $date);
        if ($current) {
            update_post_meta($post_id, $value, $current + 1);
        } else {
            update_post_meta($post_id, $value, 1);
        }
    }
}

/**
 * get by view
 */

function kiranime_get_anime_by_view(string $type, int $total = 10)
{
    $suffix = '_kiranime_views';
    $meta_key = '';

    if ($type == 'month') {
        $meta_key = date('mY') . $suffix;
    } elseif ($type == 'week') {
        $meta_key = date('WY') . $suffix;
    } elseif ($type == 'total') {
        $meta_key = 'total' . $suffix;
    } else {
        $meta_key = date('dmY') . $suffix;
    }

    $args = [
        'post_type' => 'anime',
        'post_status' => 'publish',
        'order' => 'DESC',
        'orderby' => 'meta_value_num',
        'meta_key' => $meta_key,
        'no_found_rows' => true,
        'posts_per_page' => $total,
    ];

    $queried = get_posts($args);
    $results = [];

    foreach ($queried as $index => $value) {
        $results[] = [
            'featured' => get_the_post_thumbnail_url($value->ID, 'featured-image'),
            'index' => $index,
            'title' => $value->post_title,
            'views' => get_post_meta($value->ID, $meta_key, true),
            'type' => wp_get_post_terms($value->ID, 'type'),
            'meta' => kiranime_get_anime_meta($value->ID),
            'slug' => $value->post_name,
            'id' => $value->ID,
            'url' => get_post_permalink($value->ID),
        ];
    }

    return $results;
}

/**
 * add vote to anime
 */
add_action('wp_ajax_kiranime_add_vote', 'kiranime_set_vote_anime');
function kiranime_set_vote_anime()
{
    $user = get_current_user_id();
    $params = $_POST;

    if (!$user) {
        return wp_send_json_error(['message' => 'User must be Logged In!'], 403);
        wp_die();
    }

    if (!wp_verify_nonce($params['nonce'], 'kiranime_set_vote_anime')) {
        return wp_send_json_error(['message' => 'Security Check fail!'], 400);
        wp_die();
    }

    $anime_vote_data = get_post_meta($params['id'], 'kiranime_anime_vote_data', true);
    $result = [];

    if ($anime_vote_data && $anime_vote_data != '[]') {
        $data = json_decode($anime_vote_data);
        $total_voted = 0;
        $calculated = 0;
        $filter = array_filter($data, function ($val) use (&$user) {
            return $val->user == $user;
        });

        if (count($filter) == 0) {
            $data[] = [
                'user' => $user,
                'value' => (int) $params['value'],
            ];
        } else {
            $data = array_map(function ($val) use (&$user, &$params) {
                if ($val->user == $user) {
                    return [
                        'user' => $user,
                        'value' => (int) $params['value'],
                    ];
                } else {
                    return $val;
                }
            }, $data);
        }

        $total_voted = count($data);
        foreach ($data as $vote) {
            $v = isset($vote->value) ? $vote->value : $vote['value'];
            $calculated = $calculated + $v;
        }

        update_post_meta($params['id'], 'kiranime_anime_vote_data', json_encode($data));
        update_post_meta($params['id'], 'kiranime_anime_vote_sum', round($calculated / $total_voted, 2));
        $result = [
            'voted' => $total_voted,
            'vote_score' => round($calculated / $total_voted, 2),
        ];
    } else {
        $data = [];
        $data[] = [
            'user' => $user,
            'value' => (int) $params['value'],
        ];
        update_post_meta($params['id'], 'kiranime_anime_vote_data', json_encode($data));
        update_post_meta($params['id'], 'kiranime_anime_vote_sum', (int) $params['value']);
        $result = [
            'voted' => 1,
            'vote_score' => (int) $params['value'],
        ];
    }
    return wp_send_json_success($result, 200);
    wp_die();
}

function kiranime_get_vote_data(int $anime_id)
{
    $sum = get_post_meta($anime_id, 'kiranime_anime_vote_sum', true);
    $voted = get_post_meta($anime_id, 'kiranime_anime_vote_data', true);
    $voted = isset($voted) && $voted != '[]' ? json_decode($voted) : [];
    return [
        'vote_score' => isset($sum) ? $sum : 0,
        'voted' => isset($voted) && !empty($voted) ? count($voted) : 0,
    ];
}

/**
 * check if current anime is already voted
 *
 * @param int $anime anime Id to check againts
 *
 */

function kiranime_check_is_voted(int $anime)
{
    $user = get_current_user_id();
    if (!$user) {
        return ['status' => false];
    }

    $data = get_post_meta($anime, 'kiranime_anime_vote_data', true);
    $data = isset($data) && $data != '[]' ? json_decode($data) : [];
    $search = isset($data) && !empty($data) ? array_values(array_filter($data, function ($val) use ($user) {
        return $val->user == $user;
    })) : [];

    if ($search && count($search) > 0) {
        return [
            'status' => true,
            'vote_data' => $search[0],
        ];
    } else {
        return [
            'status' => false,
            'vote_data' => false,
        ];
    }

}

function kiranime_get_vote_html($anime_id)
{
    $check = kiranime_check_is_voted($anime_id);
    $arr = [
        '1' => '<svg class="w-8 h-8" viewBox="0 0 72 72" xmlns="http://www.w3.org/2000/svg">
        <g>
            <path fill="#FCEA2B"
                d="M36,13c-12.6823,0-23,10.3177-23,23c0,12.6822,10.3177,23,23,23c12.6822,0,23-10.3178,23-23 C59,23.3177,48.6822,13,36,13z" />
        </g>
        <g id="hair" />
        <g id="skin" />
        <g id="skin-shadow" />
        <g id="line">
            <circle cx="36" cy="36" r="23" fill="none" stroke="#000000" stroke-miterlimit="10"
                stroke-width="2" />
            <line x1="27" x2="45" y1="43" y2="43" fill="none" stroke="#000000"
                stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10"
                stroke-width="2" />
            <line x1="25" x2="30" y1="31" y2="31" fill="none" stroke="#000000"
                stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10"
                stroke-width="2" />
            <line x1="43" x2="48" y1="31" y2="31" fill="none" stroke="#000000"
                stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10"
                stroke-width="2" />
        </g>
    </svg>',
        '2' => '<svg class="w-8 h-8" viewBox="0 0 72 72" xmlns="http://www.w3.org/2000/svg">
    <g>
        <circle cx="36.0001" cy="36" r="22.9999" fill="#FCEA2B" />
    </g>
    <g id="hair" />
    <g id="skin" />
    <g id="skin-shadow" />
    <g id="line">
        <circle cx="36" cy="36" r="23" fill="none" stroke="#000000" stroke-linecap="round"
            stroke-linejoin="round" stroke-width="2" />
        <path fill="none" stroke="#000000" stroke-linecap="round" stroke-linejoin="round"
            stroke-width="2"
            d="M45.8149,44.9293 c-2.8995,1.6362-6.2482,2.5699-9.8149,2.5699s-6.9153-0.9336-9.8149-2.5699" />
        <path
            d="M30,31c0,1.6568-1.3448,3-3,3c-1.6553,0-3-1.3433-3-3c0-1.6552,1.3447-3,3-3C28.6552,28,30,29.3448,30,31" />
        <path
            d="M48,31c0,1.6568-1.3447,3-3,3s-3-1.3433-3-3c0-1.6552,1.3447-3,3-3S48,29.3448,48,31" />
    </g>
</svg>',
        '3' => '<svg class="w-8 h-8" viewBox="0 0 72 72" xmlns="http://www.w3.org/2000/svg">
<g>
    <circle cx="36" cy="36" r="23" fill="#fcea2b" />
    <path fill="#fff"
        d="M50.595,41.64a11.5554,11.5554,0,0,1-.87,4.49c-12.49,3.03-25.43.34-27.49-.13a11.4347,11.4347,0,0,1-.83-4.36h.11s14.8,3.59,28.89.07Z" />
    <path fill="#ea5a47"
        d="M49.7251,46.13c-1.79,4.27-6.35,7.23-13.69,7.23-7.41,0-12.03-3.03-13.8-7.36C24.2951,46.47,37.235,49.16,49.7251,46.13Z" />
</g>
<g id="hair" />
<g id="skin" />
<g id="skin-shadow" />
<g id="line">
    <circle cx="36" cy="36" r="23" fill="none" stroke="#000" stroke-linecap="round"
        stroke-linejoin="round" stroke-width="2" />
    <ellipse cx="28.5684" cy="30.818" rx="3" ry="5.4038" />
    <ellipse cx="43.4316" cy="30.8216" rx="3" ry="5.4038" />
    <path fill="none" stroke="#000" stroke-linecap="round" stroke-linejoin="round"
        stroke-width="2"
        d="M50.595,41.64a11.5554,11.5554,0,0,1-.87,4.49c-12.49,3.03-25.43.34-27.49-.13a11.4347,11.4347,0,0,1-.83-4.36h.11s14.8,3.59,28.89.07Z" />
    <path fill="none" stroke="#000" stroke-linecap="round" stroke-linejoin="round"
        stroke-width="2"
        d="M49.7251,46.13c-1.79,4.27-6.35,7.23-13.69,7.23-7.41,0-12.03-3.03-13.8-7.36C24.2951,46.47,37.235,49.16,49.7251,46.13Z" />
</g>
</svg>',
        '4' => '<svg class="w-8 h-8" viewBox="0 0 72 72" xmlns="http://www.w3.org/2000/svg">
<g>
    <circle cx="36" cy="36" r="23" fill="#fcea2b" />
    <path fill="#fff"
        d="M50.595,41.64a11.5554,11.5554,0,0,1-.87,4.49c-12.49,3.03-25.43.34-27.49-.13a11.4347,11.4347,0,0,1-.83-4.36h.11s14.8,3.59,28.89.07Z" />
    <path fill="#fff"
        d="M49.7251,46.13c-1.79,4.27-6.35,7.23-13.69,7.23-7.41,0-12.03-3.03-13.8-7.36C24.2951,46.47,37.235,49.16,49.7251,46.13Z" />
</g>
<g id="hair" />
<g id="skin" />
<g id="skin-shadow" />
<g id="line">
    <circle cx="36" cy="36" r="23" fill="none" stroke="#000" stroke-linecap="round"
        stroke-linejoin="round" stroke-width="2" />
    <path fill="none" stroke="#000" stroke-linecap="round" stroke-linejoin="round"
        stroke-width="2"
        d="M50.595,41.64a11.5554,11.5554,0,0,1-.87,4.49c-12.49,3.03-25.43.34-27.49-.13a11.4347,11.4347,0,0,1-.83-4.36h.11s14.8,3.59,28.89.07Z" />
    <path fill="none" stroke="#000" stroke-linecap="round" stroke-linejoin="round"
        stroke-width="2"
        d="M49.7251,46.13c-1.79,4.27-6.35,7.23-13.69,7.23-7.41,0-12.03-3.03-13.8-7.36C24.2951,46.47,37.235,49.16,49.7251,46.13Z" />
    <path fill="none" stroke="#000" stroke-linecap="round" stroke-miterlimit="10"
        stroke-width="2" d="M31.6941,32.4036a4.7262,4.7262,0,0,0-8.6382,0" />
    <path fill="none" stroke="#000" stroke-linecap="round" stroke-miterlimit="10"
        stroke-width="2" d="M48.9441,32.4036a4.7262,4.7262,0,0,0-8.6382,0" />
</g>
</svg>',
        '5' => '<svg class="w-8 h-8" viewBox="0 0 72 72" xmlns="http://www.w3.org/2000/svg">
<g>
    <circle cx="36" cy="36" r="23" fill="#FCEA2B" />
    <path fill="#D22F27"
        d="M26.4992,27.4384c-1.2653-3.3541-6.441-3.5687-6.1168,1.3178c0.0431,0.6485,0.281,1.2724,0.6414,1.8135 l5.3179,6.4224l0,0l5.2212-6.266c0.5796-0.6964,0.9224-1.5779,0.905-2.4853c-0.0863-4.3523-5.0509-4.0351-6.1274-0.8036" />
    <path fill="#D22F27"
        d="M45.8012,27.4384c-1.2547-3.3541-6.3873-3.5687-6.0658,1.3178c0.0428,0.6485,0.2787,1.2724,0.6361,1.8135 l5.2737,6.4224l0,0l5.1777-6.266c0.5747-0.6964,0.9147-1.5779,0.8974-2.4853c-0.0856-4.3523-5.0089-4.0351-6.0763-0.8036" />
    <path fill="#FFFFFF"
        d="M48.5859,42.6735c0,5.6296-4.1784,10.1046-12.5541,10.1046c-8.3738,0-12.6069-4.4888-12.6069-10.1047 C23.4249,42.6734,36.4503,45.7045,48.5859,42.6735z" />
</g>
<g id="hair" />
<g id="skin" />
<g id="skin-shadow" />
<g id="line">
    <path fill="none" stroke="#000000" stroke-linecap="round" stroke-linejoin="round"
        stroke-miterlimit="10" stroke-width="2" d="M48.1113,44.5467" />
    <path fill="none" stroke="#000000" stroke-linecap="round" stroke-linejoin="round"
        stroke-miterlimit="10" stroke-width="2" d="M23.934,44.5467" />
    <circle cx="36" cy="36" r="23" fill="none" stroke="#000000" stroke-linecap="round"
        stroke-linejoin="round" stroke-miterlimit="10" stroke-width="2" />
    <path fill="none" stroke="#000000" stroke-linecap="round" stroke-linejoin="round"
        stroke-miterlimit="10" stroke-width="2"
        d="M48.5859,42.6735c0,5.6296-4.1784,10.1046-12.5541,10.1046c-8.3738,0-12.6069-4.4888-12.6069-10.1047 C23.4249,42.6734,36.4503,45.7045,48.5859,42.6735z" />
    <path fill="none" stroke="#000000" stroke-linecap="round" stroke-linejoin="round"
        stroke-miterlimit="10" stroke-width="2"
        d="M26.4992,27.4384c-1.2653-3.3541-6.441-3.5687-6.1168,1.3178c0.0431,0.6485,0.281,1.2724,0.6414,1.8135l5.3179,6.4224l0,0 l5.2212-6.266c0.5796-0.6964,0.9224-1.5779,0.905-2.4853c-0.0863-4.3523-5.0509-4.0351-6.1274-0.8036" />
    <path fill="none" stroke="#000000" stroke-linecap="round" stroke-linejoin="round"
        stroke-miterlimit="10" stroke-width="2"
        d="M45.8012,27.4384c-1.2547-3.3541-6.3873-3.5687-6.0658,1.3178c0.0428,0.6485,0.2787,1.2724,0.6361,1.8135l5.2737,6.4224l0,0 l5.1777-6.266c0.5747-0.6964,0.9147-1.5779,0.8974-2.4853c-0.0856-4.3523-5.0089-4.0351-6.0763-0.8036" />
</g>
</svg>',
    ];

    $result = '';
    foreach ($arr as $key => $val):
        if (empty($check['vote_data'])) {
            $result .= '<span data-vote-anime="' . $key . '" data-vote-anime-id="' . $anime_id . '"class="p-2 w-1/5 hover:bg-white hover:bg-opacity-10 cursor-pointer flex items-center justify-center ">' . $val . '</span>';
        } else {
            if ($key == $check['vote_data']->value) {
                $result .= '<span data-vote-anime="' . $key . '" data-vote-anime-id="' . $anime_id . '"class="p-2 w-1/5 bg-white bg-opacity-20 cursor-pointer flex items-center justify-center ">' . $val . '</span>';
            } else {
                $result .= '<span data-vote-anime="' . $key . '" data-vote-anime-id="' . $anime_id . '"class="p-2 w-1/5 hover:bg-white hover:bg-opacity-10 opacity-30 cursor-pointer flex items-center justify-center ">' . $val . '</span>';
            }
        }
    endforeach;

    return $result;
}