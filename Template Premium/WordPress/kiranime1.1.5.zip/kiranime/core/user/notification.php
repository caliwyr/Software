<?php

/**
 * send notification to user if new episode of the anime is on their watch list.
 * using anime metadata watch list
 */

function kiranime_notify_user_new_episode($episode_id, $anime_id)
{

    $anime_id = isset($anime_id) ? $anime_id : (int) get_post_meta($episode_id, 'kiranime_episode_parent_id', true);

    $subscribers = kiranime_get_user_list_by_anime($anime_id);

    foreach ($subscribers as $subscriber) {
        $get = get_posts([
            'post_type' => 'notification',
            'author' => $subscriber,
        ]);

        if (!$get || count($get) == 0) {
            $create_notification = wp_insert_post([
                'post_type' => 'notification',
                'post_title' => 'notification_for_' . $subscriber,
                'post_status' => 'publish',
                'post_author' => $subscriber,
            ]);

            update_post_meta($create_notification, 'notification_update', json_encode([['episode_id' => $episode_id, 'status' => false, 'anime_id' => $anime_id, 'notification_id' => $episode_id . $anime_id]]));
        } else {
            $meta = get_post_meta($get[0]->ID, 'notification_update', true);
            $meta = $meta ? json_decode($meta) : [];

            $meta[] = [
                'episode_id' => $episode_id,
                'status' => false,
                'anime_id' => $anime_id,
                'notification_id' => $episode_id . $anime_id,
            ];

            update_post_meta($get[0]->ID, 'notification_update', json_encode($meta));
        }
    }
}

add_action('wp_ajax_kiranime_check_notification', 'kiranime_check_notification');
function kiranime_check_notification()
{
    $notification = $_POST['notification_id'];

    $nid = $notification ? explode(",", $notification) : [];
    $user = get_current_user_id();

    $get = get_posts([
        'post_type' => 'notification',
        'author' => $user,
    ]);

    $meta = get_post_meta($get[0]->ID, 'notification_update', true);
    $meta = $meta ? (array) json_decode($meta) : [];

    $new_notif = [];
    foreach ($meta as $index => $n) {
        if (in_array($n->notification_id, $nid)) {
            $new_notif[] = [
                'episode_id' => $n->episode_id,
                'status' => true,
                'anime_id' => $n->anime_id,
                'notification_id' => $n->notification_id,
            ];
        } else {
            $new_notif[] = $n;
        }
    }

    update_post_meta($get[0]->ID, 'notification_update', json_encode($new_notif));

    return wp_send_json_success(['results' => $new_notif]);
    wp_die();
}

function kiranime_get_anime_data_for_notification(array $notifications)
{
    if (count($notifications) == 0) {
        return false;
    }

    $result = [];
    foreach ($notifications as $notif) {
        $episode = get_post($notif->episode_id);
        $anime = get_post($notif->anime_id);

        $result[] = [
            'title' => $anime->post_title,
            'anime_id' => $notif->anime_id,
            'url' => get_post_permalink($episode->ID),
            'published' => human_time_diff(get_the_time('U', $episode)),
            'number' => get_post_meta($episode->ID, 'kiranime_episode_number', true),
        ];
    }

    return $result;
}

add_action('wp_ajax_kiranime_get_notification', 'kiranime_get_notification');
function kiranime_get_notification()
{
    $user = get_current_user_id();

    if (!$user) {
        return wp_send_json_error([], 403);
        wp_die();
    }

    $get = get_posts([
        'post_type' => 'notification',
        'author' => $user,
    ]);

    $meta = isset($get) && isset($get[0]->ID) ? get_post_meta($get[0]->ID, 'notification_update', true) : false;
    $meta = $meta ? (array) json_decode($meta) : [];

    $results = [];
    foreach ($meta as $notif) {
        $episode = get_post($notif->episode_id);
        $anime = get_post($notif->anime_id);

        $results[] = [
            'title' => $anime->post_title,
            'anime_id' => $notif->anime_id,
            'url' => get_post_permalink($episode->ID),
            'published' => human_time_diff(get_the_time('U', $episode)),
            'number' => get_post_meta($episode->ID, 'kiranime_episode_number', true),
            'status' => $notif->status,
            'featured' => get_the_post_thumbnail_url($anime, 'featured-image'),
            'notif_id' => $notif->notification_id,
        ];
    }

    return wp_send_json_success($results);
    wp_die();
}

add_action('kiranime_set_notification', 'kiranime_set_notification', 10, 1);
function kiranime_set_notification(int $notification_id)
{
    $user = get_current_user_id();

    $get = get_posts([
        'post_type' => 'notification',
        'author' => $user,
    ]);

    $meta = get_post_meta($get[0]->ID, 'notification_update', true);
    $meta = $meta ? (array) json_decode($meta) : [];

    $filtered = array_map(function ($val) use ($notification_id) {
        if ($val['notification_id'] == $notification_id) {
            return [
                'episode_id' => $val['id'],
                'status' => true,
                'anime_id' => $val['anime_id'],
                'notification_id' => $val['notification_id'],
            ];
        } else {
            return $val;
        }
    }, $meta);

    update_post_meta($get[0]->ID, 'notification_update', json_encode($filtered));
}