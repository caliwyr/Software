<?php

add_action('wp_ajax_nopriv_kiranime_ajax_login', 'kiranime_ajax_login');
function kiranime_ajax_login()
{
    if (!wp_verify_nonce($_POST['login_nonce'], 'ajax-login-nonce')) {
        return wp_send_json_error(['success' => false, 'message' => 'Security check failed. Reload this page.']);
        wp_die();
    }

    $info = [];
    $info['user_login'] = $_POST['username'];
    $info['user_password'] = $_POST['password'];

    $user_signon = wp_signon($info, '');
    if (is_wp_error($user_signon)) {
        return wp_send_json_error(['loggedin' => false, 'message' => __('Wrong username or password.')], 403);
    } else {
        return wp_send_json_success(['loggedin' => true, 'message' => __('Login successful, redirecting...')], 200);
    }

    wp_die();
}

add_action('wp_ajax_nopriv_kiranime_ajax_register', 'kiranime_ajax_register');
function kiranime_ajax_register()
{
    $params = $_POST;

    if (!wp_verify_nonce($params['register_nonce'], 'ajax-register-nonce')) {
        return wp_send_json_error(['success' => false, 'message' => 'Security check failed. Reload this page.']);
        wp_die();
    }

    $username_check = username_exists($params['username']);
    $email_check = email_exists($params['email']);

    $banned_username = ['admin', 'administrator'];

    if (in_array($params['username'], $banned_username)) {
        return wp_send_json_error(['success' => false, 'message' => 'Username not allowed!']);
        wp_die();
    }

    if ($username_check) {
        return wp_send_json_error(['success' => false, 'message' => 'Email already exist!']);
        wp_die();
    }

    if ($email_check) {
        return wp_send_json_error(['success' => false, 'message' => 'Email already exist!']);
        wp_die();
    }

    $created = wp_create_user($params['username'], $params['password'], $params['email']);

    if (is_wp_error($created)) {
        return wp_send_json_error(['success' => false, 'message' => $created->errors]);
        wp_die();
    }

    add_user_meta($created, 'kiranime_user_avatar', get_stylesheet_directory_uri() . '/avatar/dragonball/av-db-1.jpeg');

    return wp_send_json_success(['success' => true, 'message' => 'Register successful.']);
    wp_die();
}

add_action('wp_ajax_kiranime_ajax_logout', 'kiranime_ajax_logout');
function kiranime_ajax_logout()
{
    wp_logout();
    ob_clean(); // probably overkill for this, but good habit
    wp_send_json_success(['status' => true]);
    wp_die();
}