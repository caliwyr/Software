<?php

/**
 * get user avatar
 */

function kiranime_get_user_avatar(int $user_id)
{
    $avatar = (string) get_user_meta($user_id, 'kiranime_user_avatar', true);

    if (!$avatar) {
        return get_stylesheet_directory_uri() . '/avatar/dragonball/av-db-1.jpeg';
    } else {
        return $avatar;
    }
}

/**
 * set user avatar
 */
add_action('wp_ajax_kiranime_change_avatar', 'kiranime_set_user_avatar');
function kiranime_set_user_avatar(string $avatar_path)
{
    $avatar = $_POST['avatar'];
    $set = get_stylesheet_directory_uri() . $avatar_path;
    $uid = get_current_user_id();

    $updated = update_user_meta($uid, 'kiranime_user_avatar', $avatar ? $avatar : $set);
    if (!$updated) {
        return wp_send_json_error(['success' => false], 500);
        wp_die();
    } else {
        return wp_send_json_success(['success' => true, 'data' => $updated]);
        wp_die();
    }
}

function kiranime_get_avatar_list()
{
    $chibi = range(1, 19);
    $dragonball = range(1, 6);
    $onepiece = range(1, 12);

    $results = [
        'chibi' => [],
        'dragonball' => [],
        'onepiece' => [],
    ];

    foreach ($chibi as $c) {
        $results['chibi'][] = get_stylesheet_directory_uri() . '/avatar/chibi/chibi_' . $c . '.png';
    }
    foreach ($dragonball as $d) {
        $results['dragonball'][] = get_stylesheet_directory_uri() . '/avatar/dragonball/av-db-' . $d . '.jpeg';
    }
    foreach ($onepiece as $o) {
        $results['onepiece'][] = get_stylesheet_directory_uri() . '/avatar/onepiece/user-' . $o . '.jpeg';
    }

    return $results;
}

add_action('wp_ajax_kiranime_save_user_setting', 'kiranime_save_user_setting');
function kiranime_save_user_setting()
{
    $params = isset($_POST['data']) ? json_decode(stripslashes($_POST['data'])) : [];
    $uid = get_current_user_id();

    if (!$params) {
        return wp_send_json_error(['message' => 'no data!', 'param' => $_POST]);
        wp_die();
    }

    foreach ($params as $data) {
        update_user_meta($uid, $data->name, $data->value);
    }

    return wp_send_json_success(['success' => true]);
    wp_die();
}