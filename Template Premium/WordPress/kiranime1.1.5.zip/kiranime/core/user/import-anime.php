<?php

/**
 * importing anime list from MAL
 */

add_action('wp_ajax_kiranime_import_anime_list', 'kiranime_import_anime_list');
function kiranime_import_anime_list()
{

    global $wpdb;

    $nonce = $_POST['nonce'];
    $animes = $_POST['animes'];

    if (!wp_verify_nonce($nonce, 'kiranime_mal_import')) {
        return wp_send_json_error(['success' => false, 'message' => 'Security check failed!'], 403);
        wp_die();
    }
    if (!$animes) {
        return wp_send_json_success(['success' => true, 'message' => 'Imported 0 anime to your watch list.']);
        wp_die();
    }

    $animes = json_decode(stripslashes($animes));

    $result = 0;
    $uid = get_current_user_id();
    foreach ($animes as $anime) {

        if (!$anime->type) {
            continue;
        }

        $name = sanitize_title($anime->title);
        $prepare = $wpdb->prepare("SELECT * FROM $wpdb->posts WHERE `post_type`=%s AND `post_status`=%s AND `post_name`= %s", 'anime', 'publish', $name);
        $res = $wpdb->get_results($prepare);
        if (!$res || !$res[0]) {
            continue;
        }

        $id = $res[0]->ID;
        $get_current_list = get_post_meta($id, 'bookmark_' . $anime->type . '_by', false);
        if (in_array($uid, $get_current_list)) {
            continue;
        } else {
            $removed = remove_other_bookmark_type($anime->type, $id, $uid);
            $count = (int) get_post_meta($id, 'bookmark_count', true);
            foreach ($removed as $rev) {
                if ($rev['status']) {
                    update_post_meta($id, 'bookmark_count', $count + 1);
                }
            }

            add_post_meta($id, 'bookmark_' . $anime->type . '_by', $uid);
            $result = $result + 1;
        }
    }

    return wp_send_json_success(['success' => true, 'message' => 'Imported ' . $result . ' anime to your watch list.', 'data' => $animes]);
    wp_die();

}