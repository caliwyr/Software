<?php

/**
 * Status taxonomy
 *
 * @package kiranime
 */

function kiranime_status_taxonomy()
{
    $labels = array(
        'name' => _x('Status', 'taxonomy general name'),
        'singular_name' => _x('Status', 'taxonomy singular name'),
        'search_items' => __('Search Status'),
        'all_items' => __('All Status'),
        'parent_item' => __('Parent Status'),
        'parent_item_colon' => __('Parent Status:'),
        'edit_item' => __('Edit Status'),
        'update_item' => __('Update Status'),
        'add_new_item' => __('Add New Status'),
        'new_item_name' => __('New Status Name'),
        'menu_name' => __('Status'),
    );
    $args = array(
        'hierarchical' => true, // make it hierarchical (like categories)
        'labels' => $labels,
        'show_ui' => true,
        'show_admin_column' => true,
        'query_var' => true,
        'rewrite' => ['slug' => 'status'],
    );
    register_taxonomy('status', ['anime'], $args);
}
add_action('init', 'kiranime_status_taxonomy');