<?php

/**
 * Anime Attribute taxonomy
 *
 * @package kiranime
 */

function kiranime_anime_attribute_taxonomy()
{
    $labels = array(
        'name' => _x('Anime Attribute', 'taxonomy general name'),
        'singular_name' => _x('Anime Attribute', 'taxonomy singular name'),
        'search_items' => __('Search Anime Attribute'),
        'all_items' => __('All Anime Attribute'),
        'parent_item' => __('Parent Anime Attribute'),
        'parent_item_colon' => __('Parent Anime Attribute:'),
        'edit_item' => __('Edit Anime Attribute'),
        'update_item' => __('Update Anime Attribute'),
        'add_new_item' => __('Add New Anime Attribute'),
        'new_item_name' => __('New Anime Attribute Name'),
        'menu_name' => __('Anime Attribute'),
    );
    $args = array(
        'hierarchical' => true, // make it hierarchical (like categories)
        'labels' => $labels,
        'show_ui' => true,
        'show_admin_column' => true,
        'query_var' => true,
        'rewrite' => ['slug' => 'anime_attribute'],
    );
    register_taxonomy('anime_attribute', ['anime'], $args);
}
add_action('init', 'kiranime_anime_attribute_taxonomy');