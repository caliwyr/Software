<?php

/**
 * Notification custom post type
 *
 * @package kiranime
 */

function kiranime_notification_cpt()
{
    $labels = array(
        'name' => _x('Notifications', 'Post Type General Name', 'kiranime'),
        'singular_name' => _x('Notification', 'Post Type Singular Name', 'kiranime'),
        'menu_name' => __('Notifications', 'kiranime'),
        'parent_item_colon' => __('Parent Notification', 'kiranime'),
        'all_items' => __('All Notifications', 'kiranime'),
        'view_item' => __('View Notification', 'kiranime'),
        'add_new_item' => __('Add New Notification', 'kiranime'),
        'add_new' => __('Add New', 'kiranime'),
        'edit_item' => __('Edit Notification', 'kiranime'),
        'update_item' => __('Update Notification', 'kiranime'),
        'search_items' => __('Search Notification', 'kiranime'),
        'not_found' => __('Not Found', 'kiranime'),
        'not_found_in_trash' => __('Not found in Trash', 'kiranime'),
    );

    $args = array(
        'label' => __('notifications', 'kiranime'),
        'description' => __('Notification post', 'kiranime'),
        'labels' => $labels,
        'supports' => array('title', 'author'),
        /* A hierarchical CPT is like Pages and can have
         * Parent and child items. A non-hierarchical CPT
         * is like Posts.
         */
        'hierarchical' => false,
        'public' => true,
        'show_ui' => false,
        'show_in_menu' => false,
        'show_in_nav_menus' => false,
        'show_in_admin_bar' => false,
        'menu_position' => 6,
        'can_export' => true,
        'has_archive' => false,
        'exclude_from_search' => true,
        'publicly_queryable' => true,
        'capability_type' => 'post',
        'show_in_rest' => false,

    );

    // Registering your Custom Post Type
    register_post_type('notification', $args);
}

add_action('init', 'kiranime_notification_cpt', 10);