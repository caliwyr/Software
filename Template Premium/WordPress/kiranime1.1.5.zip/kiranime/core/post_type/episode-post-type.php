<?php

/**
 * Episode custom post type
 *
 * @package kiranime
 */

function kiranime_episode_cpt()
{
    $labels = array(
        'name' => _x('Episodes', 'Post Type General Name', 'kiranime'),
        'singular_name' => _x('Episode', 'Post Type Singular Name', 'kiranime'),
        'menu_name' => __('Episodes', 'kiranime'),
        'parent_item_colon' => __('Parent Episode', 'kiranime'),
        'all_items' => __('All Episodes', 'kiranime'),
        'view_item' => __('View Episode', 'kiranime'),
        'add_new_item' => __('Add New Episode', 'kiranime'),
        'add_new' => __('Add New', 'kiranime'),
        'edit_item' => __('Edit Episode', 'kiranime'),
        'update_item' => __('Update Episode', 'kiranime'),
        'search_items' => __('Search Episode', 'kiranime'),
        'not_found' => __('Not Found', 'kiranime'),
        'not_found_in_trash' => __('Not found in Trash', 'kiranime'),
    );

    $args = array(
        'label' => __('episodes', 'kiranime'),
        'description' => __('Episode post', 'kiranime'),
        'labels' => $labels,
        'supports' => array('title', 'author', 'thumbnail', 'comments'),
        'taxonomies' => array('genres'),
        /* A hierarchical CPT is like Pages and can have
         * Parent and child items. A non-hierarchical CPT
         * is like Posts.
         */
        'hierarchical' => false,
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'show_in_nav_menus' => true,
        'show_in_admin_bar' => true,
        'menu_position' => 6,
        'can_export' => true,
        'has_archive' => true,
        'exclude_from_search' => false,
        'publicly_queryable' => true,
        'capability_type' => 'post',
        'show_in_rest' => true,
        'rewrite' => array('slug' => 'watch'),
    );

    // Registering your Custom Post Type
    register_post_type('episode', $args);
}

add_action('init', 'kiranime_episode_cpt', 10);