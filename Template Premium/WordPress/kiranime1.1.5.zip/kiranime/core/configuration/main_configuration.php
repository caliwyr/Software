<?php

/**
 * anime display list
 * determine how many anime will be displayed on homepage for latest, new, and upcomming.
 */

add_action('admin_menu', 'kiranime_configuration');
function kiranime_configuration()
{
    add_menu_page('Configuration', 'Theme Settings', 'manage_options', 'theme_configuration', 'kiranime_display_setting', 'dashicons-admin-generic', 81);
    add_submenu_page('theme_configuration', 'Anime Display', 'Anime Display', 'manage_options', 'theme_configuration', 'kiranime_display_setting');
    add_submenu_page('theme_configuration', 'Site Settings', 'Site Settings', 'manage_options', 'site_setting', 'kiranime_site_setting');
    add_submenu_page('theme_configuration', 'Ads Settings', 'Ads Settings', 'manage_options', 'banner_setting', 'kiranime_banner_setting');
    add_submenu_page('theme_configuration', 'Other Settings', 'Others', 'manage_options', 'others_setting', 'kiranime_others_setting');
    add_action('admin_init', 'kiranime_register_setting');
}

function kiranime_register_setting()
{
    // Logo - etc
    register_setting('kiranime_setting_site', '__s_footer');
    register_setting('kiranime_setting_site', '__s_rd');
    register_setting('kiranime_setting_site', '__s_dc');
    register_setting('kiranime_setting_site', '__s_tl');

    // Banner setting
    register_setting('kiranime_setting_banner', '__b_after_trending');
    register_setting('kiranime_setting_banner', '__b_after_featured');
    register_setting('kiranime_setting_banner', '__b_after_download');
    register_setting('kiranime_setting_banner', '__b_home_pop');
    register_setting('kiranime_setting_banner', '__b_archive_pop');
    register_setting('kiranime_setting_banner', '__b_single_pop');

    // Anime display count
    register_setting('kiranime_setting_display', '__c_spotlight');
    register_setting('kiranime_setting_display', '__c_trending');
    register_setting('kiranime_setting_display', '__c_latest');
    register_setting('kiranime_setting_display', '__c_new_anime');
    register_setting('kiranime_setting_display', '__c_upcomming');
    register_setting('kiranime_setting_display', '__c_recommended');
    register_setting('kiranime_setting_display', '__c_archive');

    // Others (share shortcode, etc.)
    register_setting('kiranime_setting_others', '__o_share');
    register_setting('kiranime_setting_others', '__o_noplayer');
    register_setting('kiranime_setting_others', '__a_mal');
    register_setting('kiranime_setting_others', '__a_tmdb');
}

function load_css_setting()
{
    wp_enqueue_style('kiranime-setting-css', kiranime_asset('css/app.css'), [], time());
}

function kiranime_display_setting()
{
    load_css_setting();
    $spotlight = get_option('__c_spotlight') ? get_option('__c_spotlight') : 10;
    $trending = get_option('__c_trending') ? get_option('__c_trending') : 12;
    $latest = get_option('__c_latest') ? get_option('__c_latest') : 16;
    $new_anime = get_option('__c_new_anime') ? get_option('__c_new_anime') : 16;
    $upcomming = get_option('__c_upcomming') ? get_option('__c_upcomming') : 16;
    $recommended = get_option('__c_recommended') ? get_option('__c_recommended') : 12;
    ?>
<div class="w-10/12 my-10 p-4 bg-white rounded shadow-md">
    <h2 class="leading-10 font-medium text-2xl w-max pb-4 border-b border-gray-500">Anime Display</h2>
    <form class="space-y-6 my-5" method="post" action="options.php" enctype="multipart/form-data">
        <?php settings_fields('kiranime_setting_display');?>
        <?php do_settings_sections('kiranime_setting_display');?>
        <div class="grid grid-cols-10 gap-5 items-center">
            <label for="__c_spotlight" class="col-span-2 text-sm font-semibold">Spotlight Count</label>
            <input name="__c_spotlight" type="number" placeholder="10"
                <?php if ($spotlight) {echo 'value="' . $spotlight . '"';}?>
                class="w-full col-span-8 border-gray-600 focus:border-gray-800 outline-none text-sm font-medium">
        </div>
        <div class="grid grid-cols-10 gap-5 items-center">
            <label for="__c_trending" class="col-span-2 text-sm font-semibold">Trending Count</label>
            <input name="__c_trending" type="number" placeholder="10"
                <?php if ($trending) {echo 'value="' . $trending . '"';}?>
                class="w-full col-span-8 border-gray-600 focus:border-gray-800 outline-none text-sm font-medium">
        </div>
        <div class="grid grid-cols-10 gap-5 items-center">
            <label for="__c_latest" class="col-span-2 text-sm font-semibold">Latest Update Count</label>
            <input name="__c_latest" type="number" placeholder="10"
                <?php if ($latest) {echo 'value="' . $latest . '"';}?>
                class="w-full col-span-8 border-gray-600 focus:border-gray-800 outline-none text-sm font-medium">
        </div>
        <div class="grid grid-cols-10 gap-5 items-center">
            <label for="__c_new_anime" class="col-span-2 text-sm font-semibold">New Anime Count</label>
            <input name="__c_new_anime" type="number" placeholder="10"
                <?php if ($new_anime) {echo 'value="' . $new_anime . '"';}?>
                class="w-full col-span-8 border-gray-600 focus:border-gray-800 outline-none text-sm font-medium">
        </div>
        <div class="grid grid-cols-10 gap-5 items-center">
            <label for="__c_upcomming" class="col-span-2 text-sm font-semibold">Upcomming Anime Count</label>
            <input name="__c_upcomming" type="number" placeholder="10"
                <?php if ($upcomming) {echo 'value="' . $upcomming . '"';}?>
                class="w-full col-span-8 border-gray-600 focus:border-gray-800 outline-none text-sm font-medium">
        </div>
        <div class="grid grid-cols-10 gap-5 items-center">
            <label for="__c_recommended" class="col-span-2 text-sm font-semibold">Recommended Anime Count</label>
            <input name="__c_recommended" type="number" placeholder="10"
                <?php if ($recommended) {echo 'value="' . $recommended . '"';}?>
                class="w-full col-span-8 border-gray-600 focus:border-gray-800 outline-none text-sm font-medium">
        </div>
        <div class="w-full flex items-center justify-end">
            <button type="submit"
                class="rounded text-sm outline-none border-none focus:ring ring-sky-400 bg-sky-600 px-5 text-white py-2">Save</button>
        </div>
    </form>
</div>
<?php }

function kiranime_others_setting()
{
    load_css_setting();
    $share = get_option('__o_share') ? get_option('__o_share') : '';
    $mal = get_option('__a_mal') ? get_option('__a_mal') : '';
    $tmdb = get_option('__a_tmdb') ? get_option('__a_tmdb') : '';
    $noplayer = get_option('__o_noplayer') ? get_option('__o_noplayer') : '';?>

<div class="w-10/12 my-10 p-4 bg-white rounded shadow-md">
    <h2 class="leading-10 font-medium text-2xl w-max pb-4 border-b border-gray-500">Other Theme Settings</h2>
    <form class="space-y-6 my-5" method="post" action="options.php" enctype="multipart/form-data">
        <?php settings_fields('kiranime_setting_others');?>
        <?php do_settings_sections('kiranime_setting_others');?>
        <div class="grid grid-cols-10 gap-5 items-center">
            <label for="__o_share" class="col-span-2 text-sm font-semibold">Share Shortcode</label>
            <input name="__o_share" id="__o_share" type="text" placeholder="[add_this='....']"
                <?php if ($share) {echo 'value="' . esc_attr($share) . '"';}?>
                class="w-full col-span-8 border-gray-600 focus:border-gray-800 outline-none text-sm font-medium">
        </div>
        <div class="grid grid-cols-10 gap-5 items-center">
            <label for="__o_noplayer" class="col-span-2 text-sm font-semibold">No Player Notice</label>
            <textarea name="__o_noplayer" id="__o_noplayer" rows="5"
                placeholder="your no episode video info iframe or img."
                class="w-full col-span-8 p-1 border-gray-600 focus:border-gray-800 outline-none text-sm font-medium"><?php if ($noplayer) {echo esc_attr($noplayer);}?></textarea>
        </div>
        <div class="grid grid-cols-10 gap-5 items-center">
            <label for="__a_mal" class="col-span-2 text-sm font-semibold">MAL Endpoint</label>
            <input name="__a_mal" id="__a_mal" type="text" <?php if ($mal) {echo 'value="' . esc_attr($mal) . '"';}?>
                class="w-full col-span-8 border-gray-600 focus:border-gray-800 outline-none text-sm font-medium">
        </div>
        <div class="grid grid-cols-10 gap-5 items-center">
            <label for="__a_tmdb" class="col-span-2 text-sm font-semibold">TMDB API Key</label>
            <input name="__a_tmdb" id="__a_tmdb" type="text"
                <?php if ($tmdb) {echo 'value="' . esc_attr($tmdb) . '"';}?>
                class="w-full col-span-8 border-gray-600 focus:border-gray-800 outline-none text-sm font-medium">
        </div>
        <div class="w-full flex items-center justify-end">
            <button type="submit"
                class="rounded text-sm outline-none border-none focus:ring ring-sky-400 bg-sky-600 px-5 text-white py-2">Save</button>
        </div>
    </form>
</div>

<?php }

function kiranime_site_setting()
{
    load_css_setting();
    $socials = [
        '__s_rd' => ['name' => 'Reddit', 'link' => get_option('__s_rd')],
        '__s_tl' => ['name' => 'Telegram', 'link' => get_option('__s_tl')],
        '__s_dc' => ['name' => 'Discord', 'link' => get_option('__s_dc')],
    ];
    $footer = get_option('__s_footer');?>
<div class="w-10/12 my-10 p-4 bg-white rounded shadow-md">
    <h2 class="leading-10 font-medium text-2xl w-max pb-4 border-b border-gray-500">Site and Socials Setting</h2>
    <form class="space-y-6 my-5" method="post" action="options.php" enctype="multipart/form-data">
        <?php settings_fields('kiranime_setting_site');?>
        <?php do_settings_sections('kiranime_setting_site');?>
        <div class="grid grid-cols-10 gap-5 items-center">
            <label for="__s_footer" class="col-span-2 text-sm font-semibold">Footer Image Url</label>
            <input name="__s_footer" id="__s_footer" type="text"
                placeholder="Your footer image url, minimum height 400px"
                <?php if ($footer) {echo 'value="' . $footer . '"';}?>
                class="w-full col-span-8 border-gray-600 focus:border-gray-800 outline-none text-sm font-medium">
        </div>
        <div class="grid grid-cols-3 w-full gap-4">
            <span class="col-span-full py-1 text-sm font-semibold text-gray-900 pb-2 border-b border-gray-300">Social
                Links</span>
            <?php foreach ($socials as $social => $data): ?>
            <div class="space-y-1 items-center">
                <label for="<?php echo $social ?>" class="text-sm font-semibold"><?php echo $data['name'] ?>
                    URL</label>
                <input name="<?php echo $social ?>" id="<?php echo $social ?>" type="text"
                    placeholder="your <?php echo $data['name'] ?> url."
                    <?php if ($data['link']) {echo 'value="' . $data['link'] . '"';}?>
                    class="w-full col-span-8 border-gray-600 focus:border-gray-800 outline-none text-sm font-medium">
            </div>
            <?php endforeach;?>
        </div>
        <div class="w-full flex items-center justify-end">
            <button type="submit"
                class="rounded text-sm outline-none border-none focus:ring ring-sky-400 bg-sky-600 px-5 text-white py-2">Save</button>
        </div>
    </form>
</div>

<?php }

function kiranime_banner_setting()
{
    load_css_setting();

    $__b_after_trending = get_option('__b_after_trending') ? get_option('__b_after_trending') : false;
    $__b_after_featured = get_option('__b_after_featured') ? get_option('__b_after_featured') : false;
    $__b_after_download = get_option('__b_after_download') ? get_option('__b_after_download') : false;
    $__b_home_pop = get_option('__b_home_pop') ? get_option('__b_home_pop') : false;
    $__b_archive_pop = get_option('__b_archive_pop') ? get_option('__b_archive_pop') : false;
    $__b_single_pop = get_option('__b_single_pop') ? get_option('__b_single_pop') : false;

    ?>
<div class="w-10/12 my-10 p-4 bg-white rounded shadow-md">
    <h2 class="leading-10 font-medium text-2xl w-max pb-4 border-b border-gray-500">Ads Setting</h2>
    <form class="space-y-6 my-5" method="post" action="options.php" enctype="multipart/form-data">
        <?php settings_fields('kiranime_setting_banner');?>
        <?php do_settings_sections('kiranime_setting_banner');?>
        <div class="grid grid-cols-10 gap-5 items-center">
            <label for="__b_after_trending" class="col-span-2 text-sm font-semibold">After Trending Banner</label>
            <textarea name="__b_after_trending" id="__b_after_trending" type="text"
                placeholder="banner after trending slider. use Javascript code or image html." rows="3"
                class="w-full col-span-8 border-gray-600 focus:border-gray-800 outline-none px-3 py-1 text-sm font-medium"><?php if ($__b_after_trending) {echo esc_html($__b_after_trending);}?></textarea>
        </div>
        <div class="grid grid-cols-10 gap-5 items-center">
            <label for="__b_after_featured" class="col-span-2 text-sm font-semibold">After Featured list Banner</label>
            <textarea name="__b_after_featured" id="__b_after_featured" type="text"
                placeholder="banner after featured list. use Javascript code or image html." rows="3"
                class="w-full col-span-8 border-gray-600 focus:border-gray-800 px-3 py-1 outline-none text-sm font-medium"><?php if ($__b_after_featured) {echo esc_html($__b_after_featured);}?></textarea>
        </div>
        <div class="grid grid-cols-10 gap-5 items-center">
            <label for="__b_after_download" class="col-span-2 text-sm font-semibold">After Download Banner</label>
            <textarea name="__b_after_download" id="__b_after_download" type="text"
                placeholder="banner after download link. use Javascript code or image html." rows="3"
                class="w-full col-span-8 border-gray-600 px-3 py-1 focus:border-gray-800 outline-none text-sm font-medium"><?php if ($__b_after_download) {echo esc_html($__b_after_download);}?></textarea>
        </div>
        <div class="grid grid-cols-10 gap-5 items-center">
            <label for="__b_home_pop" class="col-span-2 text-sm font-semibold">Homepage Popup/Under</label>
            <textarea name="__b_home_pop" id="__b_home_pop" type="text"
                placeholder="Javascript popup/under ads on homepage only." rows="3"
                class="w-full col-span-8 border-gray-600 px-3 py-1 focus:border-gray-800 outline-none text-sm font-medium"><?php if ($__b_home_pop) {echo esc_html($__b_home_pop);}?></textarea>
        </div>
        <div class="grid grid-cols-10 gap-5 items-center">
            <label for="__b_archive_pop" class="col-span-2 text-sm font-semibold">Archive Popup/Under</label>
            <textarea name="__b_archive_pop" id="__b_archive_pop" type="text"
                placeholder="Javascript popup/under ads on archive only." rows="3"
                class="w-full col-span-8 border-gray-600 px-3 py-1 focus:border-gray-800 outline-none text-sm font-medium"><?php if ($__b_archive_pop) {echo esc_html($__b_archive_pop);}?></textarea>
        </div>
        <div class="grid grid-cols-10 gap-5 items-center">
            <label for="__b_single_pop" class="col-span-2 text-sm font-semibold">Single Post Popup/Under</label>
            <textarea name="__b_single_pop" id="__b_single_pop" type="text"
                placeholder="Javascript popup/under ads on single post, anime, episode only." rows="3"
                class="w-full col-span-8 border-gray-600 px-3 py-1 focus:border-gray-800 outline-none text-sm font-medium"><?php if ($__b_single_pop) {echo esc_html($__b_single_pop);}?></textarea>
        </div>
        <div class="w-full flex items-center justify-end">
            <button type="submit"
                class="rounded text-sm outline-none border-none focus:ring ring-sky-400 bg-sky-600 px-5 text-white py-2">Save</button>
        </div>
    </form>
</div>
<?php }