<?php

/**
 * create taxonomies and pages after theme switch
 *
 * @package kiranime
 */

add_action('after_switch_theme', 'kiranime_generate_taxonomy');
add_action('after_switch_theme', 'kiranime_generate_pages');

function kiranime_generate_taxonomy()
{
    $status = kiranime_generate_status_taxonomy();
    $attr = kiranime_generate_attribute_taxonomy();
    $type = kiranime_generate_type_taxonomy();

    return [$status, $attr, $type];
}

function kiranime_generate_status_taxonomy()
{
    $required_terms = [
        'upcomming' => 'Upcomming',
        'airing' => 'Currently Airing',
        'completed' => 'Finished Airing',
    ];
    $tax_name = 'status';

    foreach ($required_terms as $slug => $term_name) {
        if (!get_term($slug, $tax_name)) {
            wp_insert_term(
                $term_name,
                $tax_name,
                [
                    'description' => $term_name . ' status.',
                    'slug' => $slug,
                ]
            );
        }
    }
}

function kiranime_generate_attribute_taxonomy()
{
    $required_terms = [
        'sub' => 'SUB',
        'dub' => 'DUB',
        'hd' => 'HD',
    ];
    $tax_name = 'anime_attribute';

    foreach ($required_terms as $slug => $term_name) {
        if (!get_term($slug, $tax_name)) {
            wp_insert_term(
                $term_name,
                $tax_name,
                [
                    'description' => $term_name . ' anime attribute.',
                    'slug' => $slug,
                ]
            );
        }
    }
}

function kiranime_generate_type_taxonomy()
{
    $required_terms = [
        'ova' => 'OVA',
        'movie' => 'Movie',
        'ona' => 'ONA',
        'tv' => 'TV',
        'special' => 'Special',
    ];
    $tax_name = 'type';

    foreach ($required_terms as $slug => $term_name) {
        if (!get_term($slug, $tax_name)) {
            wp_insert_term(
                $term_name,
                $tax_name,
                [
                    'description' => $term_name . ' type.',
                    'slug' => $slug,
                ]
            );
        }
    }
}

function kiranime_generate_pages()
{
    kiranime_generate_page_user();
    kiranime_generate_az_list_page();
    kiranime_generate_necessary_page();
}

function kiranime_generate_page_user()
{
    global $wpdb;
    $query = $wpdb->prepare("SELECT * FROM $wpdb->posts WHERE `post_name`=%s OR `post_name`=%s AND `post_type`=%s", 'user', 'profile', 'page');
    $isExist = $wpdb->get_results($query);

    if (!empty($isExist) || !is_null($isExist) || !$isExist[0]->ID) {
        return true;
    }

    $user_page = wp_insert_post([
        'post_title' => 'User',
        'post_content' => '',
        'post_name' => 'user',
        'post_type' => 'page',
        'post_status' => 'publish',
        'page_template' => 'page-user.php',
    ], true);

    $user_child = ['profile' => 'Profile', 'continue-watching' => 'Continue Watching', 'watch-list' => 'Watch List', 'setting' => 'Setting', 'notification' => 'Notification', 'mal' => 'MAL Import'];

    if (is_wp_error($user_page)) {
        return false;
    }

    foreach ($user_child as $name => $title) {
        wp_insert_post([
            'post_title' => $title,
            'post_type' => 'page',
            'post_content' => '',
            'post_status' => 'publish',
            'post_name' => $name,
            'page_template' => 'page-' . $name . '.php',
            'post_parent' => $user_page,
        ]);
    }

    return true;
}

function kiranime_generate_az_list_page()
{
    global $wpdb;
    $get_q = $wpdb->prepare("SELECT ID FROM $wpdb->posts WHERE `post_name`= %s AND `post_type`=%s", 'az-list', 'page');

    $is_any = $wpdb->get_results($get_q);
    if (!empty($is_any) || isset($is_any)) {
        return true;
    }

    $create_az = wp_insert_post([
        'post_title' => 'AZ List',
        'post_status' => 'publish',
        'post_type' => 'page',
        'post_name' => 'az-list',
        'page_template' => 'page-az-list.php',
    ], true);

    if (is_wp_error($create_az)) {
        return false;
    }
    return true;
}

function kiranime_generate_necessary_page()
{
    global $wpdb;
    $pages = ['recently-added' => 'Recently Added Anime', 'upcomming-anime' => 'Upcomming Anime', 'latest-update' => 'Latest Update Anime', 'filter' => 'Anime Filter', 'search' => 'Anime Search', 'top-airing' => 'Top Airing Anime', 'most-popular' => 'Most Popular Anime', 'favorite' => 'Most Favorite Anime'];

    foreach ($pages as $name => $title) {
        $get_prepare = $wpdb->prepare("SELECT ID FROM $wpdb->posts WHERE `post_name`= %s AND `post_type`=%s", $name, 'page');
        $get = $wpdb->get_results($get_prepare, OBJECT);

        if (!empty($get)) {
            continue;
        } else {
            wp_insert_post([
                'post_type' => 'page',
                'post_title' => $title,
                'post_name' => $name,
                'post_status' => 'publish',
                'page-template' => 'page-' . $name . '.php',
            ]);
        }

    }
}