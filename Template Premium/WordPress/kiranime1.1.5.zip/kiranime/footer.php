</main>
<?php $footer_image = get_option('__s_footer')?>
<div class="px-5 max-w-full relative z-39"
    style="background: #2a2c31 <?php if ($footer_image) {echo 'url(' . $footer_image . ') top center no-repeat';}?>;">
    <div class="py-8">
        <div
            class="mb-5 pb-5 sm:border-b border-gray-400 border-opacity-40 max-w-max sm:mx-auto lg:mx-0 lg:justify-start sm:flex hidden">
            <a href="/" id="logo" class="inline-block mr-10">
                <?php if (get_theme_mod('custom_logo')) {?>
                <img src="<?php $image = wp_get_attachment_image_src(get_theme_mod('custom_logo'));
    echo $image['0']?>" alt="<?php echo get_bloginfo('name') ?>">
                <?php } else {
    echo get_bloginfo('name');
}?>
            </a>
            <div class="pl-8 border-l border-gray-400 border-opacity-40 flex gap-5 items-center">
                <div class="w-max">
                    <span class="block text-xs">Join now</span>
                    <span class="block text-sm">
                        <?php echo get_bloginfo('name') ?>
                    </span>
                </div>
                <div class="flex items-center justify-start gap-4">
                    <?php $socials = kiranime_get_social_links()?>
                    <?php foreach ($socials as $key => $val): ?>
                    <?php if ($val['link']): ?>
                    <a href="<?php echo $val['link'] ?>" target="_blank"
                        class="flex items-center rounded shadow-md justify-center p-2 text-sm font-normal"
                        style="background-color: <?php echo $val['bg'] ?>;">
                        <?php echo $val['svg']; ?>
                    </a>
                    <?php endif;?>
                    <?php endforeach;?>
                </div>
            </div>
        </div>
        <div class="mb-3 hidden sm:block sm:text-center lg:text-left">
            <div class="block mb-3">
                <span
                    class="inline-block pr-5 mr-5 border-r border-gray-400 border-opacity-40 leading-4 text-xl font-semibold">A-Z
                    LIST</span>
                <span class="text-xs">Searching anime order by alphabet name A to
                    Z.</span>
            </div>
            <ul class="mt-2 m-0 p-0 list-none">
                <?php
$alphabet = ['All', '#', '0-9', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];

foreach ($alphabet as $key => $value) {
    if ($key == 0) {
        echo '<li class="mr-3 mb-3 inline-block"><a class="text-sm py-1 px-2 bg-opacity-4 hover:bg-sky-600 bg-secondary rounded-sm" href="/az-list">All</a></li>';
    } elseif ($key == 1) {
        echo '<li class="mr-3 mb-3 inline-block"><a class="text-sm py-1 px-2 bg-opacity-4 hover:bg-sky-600 bg-secondary rounded-sm" href="/az-list/?letter=other">#</a></li>';
    } else {
        echo '<li class="mr-3 mb-3 inline-block"><a class="text-sm py-1 px-2 bg-opacity-4 hover:bg-sky-600 bg-secondary rounded-sm" href="/az-list/?letter=' . $value . '">' . $value . '</a></li>';
    }
}
?>
            </ul>
        </div>
        <div class="flex sm:hidden w-max mx-auto items-center gap-4 mb-5 justify-center p-4 bg-white rounded-md shadow">
            <?php $socials = kiranime_get_social_links()?>
            <?php foreach ($socials as $key => $val): ?>
            <?php if ($val['link']): ?>
            <a href="<?php echo $val['link'] ?>" target="_blank"
                class="p-2 text-sm flex items-center justify-center font-normal"
                style="background-color: <?php echo $val['bg'] ?>;">
                <?php echo $val['svg']; ?>
            </a>

            <?php endif;?>
            <?php endforeach;?>
        </div>
        <div class="flex items-center gap-5 mb-3 justify-center md:justify-start">
            <a class="text-xs leading-8" href="/terms" title="Terms of service">Terms of service</a>
            <a class="text-xs leading-8" href="/dmca" title="DMCA">DMCA</a>
            <a class="text-xs leading-8" href="/contact" title="Contact">Contact</a>
        </div>
        <div class="text-xs  text-gray-500 text-opacity-80 text-center md:text-left">
            <?php echo get_bloginfo('name') ?> does not store any files on our server, we only linked to the media
            which is hosted on 3rd party services.
        </div>
        <p class="text-xs  text-gray-500 text-opacity-80 mb-3 text-center md:text-left">©
            <?php echo get_bloginfo('name') ?></p>
    </div>
</div>
<?php wp_footer();?>
<?php
$home_pop = get_option('__b_home_pop');
$archive_pop = get_option('__b_archive_pop');
$single_pop = get_option('__b_single_pop');
?>

<?php if (is_home() || is_front_page()): ?>
<?php if ($home_pop): ?>
<?php echo $home_pop ?>
<?php endif;?>
<?php endif;?>
<?php if (is_archive() || is_page_template(['page-az-list.php', 'page-most-popular.php', 'page-latest-update.php', 'page-top-airing.php', 'page-upcomming-anime.php', 'page-filter.php', 'page-search.php', 'page-recently-added.php'])): ?>
<?php if ($archive_pop): ?>
<?php echo $archive_pop ?>
<?php endif;?>
<?php endif;?>
<?php if (is_singular(['anime', 'episode'])): ?>
<?php if ($single_pop): ?>
<?php echo $single_pop ?>
<?php endif;?>
<?php endif;?>

</body>

</html>