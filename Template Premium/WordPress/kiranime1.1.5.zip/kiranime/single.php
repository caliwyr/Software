<?php get_header();?>
<?php if (have_posts()): while (have_posts()): the_post();?>
<div class="lg:px-10 md:px-5 py-10 w-full flex gap-5">
    <div class="w-full lg:w-3/4 container">
        <section class="mt-17">
            <!-- breadcrumb -->
            <nav aria-label="Breadcrumb" class="text-sm font-medium mb-5">
                <ol class="flex gap-2 items-center flex-wrap">
                    <li>
                        <a href="/">
                            Home
                        </a>
                    </li>
                    <li>
                        <div class="w-1 h-1 bg-gray-500 rounded-full"></div>
                    </li>
                    <li>
                        <a href="/news">
                            News
                        </a>
                    </li>
                    <li>
                        <div class="w-1 h-1 bg-gray-500 rounded-full"></div>
                    </li>
                    <li>
                        <a href="<?php the_permalink()?>" class="text-gray-500">
                            <?php the_title()?>
                        </a>
                    </li>
                </ol>
            </nav>
        </section>
        <article class="w-full">
            <h2 class="text-4xl font-semibold"><?php the_title()?></h2>
            <span class="inline-block mb-5 font-medium text-sm">Published
                <?php echo human_time_diff(get_the_time('U')) ?> ago.</span>
            <main class="text-sm">
                <?php the_content();?>
            </main>
        </article>
        <div class="my-10">
            <?php
        // If comments are open or we have at least one comment, load up the comment template.
        if (comments_open() || get_comments_number()):
            comments_template();
        endif;
        ?>
        </div>
    </div>
    <aside class="w-full lg:w-1/4">
        <?php if (is_active_sidebar('article-sidebar')): dynamic_sidebar('article-sidebar');endif;?>
    </aside>
</div>
<?php endwhile;endif;?>
<?php
get_footer();