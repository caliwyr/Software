<?php
/**
 * Template Name: Advanced Search Page
 *
 * @package Kiranime
 */

get_header('single');

$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
$per_page = get_option('__c_results') ? get_option('__c_results') : 20;
$query = [
    'post_type' => 'anime',
    'posts_per_page' => $per_page,
    'paged' => $paged,
    'order' => 'DESC',
];
$kw = get_query_var('keyword');
$order = get_query_var('order');
$orderby = get_query_var('orderby');
$genre = get_query_var('genre');
$data_genre = !empty($genre) ? explode(",", $genre) : [];
$type = get_query_var('type');
$status = get_query_var('status');
$season = get_query_var('season');
$year_selected = get_query_var('year');
$premiered = '';

if (!empty($season) && $season != 'all') {
    if ($year_selected) {
        $premiered = $season . ' ' . $year_selected;
    } else {
        $premiered = $season;
    }
}

if (isset($year_selected) && empty($season)) {
    $premiered = $year_selected;
}

$years = range(date('Y'), 1950);

if (!empty($kw)) {
    $query['keyword'] = $kw;
}

if (!empty($orderby)) {
    if ($orderby == 'title_a_z') {
        $query['orderby'] = 'title';
        $query['order'] = 'ASC';
    } elseif ($orderby == 'title_z_a') {
        $query['orderby'] = 'title';
        $query['order'] = 'DESC';
    } elseif ($orderby == 'update') {
        $query['orderby'] = 'meta_value_num';
        $query['meta_key'] = 'kiranime_anime_updated';
    } elseif ($orderby == 'viewed') {
        $query['orderby'] = 'meta_value_num';
        $query['meta_key'] = date('mY') . '_kiranime_views';
    }
}

$tax_query = [];
$meta_query = [];
if (!empty($genre)) {
    if ($genre != 'all') {$tax_query[] = [
        'taxonomy' => 'genre',
        'field' => 'slug',
        'terms' => explode(",", $genre),
    ];}
}

if (!empty($type)) {
    if ($type != 'all') {$tax_query[] = [
        'taxonomy' => 'type',
        'field' => 'slug',
        'terms' => explode(",", $type),
    ];}
}
if (!empty($status)) {
    if ($status != 'all') {$tax_query[] = [
        'taxonomy' => 'status',
        'field' => 'slug',
        'terms' => explode(",", $status),
    ];}
}

if (!empty($premiered)) {
    $meta_query[] = [
        'key' => 'kiranime_anime_premiered',
        'value' => $premiered,
        'compare' => 'LIKE',
    ];
}

if (!empty($tax_query)) {
    if (count($tax_query) > 1) {
        $query['tax_query'] = [
            'relation' => 'AND',
            ...$tax_query,
        ];
    } else {
        $query['tax_query'] = $tax_query;
    }
}

if (!empty($meta_query)) {
    $query['meta_query'] = $meta_query;
}
add_filter('posts_where', 'title_filter', 10, 2);
$queried = new WP_Query($query);
remove_filter('posts_where', 'title_filter', 10, 2);
?>
<section class="mt-17 lg:pt-5 container px-10">
    <!-- breadcrumb -->
    <nav aria-label="Breadcrumb" class="text-xs font-medium mb-5">
        <ol class="flex gap-2 items-center flex-wrap">
            <li>
                <a href="/">
                    Home
                </a>
            </li>
            <li>
                <div class="w-1 h-1 bg-gray-500 rounded-full"></div>
            </li>
            <li>
                <a href="?" class="text-gray-500">
                    filter
                </a>
            </li>
        </ol>
    </nav>
</section>
<div class="mb-17 pt-2 lg:pt-8 lg:grid grid-cols-12 lg:px-10 mx-auto w-full gap-5">
    <section class="col-span-full">
        <div class="w-full h-auto p-4 bg-gradient-to-b from-tertiary mb-10 rounded shadow-md">
            <form action="/filter" method="GET">
                <div class="text-sm font-medium mb-2 w-full">
                    Filter
                </div>
                <div class="flex items-center flex-wrap gap-5">
                    <input type="text" name="keyword" value="<?php echo $kw; ?>" placeholder="Search title here.."
                        class="py-2 px-4 text-sm w-full lg:w-max bg-tertiary bg-opacity-5 ring-1 ring-gray-500 focus:ring-sky-600 focus:ring outline-none border-none rounded">
                    <div
                        class="w-full lg:w-max flex gap-2 items-center px-2 py-1 border border-gray-500 rounded-md text-sm">
                        <label for="type" class="min-w-max flex-shrink-0">Type</label>
                        <select name="type" id="type"
                            class="block w-full pl-3 pr-2 py-1 text-sm outline-none border-none bg-tertiary bg-opacity-0 focus:outline-none text-sky-400 focus:border-none">
                            <option class="bg-tertiary" value="all"
                                <?php if ($type == '' || $type == 'all') {echo 'selected';}?>>All</option>
                            <option class="bg-tertiary" value="tv" <?php if ($type == 'tv') {echo 'selected';}?>>TV
                            </option>
                            <option class="bg-tertiary" value="special"
                                <?php if ($type == 'special') {echo 'selected';}?>>
                                Special</option>
                            <option class="bg-tertiary" value="ona" <?php if ($type == 'ona') {echo 'selected';}?>>ONA
                            </option>
                            <option class="bg-tertiary" value="ova" <?php if ($type == 'ova') {echo 'selected';}?>>OVA
                            </option>
                            <option class="bg-tertiary" value="movie" <?php if ($type == 'movie') {echo 'selected';}?>>
                                Movie
                            </option>
                        </select>
                    </div>
                    <div
                        class="w-full lg:w-max flex gap-2 items-center px-2 py-1 border border-gray-500 rounded-md text-sm">
                        <label for="status" class="min-w-max flex-shrink-0">Status</label>
                        <select name="status" id="status"
                            class="block w-full pl-3 pr-2 py-1 text-sm outline-none border-none bg-tertiary bg-opacity-0 focus:outline-none text-sky-400 focus:border-none">
                            <option class="bg-tertiary" value="all"
                                <?php if ($status == '' || $status == 'all') {echo 'selected';}?>>All</option>
                            <option class="bg-tertiary" value="completed"
                                <?php if ($status == 'completed') {echo 'selected';}?>>Finished Airing</option>
                            <option class="bg-tertiary" value="airing"
                                <?php if ($status == 'airing') {echo 'selected';}?>>
                                Currently Airing</option>
                            <option class="bg-tertiary" value="upcomming"
                                <?php if ($status == 'upcomming') {echo 'selected';}?>>Upcomming</option>
                        </select>
                    </div>
                    <div
                        class="w-full lg:w-max flex gap-2 items-center px-2 py-1 border border-gray-500 rounded-md text-sm">
                        <label for="season" class="min-w-max flex-shrink-0">Season</label>
                        <select name="season" id="season"
                            class="block w-full pl-3 pr-2 py-1 text-sm outline-none border-none bg-tertiary bg-opacity-0 focus:outline-none text-sky-400 focus:border-none">
                            <option class="bg-tertiary py-2" value="all"
                                <?php if ($season == '' || $season == 'all') {echo 'selected';}?>>All</option>
                            <option class="bg-tertiary py-2" value="winter"
                                <?php if ($season == 'winter') {echo 'selected';}?>>Winter</option>
                            <option class="bg-tertiary py-2" value="spring"
                                <?php if ($season == 'spring') {echo 'selected';}?>>Spring</option>
                            <option class="bg-tertiary py-2" value="summer"
                                <?php if ($season == 'summer') {echo 'selected';}?>>Summer</option>
                            <option class="bg-tertiary py-2" value="fall"
                                <?php if ($season == 'fall') {echo 'selected';}?>>
                                Fall</option>
                        </select>
                    </div>
                    <div
                        class="w-full lg:w-max flex gap-2 items-center px-2 py-1 border border-gray-500 rounded-md text-sm">
                        <label for="year" class="min-w-max flex-shrink-0">Year</label>
                        <select name="year" id="year"
                            class="block w-full pl-3 pr-2 py-1 text-sm outline-none border-none bg-tertiary bg-opacity-0 focus:outline-none text-sky-400 focus:border-none">
                            <option class="bg-tertiary" value="all"
                                <?php if ($year_selected == '' || $year_selected == 'all') {echo 'selected';}?>>All
                            </option>
                            <?php foreach ($years as $year): ?>
                            <option class="bg-tertiary" value="<?php echo $year ?>"
                                <?php if ($year == $year_selected) {echo 'selected';}?>><?php echo $year ?></option>
                            <?php endforeach;?>
                        </select>
                    </div>
                    <div
                        class="w-full lg:w-max flex gap-2 items-center px-2 py-1 border border-gray-500 rounded-md text-sm">
                        <?php $sorts = ['title_a_z' => 'Title ASC', 'title_z_a' => 'Title DESC', 'update' => 'Update', 'date' => 'Published', 'viewed' => 'Most Viewed']?>
                        <label for="orderby" class="min-w-max flex-shrink-0">Sort By</label>
                        <select name="orderby" id="orderby"
                            class="block w-full pl-3 pr-2 py-1 text-sm outline-none border-none bg-tertiary bg-opacity-0 focus:outline-none text-sky-400 focus:border-none">
                            <option class="bg-tertiary" value="default"
                                <?php if ($orderby == '' || $orderby == 'default') {echo 'selected';}?>>Default</option>
                            <?php foreach ($sorts as $key => $value): ?>
                            <option class="bg-tertiary" value="<?php echo $key ?>"
                                <?php if ($key == $orderby) {echo 'selected';}?>><?php echo $value ?></option>
                            <?php endforeach;?>
                        </select>
                    </div>
                </div>
                <div class="text-sm font-medium my-3 w-full">
                    Genre
                </div>
                <div class="flex flex-wrap gap-2 mb-5">
                    <?php $genres = get_terms(['taxonomy' => 'genre']);?>
                    <input type="hidden" name="genre" value="<?php echo $genre ?>" data-genre-input>
                    <?php foreach ($genres as $gnr): ?>
                    <div data-genre-slug="<?php echo $gnr->slug; ?>"
                        class="px-3 py-2 ring-1 cursor-pointer text-xs font-medium border-gray-500 rounded <?php if (in_array($gnr, $data_genre)) {echo 'ring-sky-400 text-sky-400';} else {echo 'ring-gray-500';}?>">
                        <?php echo $gnr->name ?>
                    </div>
                    <?php endforeach;?>
                </div>
                <button type="submit"
                    class="outline-none border-none shadow-lg drop-shadow-md rounded-md bg-sky-600 w-full block text-center text-sm font-medium col-span-full py-2 px-4 hover:shadow-xl hover:drop-shadow-lg hover:bg-sky-700">Filter</button>
            </form>
        </div>
        <div class="flex items-center justify-between">
            <h3 class="mb-4 text-2xl font-semibold leading-10 text-sky-400">
                Filter Results
            </h3>
            <span class="text-sm font-light"><?php echo $queried->found_posts ?> Results</span>
        </div>
        <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-7 gap-5">
            <?php if ($queried->have_posts()): while ($queried->have_posts()): $queried->the_post();
        ?>
            <div class="col-span-1">
                <?php get_template_part('template-parts/component', 'archive')?>
            </div>
            <?php endwhile;endif;?>
        </div>
        <?php
echo paginate_links(array(
    'base' => str_replace(999999999, '%#%', esc_url(get_pagenum_link(999999999))),
    'total' => $queried->max_num_pages,
    'current' => max(1, get_query_var('paged')),
    'format' => '?paged=%#%',
    'show_all' => false,
    'type' => 'list',
    'end_size' => 2,
    'mid_size' => 1,
    'prev_next' => false,
    'add_args' => false,
    'add_fragment' => '',
));
?>
    </section>
</div>

<?php get_footer();?>