<!DOCTYPE html>
<html <?php language_attributes();?>>

<head>
    <meta charset="<?php bloginfo('charset');?>">
    <meta name="viewport" content="width=device-width">
    <link rel="profile" href="http://gmpg.org/xfn/11">
    <link rel="pingback" href="<?php bloginfo('pingback_url');?>">
    <?php wp_head();?>
    <!-- <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" /> -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700;800;900&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/brands.min.css"
        integrity="sha512-lCU0XyQA8yobR7ychVxEOU5rcxs0+aYh/9gNDLaybsgW9hdrtqczjfKVNIS5doY0Y5627/+3UVuoGv7p8QsUFw=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <?php $isloggedin = is_user_logged_in();?>
    <script>
    const ajaxUrl = '<?php echo admin_url('admin-ajax.php') ?>';
    const isloggedIn = <?php echo json_encode($isloggedin); ?>;
    const bookmarkNonce = '<?php echo wp_create_nonce('kiranime_user_bookmark'); ?>';
    </script>
</head>

<body <?php body_class('bg-primary text-white antialiased font-montserrat');?>>

    <header id="header-data-single" style="height: 70px;"
        class=" bg-primary text-white text-sm fixed inset-0 z-999 leading-5 p-0 text-left transition-all duration-200">
        <?php get_template_part('template-parts/component', 'header')?>
    </header>

    <!-- login modal -->
    <?php if (!is_user_logged_in()) {?>
    <div id="login-form" class="fixed inset-0 hidden items-center justify-center z-50">
        <div data-login-overlay class="bg-black bg-opacity-80 fixed inset-0"></div>
        <div data-login-template>
            <?php get_template_part('template-parts/component', 'login')?>
        </div>
        <div data-register-template class="hidden" style="min-width: 400px;">
            <?php get_template_part('template-parts/component', 'register')?>
        </div>
    </div>
    <?php }?>

    <!-- overlay for menu sidebar when active -->
    <div data-sidebar-overlay class="hidden fixed inset-0 bg-primary bg-opacity-50 z-39"></div>

    <!-- Menu sidebar -->
    <div data-sidebar
        class="w-full max-w-xs lg:w-72 fixed inset-0 transform -translate-x-full transition-transform duration-150 ease-in-out h-full bg-primary z-999 overflow-y-auto overflow-x-hidden">
        <div sidebar-closer
            class="cursor-pointer px-4 py-2 rounded-full w-max max-w-max flex items-center gap-3 bg-white bg-opacity-20 font-medium text-sm my-5 mx-3">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" class="w-4 h-4">
                <path fill="currentColor"
                    d="M257.5 445.1l-22.2 22.2c-9.4 9.4-24.6 9.4-33.9 0L7 273c-9.4-9.4-9.4-24.6 0-33.9L201.4 44.7c9.4-9.4 24.6-9.4 33.9 0l22.2 22.2c9.5 9.5 9.3 25-.4 34.3L136.6 216H424c13.3 0 24 10.7 24 24v32c0 13.3-10.7 24-24 24H136.6l120.5 114.8c9.8 9.3 10 24.8.4 34.3z" />
            </svg>
            Close Menu
        </div>
        <div class="mt-5 min-h-full">
            <?php wp_nav_menu([
    'menu' => 'header',
    'container_class' => 'w-full',
    'menu_class' => 'flex flex-col text-sm p-0 m-0',
])?>
            <?php get_template_part('template-parts/component', 'genre-list');?>
        </div>
    </div>
    <main class="max-w-screen min-h-screen overflow-visible z-40 mb-10">