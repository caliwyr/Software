<?php

/**
 * Register taxonomy & post-type
 */

require_once 'core/post_type/anime-post-type.php';
require_once 'core/post_type/episode-post-type.php';
require_once 'core/post_type/user-notification.php';
require_once 'core/taxonomies/type-taxonomy.php';
require_once 'core/taxonomies/genre-taxonomy.php';
require_once 'core/taxonomies/status-taxonomy.php';
require_once 'core/taxonomies/attribute-taxonomy.php';

/**
 * Create taxonomies, pages
 */

require_once 'core/runner/preparing-theme.php';

/**
 * anime views meta
 */

require_once 'core/getter/anime-views.php';
require_once 'core/getter/anime-featured.php';
require_once 'core/getter/anime-search.php';
require_once 'core/getter/episode-getter.php';
require_once 'core/getter/config.php';

/**
 * meta box
 */

require_once 'core/metadata/anime-information-meta-box.php';
require_once 'core/metadata/episode-information.php';
require_once 'core/metadata/user-bookmark.php';

/**
 * auto download background images
 * required plugin notice
 */

require_once 'core/plugins/required_plugin.php';

/**
 * Widget
 */

require_once 'core/widget/genre-list.php';
require_once 'core/widget/popular-list.php';
require_once 'core/widget/most-popular.php';

/**
 * User login and register
 */

require_once 'core/user/login-register.php';
require_once 'core/user/usermeta.php';
require_once 'core/user/notification.php';
require_once 'core/user/import-anime.php';

/**
 * register and load widget
 */

function kiranime_load_widget()
{
    register_widget('Kiranime_Popular_List');
    register_widget('Kiranime_Genre_List');
    register_widget('Kiranime_Most_Popular');
}
add_action('widgets_init', 'kiranime_load_widget');

/**
 * Add theme configuration
 */

require_once 'core/configuration/main_configuration.php';
/**
 * Theme setup.
 */

function kiranime_setup()
{
    add_theme_support('title-tag');

    register_nav_menus(
        array(
            'footer' => __('Footer Menu', 'kiranime'),
            'header_side' => __('Header Side Menu', 'kiranime'),
        )
    );

    add_theme_support(
        'html5',
        array(
            'search-form',
            'comment-form',
            'comment-list',
            'gallery',
            'caption',
        )
    );
    register_sidebar(array(
        'name' => __('Homepage Sidebar'),
        'id' => 'homepage-sidebar',
        'description' => __('Show widget on homepage'),
        'before_widget' => '',
        'after_widget' => '<div class="h-5"></div>',
        'before_title' => '<div class="text-2xl leading-10 font-semibold px-5 lg:p-0 m-0 text-sky-600 mb-4">',
        'after_title' => '</div>',
    ));
    register_sidebar(array(
        'name' => __('Anime Info Sidebar'),
        'id' => 'anime-info-sidebar',
        'description' => __('Show widget on anime info'),
        'before_widget' => '',
        'after_widget' => '<div class="h-5"></div>',
        'before_title' => '<div class="text-2xl leading-10 font-semibold px-5 lg:p-0 m-0 text-sky-600 mb-4">',
        'after_title' => '</div>',
    ));
    register_sidebar(array(
        'name' => __('Archive Sidebar'),
        'id' => 'archive-sidebar',
        'description' => __('Show widget on archive'),
        'before_widget' => '',
        'after_widget' => '<div class="h-5"></div>',
        'before_title' => '<div class="text-2xl leading-10 font-semibold px-5 lg:p-0 m-0 text-sky-600 mb-4">',
        'after_title' => '</div>',
    ));
    register_sidebar(array(
        'name' => __('Article Sidebar'),
        'id' => 'article-sidebar',
        'description' => __('Show widget on article archive and single'),
        'before_widget' => '',
        'after_widget' => '<div class="h-5"></div>',
        'before_title' => '<div class="text-2xl leading-10 font-semibold px-5 lg:p-0 m-0 text-sky-600 mb-4">',
        'after_title' => '</div>',
    ));
    add_theme_support('custom-logo');
    add_theme_support('post-thumbnails');

    add_theme_support('align-wide');
    add_theme_support('wp-block-styles');

    add_theme_support('editor-styles');
    add_editor_style('css/editor-style.css');

}

add_action('after_setup_theme', 'kiranime_setup');

/**
 * Enqueue theme assets.
 */
function kiranime_enqueue_scripts()
{
    $theme_version = wp_get_theme()->get('Version'); //Production version
    // $theme_version = time(); //development version

    // $theme->get('Version')
    wp_enqueue_style('kiranime', kiranime_asset('css/app.css'), array(), $theme_version);
    wp_enqueue_script('kiranime', kiranime_asset('js/app.js'), array(), $theme_version, true);
    wp_enqueue_script('kiranime-tooltip', kiranime_asset('js/tooltip.js'), array(), $theme_version, true);
    wp_enqueue_script('kiranime-vue', kiranime_asset('js/vueApp.js'), array(), $theme_version, true);

    if (is_home()) {
        wp_enqueue_script('kiranime-slider', kiranime_asset('js/slider.js'), array(), $theme_version, true);
    }

    if (is_singular('episode')) {
        wp_enqueue_script('kiranime-episode', kiranime_asset('js/episode.js'), [], $theme_version, true);
        wp_enqueue_script('kiranime-vote', kiranime_asset('js/vote.js'), [], $theme_version, true);
    }

    if (is_page_template('page-mal.php')) {
        wp_enqueue_script('kiranime-mal-import', kiranime_asset('js/mal-import.js'), [], $theme_version, true);
    }
}

add_action('wp_enqueue_scripts', 'kiranime_enqueue_scripts');

/**
 * Get asset path.
 *
 * @param string  $path Path to asset.
 *
 * @return string
 */
function kiranime_asset($path)
{
    if (wp_get_environment_type() === 'production') {
        return get_stylesheet_directory_uri() . '/' . $path;
    }

    return add_query_arg('time', time(), get_stylesheet_directory_uri() . '/' . $path);
}

/**
 * Adds option 'li_class' to 'wp_nav_menu'.
 *
 * @param string  $classes String of classes.
 * @param mixed   $item The curren item.
 * @param WP_Term $args Holds the nav menu arguments.
 *
 * @return array
 */
function kiranime_nav_menu_add_li_class($classes, $item, $args, $depth)
{
    if (isset($args->li_class)) {
        $classes[] = $args->li_class;
    }

    if (isset($args->{"li_class_$depth"})) {
        $classes[] = $args->{"li_class_$depth"};
    }

    return $classes;
}

add_filter('nav_menu_css_class', 'kiranime_nav_menu_add_li_class', 10, 4);

/**
 * Adds option 'submenu_class' to 'wp_nav_menu'.
 *
 * @param string  $classes String of classes.
 * @param mixed   $item The curren item.
 * @param WP_Term $args Holds the nav menu arguments.
 *
 * @return array
 */
function kiranime_nav_menu_add_submenu_class($classes, $args, $depth)
{
    if (isset($args->submenu_class)) {
        $classes[] = $args->submenu_class;
    }

    if (isset($args->{"submenu_class_$depth"})) {
        $classes[] = $args->{"submenu_class_$depth"};
    }

    return $classes;
}

add_filter('nav_menu_submenu_css_class', 'kiranime_nav_menu_add_submenu_class', 10, 3);

/**
 * disable block editor for anime post-type
 */

add_filter('use_block_editor_for_post_type', function () {
    return false;
}, 10, 2);

/**
 * Remove default image sizes
 */
add_filter('intermediate_image_sizes_advanced', 'kiranime_remove_default_image');
function kiranime_remove_default_image($sizes)
{
    unset($sizes['small']); // 150px
    unset($sizes['medium']); // 300px
    unset($sizes['large']); // 1024px
    unset($sizes['medium_large']); // 768px
    return $sizes;
}

/**
 * add new image sizes
 */
add_action('after_setup_theme', 'kiranime_add_image_size');
function kiranime_add_image_size()
{
    add_image_size('featured-image', 96);
    add_image_size('trending-image', 182);
    add_image_size('homepage-image', 360);
    add_image_size('background-image', 1280);
}

// remove wp-emoji
remove_action('wp_head', 'print_emoji_detection_script', 7);
remove_action('wp_print_styles', 'print_emoji_styles');
remove_action('admin_print_scripts', 'print_emoji_detection_script');
remove_action('admin_print_styles', 'print_emoji_styles');

/**
 * add navigation class for header menu
 */

add_filter('nav_menu_css_class', 'special_nav_class', 10, 2);
function special_nav_class($classes, $item)
{
    if (in_array('current-menu-item', $classes)) {
        $classes[] = 'active ';
    }
    return $classes;
}

function kira_add_new_css_class($classes, $item, $args)
{
    if ($args->theme_location == 'header-menu') {
        $classes[] = 'nav-link';
    }
    return $classes;
}
add_filter('nav_menu_css_class', 'kira_add_new_css_class', 1, 3);

function add_menuclass($ulclass)
{
    return preg_replace('/<a /', '<a class="nav-link"', $ulclass);
}
add_filter('wp_nav_menu', 'add_menuclass');

/**
 * query var for advanced search
 */

add_filter('query_vars', function ($vars) {
    $vars[] = 'keyword';
    $vars[] = 'genre';
    $vars[] = 'type';
    $vars[] = 'status';
    $vars[] = 'season';
    $vars[] = 'year';
    $vars[] = 'orderby';
    $vars[] = 'order';
    return $vars;
});

/**
 * add filter to query, so search query will search only from title for search & filter
 */

function title_filter($where, $wp_query)
{
    global $wpdb;
    if ($search_term = $wp_query->get('keyword')) {
        $where .= ' AND ' . $wpdb->posts . '.post_title LIKE \'%' . esc_sql($wpdb->esc_like($search_term)) . '%\'';
    }
    return $where;
}

/**
 * redirect user to homepage if not logged in and trying to access user page
 */

function kiranime_redirect_unauthorized()
{
    if (is_page_template(['page-notification.php', 'page-profile.php', 'page-continue-watching.php', 'page-mal.php', 'page-user.php', 'page-watch-list.php', 'page-setting.php']) && !is_user_logged_in()) {
        wp_redirect(home_url('/'));
        exit();
    }
}
add_action('template_redirect', 'kiranime_redirect_unauthorized');

/**
 * disable admin_bar for all user except administrator
 */
add_action('after_setup_theme', 'remove_admin_bar');
function remove_admin_bar()
{
    if (!current_user_can('administrator') && !is_admin()) {
        show_admin_bar(false);
    }
}