"use strict";
let gcsources = document.getElementsByClassName("gcext-source");
for (let i = 0; i < gcsources.length; i++) {
    let itemtext = gcsources[i].innerHTML;
    let iteml = gcsources[i].dataset.dest;
    let a = document.createElement('a'); 
    let atext = document.createTextNode(itemtext);
    a.appendChild(atext); 
    a.href = iteml; 
    a.setAttribute("target", "_blank");
    a.setAttribute("rel", "nofollow");
    gcsources[i].replaceWith(a);
}