"use strict";

var popuptrigger = document.getElementsByClassName('gccsspopuptrigger');
for (let i = 0; i < popuptrigger.length; i++) {
    let togglerobj= popuptrigger[i];
    togglerobj.addEventListener('click', function (ev) {
        ev.preventDefault();
        let destination = togglerobj.dataset.popup;
        document.getElementById(destination).classList.toggle('active');
        document.body.classList.add('gcflowhidden');
    });
}

var popupclose = document.getElementsByClassName('gccpopupclose');
for (let i = 0; i < popupclose.length; i++) {
    let togglerobj= popupclose[i];
    togglerobj.addEventListener('click', function (ev) {
        ev.preventDefault();
        togglerobj.closest('.gccsspopup').classList.remove('active');
        document.body.classList.remove('gcflowhidden');
    });
}