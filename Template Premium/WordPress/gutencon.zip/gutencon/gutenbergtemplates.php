<?php

defined( 'ABSPATH' ) OR exit;

register_block_pattern_category(
    'gutpatterns',
    array( 'label' => __( 'Gutencon Patterns', 'gutencon' ) )
);

register_block_pattern(
    'gutencon/toptitleblock',
    array(
        'title'       => __( 'Top Title block for Full width page', 'gutencon' ),
        'categories' => array('gutpatterns'),
        'description' => _x( 'Title block Special for Customizable Full width post layout', 'Block pattern description', 'gutencon' ),
        'content'     => '<!-- wp:cover {"minHeight":259,"minHeightUnit":"px","gradient":"midnight","contentPosition":"center center","align":"full"} -->
        <div class="wp-block-cover alignfull has-background-dim has-background-gradient has-midnight-gradient-background" style="min-height:259px"><div class="wp-block-cover__inner-container"><!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":24,"lineHeight":"1"}},"textColor":"luminous-vivid-amber"} -->
        <p class="has-text-align-center has-luminous-vivid-amber-color has-text-color" style="font-size:24px;line-height:1"><strong>Subtitle</strong></p>
        <!-- /wp:paragraph -->
        
        <!-- wp:heading {"textAlign":"center","level":1,"style":{"typography":{"lineHeight":"1.1","fontSize":41}}} -->
        <h1 class="has-text-align-center" style="font-size:41px;line-height:1.1">Main title for customizable layout </h1>
        <!-- /wp:heading -->
        
        <!-- wp:paragraph {"align":"center","style":{"typography":{"lineHeight":"1.2"}}} -->
        <p class="has-text-align-center" style="line-height:1.2">Date of posting</p>
        <!-- /wp:paragraph --></div></div>
        <!-- /wp:cover -->
        
        <!-- wp:spacer {"height":15} -->
        <div style="height:15px" aria-hidden="true" class="wp-block-spacer"></div>
        <!-- /wp:spacer -->',
    )
);

register_block_pattern(
    'gutencon/darkpromoblock',
    array(
        'title'       => __( 'Promobox Dark', 'gutencon' ),
        'categories' => array('gutpatterns'),
        'blockTypes'    => array( 'gutencon/promobox' ),
        'description' => _x( 'Blue Promobox', 'Block pattern description', 'gutencon' ),
        'content'     => '<!-- wp:gutencon/promobox {"backgroundColor":"#000000","textColor":"#ffffff","btnColor":"#ff6900","highlightColor":"#ff6900"} /-->',
    )
);