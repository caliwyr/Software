<?php
if (!defined('ABSPATH')) {
    wp_die();
}
$gc_options = get_option('GC_Key');
$cc_username = isset($gc_options['cc_username']) ? $gc_options['cc_username'] : '';
$cc_purchase_code = isset($gc_options['cc_purchase_code']) ? $gc_options['cc_purchase_code'] : '';

require_once('lhelper.php');
// Create a new LicenseBoxAPI helper class.
$lbapi = new GCLicenseBoxAPI();

// Performs background license check, pass TRUE as 1st parameter to perform periodic verifications only.
$registeredlicense = false;
if ($cc_username && $cc_purchase_code) {
    $lb_verify_res = $lbapi->verify_license(true, sanitize_text_field($cc_purchase_code), sanitize_text_field($cc_username));
    if (!empty($lb_verify_res['status'])) {
        $registeredlicense = true;
    }
}
echo '<style>
.wrap{background:white;max-width: 900px;margin: 2.5em auto;border: 1px solid #dbdde2;box-shadow: 0 10px 20px #ececec; text-align:center}
.wrap .notice, .wrap .error{display:none}
.wrap h2{font-size:2em; margin-bottom:1em; font-weight:bold}
.gc-introtext{font-size:15px; margin: 0 auto 50px auto; max-width:600px}
.gc-intro-form{margin-bottom:50px;display: flex;justify-content: center; overflow:hidden}
.wrap h1{text-align: left;padding: 15px 20px;margin: -1px -1px 60px -1px;font-size: 13px;font-weight: bold;text-transform: uppercase;box-shadow: 0 3px 8px rgb(0 0 0 / 5%);}
.gc-padd {padding:25px;overflow: hidden;}
.gc-intro-form input {padding: 10px 15px;width: 30%;margin-right: 20px;float: left;}
.gc-intro-form .button-large{font-size:17px; font-weight: bold}
.plugin-browser{
    display: flex;
    justify-content: center;}
.plugin-browser .plugin {
    cursor: pointer;
    margin: 0 4% 4% 0;
    position: relative;
    width: 30.6%;
    border: 1px solid #dcdcde;
    box-shadow: 0 1px 1px -1px rgb(0 0 0 / 10%);
    box-sizing: border-box;
}
.plugin-screenshot {
    display: block;
    overflow: hidden;
    position: relative;
    -webkit-backface-visibility: hidden;
    transition: opacity .2s ease-in-out;
}
.plugin-screenshot img {
    height: auto;
    position: absolute;
    left: 0;
    top: 0;
    width: 100%;
    transition: opacity .2s ease-in-out;
}
.plugin-info {
    position: absolute;
    top: 77%;
    width: 100%;
    font-size: 14px;
    text-align: center;
    background: rgba(255, 255, 255, 0.75);
    padding: 5px;
    height: 40px;
    box-sizing: border-box;
}
.plugin-screenshot:after {
    padding-top: 75%;
	content: "";
    display: block;
}
.plugin-name {
    font-size: 15px;
    font-weight: 600;
    height: 18px;
    margin: 0;
    padding: 15px;
    box-shadow: inset 0 1px 0 rgb(0 0 0 / 10%);
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    background: #fff;
    background: rgba(255,255,255,.65);
	text-align: left;
}
.plugin-actions {
    opacity: 1;
    bottom: 0;
    top: auto;
    transform: translateY(0);
    -webkit-transform: translateY(0);
    border-left: none;
    margin: 0;
	position: absolute;
	right: 0;
    padding: 9px 15px;
    box-shadow: inset 0 1px 0 rgb(0 0 0 / 10%);
}
.plugin-actions .button {
    float: none;
	margin-right: 3px;
    margin-left: 3px;
}
</style>';
echo '<div class="gc-padd">';
if (($registeredlicense == true)) {
    echo '<p class="gc-introtext">' . esc_html__("As official buyer, you have access to bonus plugins. You can see them below.", "gutencon") . '<br><br> ' . esc_html__("Documentation for", "gutencon") . ' <a href="https://rehubdocs.wpsoul.com/docs/rehub-plugins-add-ons/rh-link-pro/" target="_blank">RH Link PRO</a> | <a href="https://youtu.be/9K1t-ODpgNI?t=285" target="_blank">RH Chart</a></p>';
} else {
    echo '<p class="gc-introtext">' . esc_html__("Please, register copy of your plugin to get access to bonus section. You can register plugin on next", "gutencon") . ' <a href="' . admin_url('admin.php?page=gutenconregister') . '">' . esc_html__("page", "gutencon") . '</a></p>';
}
?>

<div class="feature-section plugin-browser rendered">
    <div class="plugin">
        <div class="plugin-screenshot">
            <img src="<?php echo GUTENCON_PLUGIN_URL . 'admin/images/rhchart.jpg'; ?>" alt="plugin">
            <div class="plugin-info"><?php esc_html_e("RH Chart - dynamic chart builder", "gutencon"); ?></div>
        </div>
        <h3 class="plugin-name"><?php esc_html_e("Chart builder", "gutencon"); ?></h3>
        <div class="plugin-actions">
            <?php if ($registeredlicense == true) : ?>
                <a href="<?php echo esc_url($lb_verify_res['data']['plugins']['rh-chart']); ?>" class="button button-primary" title="Get link">Download</a>
            <?php else : ?>
                <?php printf('<a href="%s" class="button button-primary">%s</a>', admin_url('admin.php?page=gutenconregister'), esc_html__("Register plugin to get link", "gutencon")); ?>
            <?php endif; ?>
        </div>
    </div>
    <div class="plugin">
        <div class="plugin-screenshot">
            <img src="<?php echo GUTENCON_PLUGIN_URL . 'admin/images/rhlinkhider.png'; ?>" alt="plugin">
            <div class="plugin-info"><?php esc_html_e("For Links managing", "gutencon"); ?></div>
        </div>
        <h3 class="plugin-name">RH Link PRO</h3>
        <div class="plugin-actions">
            <?php if ($registeredlicense == true) : ?>
                <a href="<?php echo esc_url($lb_verify_res['data']['plugins']['rh-cloak-affiliate-links']); ?>" class="button button-primary" title="Get link">Download</a>
            <?php else : ?>
                <?php printf('<a href="%s" class="button button-primary">%s</a>', admin_url('admin.php?page=gutenconregister'), esc_html__("Register plugin to get link", "gutencon")); ?>
            <?php endif; ?>
        </div>
    </div>
    <div class="plugin">
        <div class="plugin-screenshot">
            <img src="<?php echo GUTENCON_PLUGIN_URL . 'admin/images/envato.jpg'; ?>" alt="plugin">
            <div class="plugin-info"><?php esc_html_e("For Autoupdates", "gutencon"); ?></div>
        </div>
        <h3 class="plugin-name">Envato Market</h3>
        <div class="plugin-actions">
            <?php if ($registeredlicense == true) : ?>
                <a href="https://wpsoul.net/i/envato-market.zip" class="button button-primary" title="Get link">Download</a>
            <?php else : ?>
                <?php printf('<a href="%s" class="button button-primary">%s</a>', admin_url('admin.php?page=gutenconregister'), esc_html__("Register plugin to get link", "gutencon")); ?>
            <?php endif; ?>
        </div>
    </div>
</div>
</div>