<?php
/*
Plugin Name: GutenCon
Plugin URI: https://1.envato.market/JZgzN
Description: Marketing and SEO Booster for Gutenberg
Version: 5.2
Author: Wpsoul
Author URI: https://wpsoul.com/
Text Domain: gutencon
Domain Path: /lang/
*/

namespace GutenCon;

if ( ! defined( 'ABSPATH' ) ) {
	wp_die();
}

define( 'GUTENCON_VERSION', '5.2' );
define( 'GUTENCON_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'GUTENCON_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

final class Init {

    public $disableconditioncss = false;

    private static $instance = null;
    public static function instance(){
        if(is_null(static::$instance)) {
            static::$instance = new static();
        }
        return static::$instance;
    }

    //Declare list of our blocks and asset dependencies
    public $gutblockassets = [
        'box' => array(
            'frontcss' => array(
                'boxfrontcss' => array(
                    'link' => GUTENCON_PLUGIN_URL.'assets/box/style.css',
                    'dependencies' => array(),
                )
            ),
            'frontjs' => array(),
            'editorjs' => array(),
        ),
        'titlebox' => array(
            'frontcss' => array(
                'titleboxfrontcss' => array(
                    'link' => GUTENCON_PLUGIN_URL.'assets/titlebox/style.css',
                    'dependencies' => array(),
                )
            ),
            'frontjs' => array(),
            'editorjs' => array(),
        ),
        'promobox' => array(
            'frontcss' => array(
                'promoboxfrontcss' => array(
                    'link' => GUTENCON_PLUGIN_URL.'assets/promobox/style.css',
                    'dependencies' => array(),
                )
            ),
            'frontjs' => array(),
            'editorjs' => array(),
        ),
        'event' => array(
            'frontcss' => array(
                'eventfrontcss' => array(
                    'link' => GUTENCON_PLUGIN_URL.'assets/event/style.css',
                    'dependencies' => array(),
                ),
                'gclightboxfront' => array(
                    'link' => GUTENCON_PLUGIN_URL.'assets/imagelightbox/imagelightbox.css',
                    'dependencies' => array(),
                ), 
            ),
            'frontjs' => array(
                'gclightboxjs' => array(
                    'link' => GUTENCON_PLUGIN_URL.'assets/imagelightbox/imagelightbox.js',
                    'dependencies' => array(),
                )
            ),
            'editorjs' => array(),
        ),
        'offerbox' => array(
            'frontcss' => array(
                'offerboxfrontcss' => array(
                    'link' => GUTENCON_PLUGIN_URL.'assets/offerbox/style.css',
                    'dependencies' => array(),
                )
            ),
            'frontjs' => array(),
            'editorjs' => array(),
        ),
        'comparison-table' => array(
            'frontcss' => array(
                'comparisonfrontcss' => array(
                    'link' => GUTENCON_PLUGIN_URL.'assets/comparison/style.css',
                    'dependencies' => array(),
                )
            ),
            'frontjs' => array(
                'gcequalizer' => array(
                    'link' => GUTENCON_PLUGIN_URL.'assets/comparison/equalizer.js',
                    'dependencies' => array(),
                ),
            ),
            'editorjs' => array(),
        ),
        'comparison-item' => array(
            'frontcss' => array(),
            'frontjs' => array(),
            'editorjs' => array(),
        ),
        'offerlisting' => array(
            'frontcss' => array(
                'offerlistingfrontcss' => array(
                    'link' => GUTENCON_PLUGIN_URL.'assets/offerlisting/style.css',
                    'dependencies' => array(),
                )
            ),
            'frontjs' => array(),
            'editorjs' => array(),
        ),
        'advanced-listing' => array(
            'frontcss' => array(
                'advlistfrontcss' => array(
                    'link' => GUTENCON_PLUGIN_URL.'assets/advanced-listing/style.css',
                    'dependencies' => array(),
                ),
                'gcaligncss' => array(
                    'link' => GUTENCON_PLUGIN_URL.'assets/extra/align.css',
                    'dependencies' => array(),
                ),
                'gctooltipcss' => array(
                    'link' => GUTENCON_PLUGIN_URL.'assets/extra/tooltip.css',
                    'dependencies' => array(),
                )  
            ),
            'frontjs' => array(),
            'editorjs' => array(),
        ),
        'offerlistingfull' => array(
            'frontcss' => array(
                'offerlistingfull' => array(
                    'link' => GUTENCON_PLUGIN_URL.'assets/offerlistingfull/style.css',
                    'dependencies' => array(),
                )
            ),
            'frontjs' => array(),
            'editorjs' => array(),
        ),
        'linelist' => array(
            'frontcss' => array(
                'linelistfrontcss' => array(
                    'link' => GUTENCON_PLUGIN_URL.'assets/linelist/style.css',
                    'dependencies' => array(),
                )
            ),
            'frontjs' => array(),
            'editorjs' => array(),
        ),
        'toctop' => array(
            'frontcss' => array(
                'toctopfrontcss' => array(
                    'link' => GUTENCON_PLUGIN_URL.'assets/toctop/style.css',
                    'dependencies' => array(),
                )
            ),
            'frontjs' => array(
                'gctoctopjs' => array(
                    'link' => GUTENCON_PLUGIN_URL.'assets/toctop/scrolltolist.js',
                    'dependencies' => array(),
                ),
            ),
            'editorjs' => array(),
        ),
        'versus' => array(
            'frontcss' => array(
                'versusfrontcss' => array(
                    'link' => GUTENCON_PLUGIN_URL.'assets/versus/style.css',
                    'dependencies' => array(),
                )
            ),
            'frontjs' => array(),
            'editorjs' => array(),
        ),
        'wclist' => array(
            'frontcss' => array(
                'offerlistingfrontcss' => array(
                    'link' => GUTENCON_PLUGIN_URL.'assets/offerlisting/style.css',
                    'dependencies' => array(),
                )
            ),
            'frontjs' => array(),
            'editorjs' => array(),
        ),
        'wcbox' => array(
            'frontcss' => array(
                'offerlistingfrontcss' => array(
                    'link' => GUTENCON_PLUGIN_URL.'assets/offerlisting/style.css',
                    'dependencies' => array(),
                ),
                'gctabsfront' => array(
                    'link' => GUTENCON_PLUGIN_URL.'assets/tabs/tabs.css',
                    'dependencies' => array(),
                ),    
                'gclightboxfront' => array(
                    'link' => GUTENCON_PLUGIN_URL.'assets/imagelightbox/imagelightbox.css',
                    'dependencies' => array(),
                ),             
            ),
            'frontjs' => array(
                'gctabsjs' => array(
                    'link' => GUTENCON_PLUGIN_URL.'assets/tabs/tabs.js',
                    'dependencies' => array(),
                ),
                'gclightboxjs' => array(
                    'link' => GUTENCON_PLUGIN_URL.'assets/imagelightbox/imagelightbox.js',
                    'dependencies' => array(),
                )
            ),
            'editorjs' => array(
                'gctabsjs' => array(
                    'link' => GUTENCON_PLUGIN_URL.'assets/tabs/tabs.js',
                    'dependencies' => array(),
                )
            ),
        ),
        'tabs' => array(
            'frontcss' => array(
                'gctabsfront' => array(
                    'link' => GUTENCON_PLUGIN_URL.'assets/tabs/tabs.css',
                    'dependencies' => array(),
                ),
                'gcaligncss' => array(
                    'link' => GUTENCON_PLUGIN_URL.'assets/extra/align.css',
                    'dependencies' => array(),
                )         
            ),
            'frontjs' => array(
                'gctabsjs' => array(
                    'link' => GUTENCON_PLUGIN_URL.'assets/tabs/tabs.js',
                    'dependencies' => array(),
                )
            ),
            'editorjs' => array(
                'gctabsjs' => array(
                    'link' => GUTENCON_PLUGIN_URL.'assets/tabs/tabs.js',
                    'dependencies' => array(),
                )
            ),
        ),
        'tab' => array(
            'frontcss' => array(),
            'frontjs' => array(),
            'editorjs' => array(),
        ),
        'swiper' => array(
            'frontcss' => array(
                'swiperfrontcss' => array(
                    'link' => GUTENCON_PLUGIN_URL.'assets/swiper/swiper-bundle.min.css',
                    'dependencies' => array(),
                )
            ),
            'frontjs' => array(
                'gcswiper' => array(
                    'link' => GUTENCON_PLUGIN_URL.'assets/swiper/init.js',
                    'dependencies' => array('swiper'),
                ),
            ),
            'editorjs' => array(),
        ),
        'swipe' => array(
            'frontcss' => array(),
            'frontjs' => array(),
            'editorjs' => array(),
        ),
        'accordion' => array(
            'frontcss' => array(
                'accordionfrontcss' => array(
                    'link' => GUTENCON_PLUGIN_URL.'assets/accordion/style.css',
                    'dependencies' => array(),
                ),           
            ),
            'frontjs' => array(
                'gcaccordionjs' => array(
                    'link' => GUTENCON_PLUGIN_URL.'assets/accordion/accordion.js',
                    'dependencies' => array(),
                ),
            ),
        ),
        'reviewbox' => array(
            'frontcss' => array(
                'reviewboxfrontcss' => array(
                    'link' => GUTENCON_PLUGIN_URL.'assets/reviewbox/style.css',
                    'dependencies' => array(),
                ),           
            )
        ),
        'scorebox' => array(
            'frontcss' => array(
                'scoreboxfrontcss' => array(
                    'link' => GUTENCON_PLUGIN_URL.'assets/scorebox/style.css',
                    'dependencies' => array(),
                ),           
            )
        ),
        'progressbar' => array(
            'frontcss' => array(),
            'frontjs' => array(),
            'editorjs' => array(),
        ),
        'numberheading' => array(
            'frontcss' => array(
                'numberheadingfrontcss' => array(
                    'link' => GUTENCON_PLUGIN_URL.'assets/numberheading/style.css',
                    'dependencies' => array(),
                ),           
            )
        ),
        'proscons' => array(
            'frontcss' => array(
                'prosboxfrontcss' => array(
                    'link' => GUTENCON_PLUGIN_URL.'assets/proscons/style.css',
                    'dependencies' => array(),
                ),           
            )
        ),
        'howto' => array(
            'frontcss' => array(
                'howtofrontcss' => array(
                    'link' => GUTENCON_PLUGIN_URL.'assets/howto/style.css',
                    'dependencies' => array(),
                ),           
            )
        ),
        'video' => array(
            'frontcss' => array(
                'gc-video' => array(
                    'link' => GUTENCON_PLUGIN_URL.'assets/video/gc-video.css',
                    'dependencies' => array(),
                ),            
            ),
            'frontjs' => array(
                'gc-video' => array(
                    'link' => GUTENCON_PLUGIN_URL.'assets/video/gc-video.js',
                    'dependencies' => array(),
                ),
            ),
        ),
        'countdown' => array(
            'frontcss' => array(
                'gccountdowncss' => array(
                    'link' => GUTENCON_PLUGIN_URL.'assets/countdown/style.css',
                    'dependencies' => array(),
                ),   
                'gcaligncss' => array(
                    'link' => GUTENCON_PLUGIN_URL.'assets/extra/align.css',
                    'dependencies' => array(),
                ),          
            ),
            'frontjs' => array(
                'gccountdownjs' => array(
                    'link' => GUTENCON_PLUGIN_URL.'assets/countdown/index.js',
                    'dependencies' => array(),
                ),
            ),
        ),
        'counter' => array(
            'frontcss' => array( 
                'gccountercss' => array(
                    'link' => GUTENCON_PLUGIN_URL.'assets/counter/style.css',
                    'dependencies' => array(),
                ), 
                'gcaligncss' => array(
                    'link' => GUTENCON_PLUGIN_URL.'assets/extra/align.css',
                    'dependencies' => array(),
                ),          
            ),
            'frontjs' => array(
                'gccounterjs' => array(
                    'link' => GUTENCON_PLUGIN_URL.'assets/counter/index.js',
                    'dependencies' => array(),
                ),
            ),
        ),
        'contenttoggler' => array(
            'frontcss' => array( 
                'gccontenttogglercss' => array(
                    'link' => GUTENCON_PLUGIN_URL.'assets/contenttoggler/style.css',
                    'dependencies' => array(),
                ),         
            ),
            'frontjs' => array(
                'gccontenttogglerjs' => array(
                    'link' => GUTENCON_PLUGIN_URL.'assets/contenttoggler/index.js',
                    'dependencies' => array(),
                ),
            ),
        ),
        'popupbutton' => array(
            'frontcss' => array( 
                'gcpopupbuttoncss' => array(
                    'link' => GUTENCON_PLUGIN_URL.'assets/popupbutton/style.css',
                    'dependencies' => array(),
                ),         
            ),
            'frontjs' => array(
                'gcpopupbuttonjs' => array(
                    'link' => GUTENCON_PLUGIN_URL.'assets/popupbutton/index.js',
                    'dependencies' => array(),
                ),
            ),
        ),
        'slider' => array(
            'frontcss' => array( 
                'gcgutslidercss' => array(
                    'link' => GUTENCON_PLUGIN_URL.'assets/slider/slider.css',
                    'dependencies' => array(),
                ),  
                'gclightboxfront' => array(
                    'link' => GUTENCON_PLUGIN_URL.'assets/imagelightbox/imagelightbox.css',
                    'dependencies' => array(),
                ),        
            ),
            'frontjs' => array(
                'gcgutsliderjs' => array(
                    'link' => GUTENCON_PLUGIN_URL.'assets/slider/index.js',
                    'dependencies' => array(),
                ),
                'gclightboxjs' => array(
                    'link' => GUTENCON_PLUGIN_URL.'assets/imagelightbox/imagelightbox.js',
                    'dependencies' => array(),
                )
            ),
            'editorjs' => array(
                'gcgutsliderback' => array(
                    'link' => GUTENCON_PLUGIN_URL.'assets/slider/indexbackend.js',
                    'dependencies' => array(),
                )
            ),
        ),
    ];

    private function __construct(){
        //Parser class
        require_once GUTENCON_PLUGIN_DIR .'class-rest.php';
        require_once GUTENCON_PLUGIN_DIR .'admin/class-admin.php';
        require_once GUTENCON_PLUGIN_DIR .'gutenbergtemplates.php';
        require_once GUTENCON_PLUGIN_DIR .'/assets/assetloading.php';

        //Send users on first install to welcome page
        
        register_activation_hook(__FILE__, function () {
            add_option('gutencon_activation_redirect', true);
        });
        add_action('admin_init', function () {
            if (get_option('gutencon_activation_redirect', false)) {
                delete_option('gutencon_activation_redirect');
                exit( wp_redirect("admin.php?page=gutenconregister") );
            }
        });

        //Register Gutenberg categories
        add_filter('block_categories_all', array($this,'block_categories_filter'), 10, 2);

        //Register our blocks and classes
        foreach($this->gutblockassets as $gutname=>$gutvalue){
            if (file_exists(GUTENCON_PLUGIN_DIR .'blockrender/'.$gutname.'/block.php')){
                require_once GUTENCON_PLUGIN_DIR .'blockrender/'.$gutname.'/block.php';
            }
        }
        $options = get_option( 'globalgutencon', array() );
        $checkforcssloading = (!empty($options['cssdiscondition'])) ? $options['cssdiscondition'] : false;
        if($checkforcssloading) $this->disableconditioncss = true;
        
        add_action('init', array( $this, 'init' )); // hook init our blocks
        add_action('enqueue_block_assets', array( $this, 'guten_assets' )); //hook add conditional frontend and backend assets
        add_filter('render_block', array( $this, 'guten_render_assets' ), 10, 2); //conditional assets loading

        if('rehub-theme' != get_option( 'template')){
            //Show Reusable blocks column
            add_action( 'registered_post_type', array( $this, 'gctemplate_menu_display'), 10, 2 );
            add_filter( 'manage_wp_block_posts_columns', array( $this, 'gctemplate_screen_add_column') );
            add_action( 'manage_wp_block_posts_custom_column' , array( $this, 'gctemplate_screen_fill_column'), 1000, 2);
            // Force Block editor for Reusable Blocks even when Classic editor plugin is activated
            add_filter( 'use_block_editor_for_post', array( $this, 'gctemplate_gutenberg_post'), 1000, 2 );
            add_filter( 'use_block_editor_for_post_type', array( $this, 'gctemplate_gutenberg_post_type'), 1000, 2 );
            //Shortcode output for reusable blocks
            add_shortcode( 'wp_reusable_render', array($this, 'gctemplate_shortcode_function'));
            //Ajax render action
            add_action( 'wp_ajax_gc_el_reusable_load', array($this, 'gc_el_reusable_load'));
            add_action( 'wp_ajax_nopriv_gc_el_reusable_load', array($this, 'gc_el_reusable_load'));
        }
    }

    //Function to display Reusable section in menu
    function gctemplate_menu_display( $type, $args ) {
        if ( 'wp_block' !== $type ) { return; }
        $args->show_in_menu = true;
        $args->_builtin = false;
        $args->labels->name = esc_html__( 'Block template', 'gutencon' );
        $args->labels->menu_name = esc_html__( 'Reusable templates', 'gutencon' );
        $args->menu_icon = 'dashicons-screenoptions';
        $args->menu_position = 58;
    }

    //Columns in Reusable section
    function gctemplate_screen_add_column( $columns ) {
        $columns = array(
            'cb' => '<input type="checkbox" />',
            'title' => esc_html__( 'Block title', 'gutencon' ),
            'gc-reusable-preview' => esc_html__( 'Usage', 'gutencon' ),
        );
        return $columns;
    }

    //Render function for Columns in Reusable Sections
    function gctemplate_screen_fill_column( $column, $ID ) {
        global $post;
        switch( $column ) {
    
            case 'gc-reusable-preview' :
    
                echo '<p><input type="text" style="width:350px" value="[wp_reusable_render id=\'' . $ID . '\']" readonly=""></p>';
                echo '<p>' . esc_html__( 'Shortcode for Ajax render:', 'gutencon' ) . '<br><input type="text" style="width:350px" value="[wp_reusable_render ajax=1 height=100 id=\'' . $ID . '\']" readonly="">';
                echo '<p>' . esc_html__( 'Hover trigger:', 'gutencon' ) . ' <code>gc-el-onhover load-block-' . $ID . '</code>';
                echo '<p>' . esc_html__( 'Click trigger:', 'gutencon' ) . ' <code>gc-el-onclick load-block-' . $ID . '</code>';
                echo '<p>' . esc_html__( 'On view trigger:', 'gutencon' ) . ' <code>gc-el-onview load-block-' . $ID . '</code>';
                break;
    
            default :
                break;
        }
    }

    //Render shortcode function
    function gctemplate_shortcode_function( $atts ){
        extract(shortcode_atts(
            array(
                'id' => '',
                'ajax'=>'',
                'height'=>'',
                'renderonview'=>''
        ), $atts));
        if(!isset($id) || empty($id)){
            return '';
        }
        if(!is_numeric($id)){
            $postget = get_page_by_path($id, OBJECT, array('wp_block') );
            $id = $postget->ID;
        }
        if(!empty($ajax)){
            wp_enqueue_style( 'wp-block-library' );
            wp_enqueue_style( 'gcpreloadercss' );
            wp_enqueue_script( 'gcelajaxloader' );
            $scriptvars = array( 
                'reusablenonce' => wp_create_nonce('gcreusable'),
                'ajax_url' => admin_url( 'admin-ajax.php', 'relative' ),	
            );
            wp_localize_script( 'gcelajaxloader', 'gcreusablevars', $scriptvars );
            $content = '<div class="gc-ajax-load-block gc-ajax-load-block-'.$id.'"></div>'; 
            if(!empty($height)){
                $content = '<div style="min-height:'.$height.'">'.$content.'</div>';
            }       
        } else{
            $content_post = get_post( $id );
            $content = $content_post->post_content;
            $content = do_blocks($content);
            $content = do_shortcode($content);
            $content = preg_replace( '%<p>&nbsp;\s*</p>%', '', $content ); 
            $content = preg_replace('/^(?:<br\s*\/?>\s*)+/', '', $content);
        }
        return $content;
    }

    //Load reusable Ajax function
    function gc_el_reusable_load() {
        check_ajax_referer( 'gcreusable', 'security' );  
        $post_id = intval($_POST['post_id']);
        $content_post = get_post(  $post_id );
        $content = $content_post->post_content;
        $content = apply_filters( 'the_content', $content);
        if( $content){
            wp_send_json_success($content);
        }else{
            wp_send_json_success('fail');
        }
        wp_die();
    }

    //Show gutenberg editor on reusable section even if Classic editor plugins enabled
    function gctemplate_gutenberg_post( $use_block_editor, $post ) {
        if ( empty( $post->ID ) ) return $use_block_editor;
        if ( 'wp_block' === get_post_type( $post->ID ) ) return true;
        return $use_block_editor;
    }
    function gctemplate_gutenberg_post_type( $use_block_editor, $post_type ) {
        if ( 'wp_block' === $post_type ) return true;
        return $use_block_editor;
    }

    //Declare category of blocks
    function block_categories_filter($categories, $post){
        array_splice($categories, 3, 0, array(
            array(
                'slug'  => 'gutencon-modules',
                'title' => esc_html__('Gutencon modules', 'gutencon'),
            )
        ));
        return $categories;
    }

    // init our blocks
	public function init(){
        load_plugin_textdomain( 'gutencon', false, basename( __DIR__ ) . '/lang' ); //translation files

        // automatically load dependencies and version
        $asset_file = include( GUTENCON_PLUGIN_DIR. 'build/index.asset.php');

        //Common main script file for blocks for editor
        wp_register_script(
            'gutencon_common_js',
            GUTENCON_PLUGIN_URL. 'build/index.js',
            $asset_file['dependencies'],
            $asset_file['version']
        );

        $options = get_option( 'globalgutencon', array() );
        $duplicaterh = (!empty($options['duplicaterh'])) ? $options['duplicaterh'] : false;

        wp_localize_script('gutencon_common_js','GCGutenberg', array(
            'disableduplicate' => ('rehub-theme' == get_option( 'template') && !$duplicaterh),
        ));

        //Translation in scripts
        if ( function_exists( 'wp_set_script_translations' ) ) {
            wp_set_script_translations( 'gutencon_common_js', 'gutencon' );
        }

        //Common Editor styles for blocks for editor
        wp_register_style(
            'gutencon_common_css',
            GUTENCON_PLUGIN_URL. 'build/index.css',
            array( 'wp-edit-blocks' ),
            $asset_file['version']
        );
        //wp_style_add_data( 'gutencon_common_css', 'rtl', true );

        //Block registration and frontend conditional asset registration
        foreach($this->gutblockassets as $gutname=>$gutvalue){
            if(!empty($gutvalue['frontcss'])){
                foreach ($gutvalue['frontcss'] as $cssname=>$cssvalue){
                    wp_register_style(
                        $cssname,
                        $cssvalue['link'],
                        $cssvalue['dependencies'],
                        GUTENCON_VERSION
                    );
                }
            }
            if(!empty($gutvalue['frontjs'])){
                foreach ($gutvalue['frontjs'] as $jsname=>$jsvalue){
                    wp_register_script(
                        $jsname,
                        $jsvalue['link'],
                        $jsvalue['dependencies'],
                        GUTENCON_VERSION,
                        true
                    );
                }
            }
            if(!empty($gutvalue['editorjs'])){
                foreach ($gutvalue['editorjs'] as $jsname=>$jsvalue){
                    wp_register_script(
                        $jsname,
                        $jsvalue['link'],
                        $jsvalue['dependencies'],
                        GUTENCON_VERSION,
                        true
                    );
                }
            }
        }

        //Additional registration for complex blocks
		wp_register_style( 'simplelightbox',  GUTENCON_PLUGIN_URL.'assets/video/simpleLightbox.min.css', array(), GUTENCON_VERSION );
		wp_register_script( 'simplelightbox',  GUTENCON_PLUGIN_URL.'assets/video/simpleLightbox.min.js', array(), GUTENCON_VERSION, true );
		wp_register_style( 'swiper',  GUTENCON_PLUGIN_URL.'assets/swiper/swiper-bundle.min.css', array(), '7.0' );
		wp_register_script( 'swiper',  GUTENCON_PLUGIN_URL.'assets/swiper/swiper-bundle.min.js', array(), '7.0', true );
        wp_register_script( 'gcextsource',  GUTENCON_PLUGIN_URL.'assets/formatsource/index.js', array(), GUTENCON_VERSION, true );
        wp_register_script( 'gctoggler',  GUTENCON_PLUGIN_URL.'assets/toggle/toggle.js', array(), GUTENCON_VERSION, true );
        wp_register_script( 'gcfilterpanel',  GUTENCON_PLUGIN_URL.'assets/filterpanel/index.js', array(), GUTENCON_VERSION, true );
        wp_register_script( 'gcajaxpagination',  GUTENCON_PLUGIN_URL.'assets/filterpanel/ajaxpagination.js', array(), GUTENCON_VERSION, true );

        //Script for ajax reusable loading
        wp_register_script( 'gcelajaxloader',  GUTENCON_PLUGIN_URL.'assets/reusable/index.js', array(), GUTENCON_VERSION, true );
        wp_register_style( 'gcpreloadercss',  GUTENCON_PLUGIN_URL.'assets/reusable/preloader.css', array(), GUTENCON_VERSION );
        

        //Ajax actions
        add_action( 'wp_ajax_gccheck_youtube_url', array( $this, 'gccheck_youtube_url') );
        add_action( 'wp_ajax_gc_filterpost', array($this, 'ajax_action_gc_filterpost') );
        add_action( 'wp_ajax_nopriv_gc_filterpost', array($this, 'ajax_action_gc_filterpost') );

	}

	public function gccheck_youtube_url(){
		$url = $_POST['url'];
		$max = wp_safe_remote_head($url);
		wp_send_json_success( wp_remote_retrieve_response_code($max) );
	}

    //Frontend and backend conditional asset enqueue
    public function guten_assets() {

        //root styles
        $options = get_option( 'globalgutencon', array() );
        $btnbgcolor = (!empty($options['btnbgcolor'])) ? $options['btnbgcolor'] : '#de1414';
        $btncolor = (!empty($options['btncolor'])) ? $options['btncolor'] : '#ffffff';
        $gc_global_css = ':root{--gcbtnbg: '.$btnbgcolor.';--gcbtncolor: '.$btncolor.';}';

        wp_add_inline_style( 'wp-block-library', $gc_global_css );

        // conditional scripts
        if(!is_admin()){
   
        }
        else{
            foreach($this->gutblockassets as $gutname=>$gutvalue){
                if(!empty($gutvalue['editorjs'])){  
                    foreach ($gutvalue['editorjs'] as $jsname=>$jsvalue){
                        wp_enqueue_script($jsname);
                    }                      
                }
            }            
        }
    }

    public function guten_render_assets($html, $block){
        if(!$this->disableconditioncss){
            static $renderedg_styles = [];
        }
        foreach($this->gutblockassets as $gutname=>$gutvalue){
            if(!empty($gutvalue['frontcss']) || !empty($gutvalue['frontjs']) ){
                if(isset( $block['blockName'] ) && $block['blockName'] === 'gutencon/'.$gutname){
                    if(!empty($gutvalue['frontcss'])){
                        foreach ($gutvalue['frontcss'] as $cssname=>$cssvalue){
                            if($this->disableconditioncss){
                                ob_start();
                                    echo '<style scoped>' . gutencon_inline_assets( $cssname ) . '</style>';
                                    $dynamic_css = ob_get_contents();
                                ob_end_clean();
                                $html = $dynamic_css.$html;                               
                            }else{
                                if(! in_array( $cssname, $renderedg_styles, true) || defined( 'ICL_LANGUAGE_CODE' )){
                                    //$stylesheet = $cssvalue['link'];
                                    ob_start();
                                        echo '<style scoped>' . gutencon_inline_assets( $cssname ) . '</style>';
                                        $dynamic_css = ob_get_contents();
                                    ob_end_clean();
                                    $html = $dynamic_css.$html;
                                    $renderedg_styles[] = $cssname;
                                }
                            }

                            //wp_add_inline_style( 'wp-block-library', $dynamic_css );
                        }
                    }   
                    if(!empty($gutvalue['frontjs'])){
                        foreach ($gutvalue['frontjs'] as $jsname=>$jsvalue){
                            if(!is_admin()) wp_enqueue_script($jsname);
                            
                        }
                    }                      
                }
            }
        }
        if(false !== strpos( json_encode($block), 'gcext-source' )){
            wp_enqueue_script( 'gcextsource');
        }
        if( $block['blockName'] === 'gutencon/video' ){
            if( $block['attrs']['provider'] === "vimeo" ){
                wp_enqueue_script( 'vimeo-player', 'https://player.vimeo.com/api/player.js', array(), true, '1.0' );
            }
            
            if( isset($block['attrs']['overlayLightbox']) && $block['attrs']['overlayLightbox'] ){
                wp_enqueue_style( 'simplelightbox');
                wp_enqueue_script( 'simplelightbox' );
            }
            $width = isset($block['attrs']['width']) ? $block['attrs']['width'] : '';
            $height = isset($block['attrs']['height']) ? $block['attrs']['height'] : '';
            $block_style = "#gc-video-" . $block['attrs']['blockId']. "{";
                if(!empty($width) && $width['desktop']['size'] > 0){
                    $block_style .= "width: " . $width['desktop']['size'] . $width['desktop']['unit'] .";";
                }
                if(!empty($height) && $height['desktop']['size'] > 0){
                    $block_style .= "height: " . $height['desktop']['size'] . $height['desktop']['unit'] .";";
                }
            $block_style .= "} @media (min-width: 1024px) and (max-width: 1140px) {";
            $block_style .= "#gc-video-" . $block['attrs']['blockId']. "{";
                if(!empty($width) && $width['landscape']['size'] > 0){
                    $block_style .= "width: " . $width['landscape']['size'] . $width['landscape']['unit'] .";";
                }
                if(!empty($height) && $height['landscape']['size'] > 0){
                    $block_style .= "height: " . $height['landscape']['size'] . $height['landscape']['unit'] .";";
                }
            $block_style .= "}";
            $block_style .= "} @media (min-width: 768px) and (max-width: 1023px) {";
            $block_style .= "#gc-video-" . $block['attrs']['blockId']. "{";
                if(!empty($width) && $width['tablet']['size'] > 0){
                    $block_style .= "width: " . $width['tablet']['size'] . $width['tablet']['unit'] .";";
                }
                if(!empty($height) && $height['tablet']['size'] > 0){
                    $block_style .= "height: " . $height['tablet']['size'] . $height['tablet']['unit'] .";";
                }
            $block_style .= "}";
            $block_style .= "} @media (max-width: 767px) {";
            $block_style .= "#gc-video-" . $block['attrs']['blockId']. "{";
                if(!empty($width) && $width['mobile']['size'] > 0){
                    $block_style .= "width: " . $width['mobile']['size'] . $width['mobile']['unit'] .";";
                }
                if(!empty($height) && $height['mobile']['size'] > 0){
                    $block_style .= "height: " . $height['mobile']['size'] . $height['mobile']['unit'] .";";
                }
            $block_style .= "} }";
            $html = '<style scoped>'.$block_style.'</style>'.$html;
            //wp_add_inline_style( 'wp-block-library', $block_style );
        }

        if ( $block['blockName'] === 'gutencon/comparison-table' ) {
            if(isset( $block['attrs']['responsiveView']) && $block['attrs']['responsiveView'] == 'slide'){
                wp_enqueue_style('swiper');
                wp_enqueue_script('swiper');
            }
        }

        if ( $block['blockName'] === 'gutencon/swiper' ) {
            wp_enqueue_script('swiper');
        }

        if ( $block['blockName'] === 'gutencon/tabs' ) {
            if(isset( $block['attrs']['swiper'])){
                wp_enqueue_style('swiper');
                wp_enqueue_script('swiper');
            }
        }

        if ( $block['blockName'] === 'gutencon/offerlistingfull' ) {
            if(!empty( $block['attrs']['enableexpand'])){
                wp_enqueue_script('gctoggler');
            }
        }
        if ( $block['blockName'] === 'gutencon/advanced-listing' ) {
            if(!empty( $block['attrs']['listargs']['togglelink']) && $block['attrs']['listargs']['togglelink'] !='no'){
                wp_enqueue_script('gctoggler');
            }
            if(!empty($block['attrs']['filterpanelenable'])){
                wp_enqueue_script('gcfilterpanel');
                $scriptvars = array( 
                    'filternonce' => wp_create_nonce('filterpanel'),
                    'ajax_url' => admin_url( 'admin-ajax.php', 'relative' ),	
                );
                wp_localize_script( 'gcfilterpanel', 'gcscriptvars', $scriptvars );
            }
        }
        return $html;
    }

    public function ajax_action_gc_filterpost() {  
        check_ajax_referer( 'filterpanel', 'security' );
        $args = (!empty($_POST['filterargs'])) ? $this->gc_sanitize_multi_arrays(json_decode(stripslashes($_POST['filterargs']), true)) : array();
        $innerargs = (!empty($_POST['innerargs'])) ? $this->gc_sanitize_multi_arrays(json_decode(stripslashes($_POST['innerargs']), true)) : array();
        $offset = (!empty($_POST['offset'])) ? intval( $_POST['offset'] ) : 0;
        $template = (!empty($_POST['template'])) ? sanitize_text_field( $_POST['template'] ) : '';
        $sorttype = (!empty($_POST['sorttype'])) ? $this->gc_sanitize_multi_arrays(json_decode(stripslashes($_POST['sorttype']), true)) : '';
        $tax = (!empty($_POST['tax'])) ? $this->gc_sanitize_multi_arrays(json_decode(stripslashes($_POST['tax']), true)) : '';
        //$containerid = (!empty($_POST['containerid'])) ? sanitize_text_field( $_POST['containerid'] ) : '';
        if ($template == '') return;
        $response = $page_sorting = '';

        if ($offset !='') {$args['offset'] = $offset;}
        $offsetnext = (!empty($args['posts_per_page'])) ? (int)$offset + $args['posts_per_page'] : (int)$offset + 12;
        //$perpage = (!empty($args['posts_per_page'])) ? $args['posts_per_page'] : 12;
        $args['no_found_rows'] = true;
        $args['post_status'] = 'publish';   

        if(!empty($sorttype) && is_array($sorttype)) { //if sorting panel  
            $filtertype = $filtermetakey = $filtertaxkey = $filtertaxtermslug = $filterorder = $filterdate = $filterorderby = $filterpricerange = $filtertaxcondition = '';
            $page_sorting = ' data-sorttype=\''.json_encode($sorttype).'\'';
            extract($sorttype);
            if($filterorderby){
                $args['orderby'] = $filterorderby;
            }        
            if(!empty($filtertype) && $filtertype =='comment') {
                $args['orderby'] = 'comment_count';
            }
            if($filtertype =='meta' && !empty($filtermetakey)) { //if meta key sorting
                if(!empty($args['meta_value'])){
                    $args['meta_query'] = array(array(
                        'key' => $args['meta_key'],
                        'value' => $args['meta_value'],
                        'compare' => '=',
                    ));
                    unset($args['meta_value']); 
                }           
                $args['orderby'] = 'meta_value_num date';
                $args['meta_key'] = esc_html($filtermetakey);
            }      
            if($filtertype =='pricerange' && !empty($filterpricerange)) { //if meta key sorting
                $price_range_array = array_map( 'trim', explode( "-", $filterpricerange ) );
                $keymeta = (!empty($args['post_type']) && $args['post_type']=='product') ? '_price' : 'rehub_main_product_price';
                $args['meta_query'][] = array(
                    'key'     => $keymeta,
                    'value'   => $price_range_array,
                    'type'    => 'numeric',
                    'compare' => 'BETWEEN',
                );
                if ($filterorderby == 'view' || $filterorderby == 'thumb' || $filterorderby == 'discount' || $filterorderby == 'price'){
                    $args['orderby'] = 'meta_value_num';
                }       
                if ($filterorderby == 'view'){
                    $args['meta_key'] = 'rehub_views';
                }
                if ($filterorderby == 'thumb'){
                    $args['meta_key'] = 'post_hot_count';
                }
                if ($filterorderby == 'wish'){
                    $args['meta_key'] = 'post_wish_count';
                }            
                if ($filterorderby == 'discount'){
                    $args['meta_key'] = '_rehub_offer_discount';
                }
                if ($filterorderby == 'price'){
                    $args['meta_key'] = $keymeta;
                }            
            }                                      
            if($filtertype =='tax' && !empty($filtertaxkey) && !empty($filtertaxtermslug)) { //if taxonomy sorting
                if (!empty($args['tax_query']) && !$filtertaxcondition) {
                    unset($args['tax_query']);
                }  
                if(is_array($filtertaxtermslug)){
                    $filtertaxtermslugarray = $filtertaxtermslug;
                }  
                else{
                    $filtertaxtermslugarray = array_map( 'trim', explode( ",", $filtertaxtermslug) );
                } 
                if($filtertaxcondition){
                    $args['tax_query'][] = array(
                        'taxonomy' => $filtertaxkey,
                        'field'    => 'slug',
                        'terms'    => $filtertaxtermslugarray,
                    );                
                } 
                else{
                    $args['tax_query'] = array (
                        array(
                            'taxonomy' => $filtertaxkey,
                            'field'    => 'slug',
                            'terms'    => $filtertaxtermslugarray,
                        )
                    );
                }    
            }
            if($tax && $filtertype != 'tax'){
                $args['tax_query'] = array (
                    array(
                        'taxonomy' => $tax['filtertaxkey'],
                        'field'    => 'slug',
                        'terms'    => $tax['filtertaxtermslug'],
                    )
                );
            }        
            if($filterorder) { $args['order'] = $filterorder; }
            if($filterdate) { //if date sorting
                if (!empty($args['date_query']) || $filterdate =='all') {
                    if(isset($args['date_query'])){
                        unset($args['date_query']);
                    }
                }
                if ($filterdate == 'day') {     
                    $args['date_query'][] = array(
                        'after'  => '1 day ago',
                    );
                }
                if ($filterdate == 'week') {    
                    $args['date_query'][] = array(
                        'after'  => '7 days ago',
                    );
                }   
                if ($filterdate == 'month') {     
                    $args['date_query'][] = array(
                        'after'  => '1 month ago',
                    );
                }   
                if ($filterdate == 'year') {     
                    $args['date_query'][] = array(
                        'after'  => '1 year ago',
                    );
                }
            }
            if($args['post_type']=='product'){
                $args['tax_query'][] = array(
                    'relation' => 'AND',
                    array(
                        'taxonomy' => 'product_visibility',
                        'field'    => 'name',
                        'terms'    => 'exclude-from-catalog',
                        'operator' => 'NOT IN',
                    )
                );          
            }
        }else{ // if infinite scroll

        }   

        $wp_query = new \WP_Query($args);
        $i=1+$offset;
        $count = 1;

        if ( $wp_query->have_posts() ) {
            while ($wp_query->have_posts() ) {
                $wp_query->the_post();
                ob_start();
                if(!empty($innerargs)) {extract($innerargs);}
                include(GUTENCON_PLUGIN_DIR.'parts/'.$template.'.php');
                $count++;$i++;
                $response .= ob_get_clean();
            }
            wp_reset_query();
            // if ($count >= $perpage){
            //     $response .='<div class="gc_ajax_pagination"><span data-offset="'.$offsetnext.'" data-containerid="'.$containerid.'"'.$page_sorting.' class="gc_ajax_pagination_btn def_btn">' . esc_html__('Show next', 'gutencon') . '</span></div>';
            // } 
        }           
        else {
            $response .= '<div class="clearfix flexbasisclear gcnomoreclass"><span class="no_more_posts">'.__('No more!', 'gutencon').'<span></div>';
        }       

        wp_send_json_success($response);
        exit;
    }

    //////////////////////////////////////////////////////////////////
    // Sanitize Arrays
    //////////////////////////////////////////////////////////////////
    public function gc_sanitize_multi_arrays($data = array()) {
        if (!is_array($data) || empty($data)) {
        return array();
        }
        foreach ($data as $k => $v) {
        if (!is_array($v) && !is_object($v)) {
            if($k == 'contshortcode'){
                $data[sanitize_key($k)] = wp_kses_post($v);
            }elseif($k=='attrelpanel'){
                $data[sanitize_key($k)] = filter_var( $v, FILTER_SANITIZE_SPECIAL_CHARS );
            }else{
                $data[sanitize_key($k)] = sanitize_text_field($v);
            }
        }
        if (is_array($v)) {
            $data[$k] = $this->gc_sanitize_multi_arrays($v);
        }
        }
        return $data;
    }

}

Init::instance();