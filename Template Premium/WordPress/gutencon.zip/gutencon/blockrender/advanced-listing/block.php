<?php


namespace Gutencon\Blocks;
defined('ABSPATH') OR exit;


class ListingQuery{

	protected $name = 'ListingQuery';

	final public static function instance(){
		static $instance = null;

		if(is_null($instance)) {
			$instance = new static();
		}

		return $instance;
	}

	static $fonts = array();

	protected function __construct(){
		add_action('init', array( $this, 'init_handler' ));
		$this->action();
	}

	public function init_handler(){
		register_block_type(__DIR__, array(
			'render_callback' => array( $this, 'render_block' ),
			'attributes'      => $this->attributes
		)
		);
	}

	protected $attributes = array(
		'cat' => array(
			'type' => 'array',
			'default' => null
		),
		'tag' => array(
			'type' => 'array',
			'default' => null
		),
		'cat_exclude' => array(
			'type' => 'array',
			'default' => null
		),
		'tag_exclude' => array(
			'type' => 'array',
			'default' => null
		),
		'tax_name' => array(
			'type' => 'string',
			'default' => '',
		),
		'tax_slug' => array(
			'type' => 'array',
			'default' => null
		),
		'tax_slug_exclude' => array(
			'type' => 'array',
			'default' => null
		),
		'user_id' => array(
			'type' => 'array',
			'default' => null
		),
		'type' => array(
			'type' => 'string',
			'default' => 'all',
		),
		'ids' => array(
			'type' => 'array',
			'default' => null
		),
		'order' => array(
			'type' => 'string',
			'default' => 'desc',
		),
		'orderby' => array(
			'type' => 'string',
			'default' => 'date',
		),
		'meta_key' => array(
			'type' => 'string',
			'default' => '',
		),
		'show' => array(
			'type' => 'number',
			'default' => 12,
		),
		'offset' => array(
			'type' => 'string',
			'default' => '',
		),
		'enable_pagination' => array(
			'type' => 'string',
			'default' => '0',
		),
		'listargs'=> array(
			'type'=>'object',
			'default'=> array(
				'image'=> '1',
				'button'=> '1',
				'review'=> false,
				'reviewkey'=>'_wc_average_rating',
				'reviewcirclecolor'=> '#cc0000',
				'contentpos'=>'titleexc',
				'metastretchdisable'=>'',
				'readmore'=> '',
				'headingtag'=> 'h2',
				'section'=>array(),
				'background'=>'',
				'togglecontent'=>'content',
				'btncolor'=>'',
				'btnbg'=>'',
				'pricecolor'=>'',
				'togglelink'=>'no',
				'height'=>'',
				'imageWidth'=>'',
				'imageHeight'=>'160',
				'margins'=>array(
					'top'=> null,
					'right'=> null,
					'bottom'=> null,
					'left'=> null
				),
				'borderradius'=>''
			)
		),
	);

	protected function action(){
		add_action( 'wp_ajax_gcal_taxonomies_list', array( $this, 'gcal_taxonomies_list' ) );
		add_action( 'wp_ajax_gcal_taxonomy_terms', array( $this, 'gcal_taxonomy_terms' ) );
		add_action( 'wp_ajax_gcal_taxonomy_terms_search', array( $this, 'gcal_taxonomy_terms_search' ) );
		add_action( 'wp_ajax_gcal_render_preview', array( $this, 'render_preview' ) );
		add_action( 'wp_ajax_gcal_products_title_list', array( $this, 'gcal_products_title_list' ) );
		add_action( 'wp_ajax_gcal_post_type_el', array( $this, 'gcal_post_type_el' ) );
	}
	public function gcal_products_title_list() {
        global $wpdb;

        //$post_types = get_post_types( array('public'   => true) );
        //$placeholdersformat = array_fill(0, count( $post_types ), '%s');
        //$postformat = implode(", ", $placeholdersformat);

        $query = [
            "select" => "SELECT SQL_CALC_FOUND_ROWS ID, post_title FROM {$wpdb->posts}",
            "where"  => "WHERE post_type IN ('post', 'product', 'blog', 'page')",
            "like"   => "AND post_title NOT LIKE %s",
            "offset" => "LIMIT %d, %d"
        ];

        $search_term = '';
        if ( ! empty( $_POST['search'] ) ) {
            $search_term = $wpdb->esc_like( $_POST['search'] ) . '%';
            $query['like'] = 'AND post_title LIKE %s';
        }

        $offset = 0;
        $search_limit = 100;
        if ( isset( $_POST['page'] ) && intval( $_POST['page'] ) && $_POST['page'] > 1 ) {
            $offset = $search_limit * absint( $_POST['page'] );
        }

        $final_query = $wpdb->prepare( implode(' ', $query ), $search_term, $offset, $search_limit );
        // Return saved values

        if ( ! empty( $_POST['saved'] ) && is_array( $_POST['saved'] ) ) {
            $saved_ids = $_POST['saved'];
            $placeholders = array_fill(0, count( $saved_ids ), '%d');
            $format = implode(', ', $placeholders);

            $new_query = [
                "select" => $query['select'],
                "where"  => $query['where'],
                "id"     => "AND ID IN( $format )",
                "order"  => "ORDER BY field(ID, " . implode(",", $saved_ids) . ")"
            ];

            $final_query = $wpdb->prepare( implode(" ", $new_query), $saved_ids );
        }

        $results = $wpdb->get_results( $final_query );
        $total_results = $wpdb->get_row("SELECT FOUND_ROWS() as total_rows;");
        $response_data = [
            'results'       => [],
            'total_count'   => $total_results->total_rows
        ];

        if ( $results ) {
            foreach ( $results as $result ) {
                $response_data['results'][] = [
                    'value'    => $result->ID,
					'id'    => $result->ID,
                    'label'  => esc_html( $result->post_title )
                ];
            }
        }

        wp_send_json_success( $response_data );
    }
	public function gcal_post_type_el() {
        $post_types = get_post_types( array('public' => true) );
        $post_types_list = array();
        foreach ( $post_types as $post_type ) {
            if ( $post_type !== 'revision' && $post_type !== 'nav_menu_item' && $post_type !== 'attachment') {
                $post_types_list[] = array(
					'label' => $post_type,
					'value' => $post_type
				);
            }
        }
        wp_send_json_success($post_types_list);
    }
	public function gcal_taxonomies_list() {
		$exclude_list = array_flip([
			'nav_menu', 'link_category', 'post_format',
			'elementor_library_type', 'elementor_library_category', 'action-group'
		]);
		$response_data = [
			'results' => []
		];
    	$args = [];
		foreach ( get_taxonomies($args, 'objects') as $taxonomy => $object ) {
			if ( isset( $exclude_list[ $taxonomy ] ) ) {
				continue;
			}

			$taxonomy = esc_html( $taxonomy );
			$response_data['results'][] = [
				'value'    => $taxonomy,
				'label'  => esc_html( $object->label ),
			];
		}
		wp_send_json_success( $response_data );
	}
	public function gcal_taxonomy_terms() {
		$response_data = [
			'results' => []
		];
	
		if ( empty( $_POST['taxonomy'] ) ) {
			wp_send_json_success( $response_data );
		}
	
		$taxonomy = sanitize_text_field($_POST['taxonomy']);
		$selected = isset($_POST['selected']) ? $_POST['selected'] : '';
		$terms = get_terms([
			'taxonomy'   => $taxonomy,
			'hide_empty' => false,
			'number' => 15,
			'exclude' => $selected
		]);
	
		foreach ( $terms as $term ) {
			$response_data['results'][] = [
				'id'    	=> $term->slug,
				'label'  	=> esc_html( $term->name ),
				'value' 	=> $term->term_id
			];
		}
	
		wp_send_json_success( $response_data );
	}
	public function gcal_taxonomy_terms_search(){
		global $wpdb;
        $taxonomy = isset($_POST['taxonomy']) ? $_POST['taxonomy'] : '';
        $query = [
            "select" => "SELECT SQL_CALC_FOUND_ROWS a.term_id AS id, b.name as name, b.slug AS slug
                        FROM {$wpdb->term_taxonomy} AS a
                        INNER JOIN {$wpdb->terms} AS b ON b.term_id = a.term_id",
            "where"  => "WHERE a.taxonomy = '{$taxonomy}'",
            "like"   => "AND (b.slug LIKE '%s' OR b.name LIKE '%s' )",
            "offset" => "LIMIT %d, %d"
        ];

        $search_term = '%' . $wpdb->esc_like( $_POST['search'] ) . '%';
        $offset = 0;
        $search_limit = 100;

        $final_query = $wpdb->prepare( implode(' ', $query ), $search_term, $search_term, $offset, $search_limit );
        // Return saved values

        $results = $wpdb->get_results( $final_query );

        $total_results = $wpdb->get_row("SELECT FOUND_ROWS() as total_rows;");
        $response_data = [
            'results'       => [],
        ];

        if ( $results ) {
            foreach ( $results as $result ) {
                $response_data['results'][] = [
					'id'    	=> esc_html( $result->slug ),
					'label'  	=> esc_html( $result->name ),
					'value' 	=> (int)$result->id
                ];
            }
        }

        wp_send_json_success( $response_data );
	}

	public function render_preview(){
		$settings = $_POST['settings'];
		if(!empty($settings['listargs'])){
			
			if(!empty( $settings['listargs']['section'])){
				foreach($settings['listargs']['section'] as $index=>$section){
					if(!empty($section['imageMapper'])){
						$imagearray = array();
						foreach($section['imageMapper'] as $image){
							$imageindex = $image['image']['id'];
							$valueindex = $image['value'];
							$imagearray[$imageindex] = $valueindex;
						}
						$settings['listargs']['section'][$index]['imageMapper'] = $imagearray;
					}
				}
			}
			
			$settings['listargs'] = json_encode( $settings['listargs']);
		}
		$this->normalize_arrays( $settings );

		if ( !empty( $settings['filterpanel'] ) ) {
            $settings['filterpanel'] = $this->filter_values( $settings['filterpanel'] );
            $settings['filterpanel'] = rawurlencode( json_encode( $settings['filterpanel'] ) );
        }
		$preview = $this->gc_list_constructor( $settings );
		wp_send_json_success( $preview );
	}

	protected function normalize_arrays( &$settings, $fields = ['cat', 'tag', 'ids', 'taxdropids', 'field', 'cat_exclude', 'tag_exclude', 'postid', 'tax_slug', 'tax_slug_exclude', 'user_id'] ) {
        foreach( $fields as $field ) {
            if ( ! isset( $settings[ $field ] ) || ! is_array( $settings[ $field ] ) || empty( $settings[ $field ] ) ) {
				$settings[ $field ] = null;
                continue;
            }
			$ids = '';
			$last = count( $settings[ $field ] );
			foreach ($settings[ $field ] as $item ){
				$ids .= $item['id'];
				if (0 !== --$last) {
					$ids .= ',';
				}
			}
            $settings[ $field ] = $ids;
        }
    }

	protected function filter_values( $haystack ) {
        foreach ( $haystack as $key => $value ) {
            if ( is_array( $value ) ) {
                $haystack[ $key ] = $this->filter_values( $haystack[ $key ]);
            }
            if ( empty( $haystack[ $key ] ) ) {
                unset( $haystack[ $key ] );
            }
        }
        return $haystack;
    }

	public function gc_custom_taxonomy_dropdown( $taxdrop, $limit = '40', $class = '', $taxdroplabel = '', $containerid ='', $taxdropids = '' ) {
		$args = array(
			'taxonomy'=> $taxdrop,
			'number' => $limit,
			'hide_empty' => true,
			'parent'        => 0,
		);
		if($taxdropids){
			$taxdropids = array_map( 'trim', explode(",", $taxdropids ));
			$args['include'] = $taxdropids;
			$args['parent'] = '';
			$args['orderby'] = 'include';
		}
		$terms = get_terms($args );
		$class = ( $class ) ? $class : 'gc_tax_dropdown';
		$output = '';
		if ( $terms && !is_wp_error($terms) ) {
			$output .= '<ul class="'.$class.'">';
			if (empty($taxdroplabel)){$taxdroplabel = esc_html__('Choose category', 'gutencon');}
			$output .= '<li class="label"><span class="gc_tax_placeholder">'.$taxdroplabel.'</span><span class="gc_choosed_tax"></span></li>';
			$output .= '<li class="gc_drop_item"><span data-sorttype="" class="gc_filtersort_btn" data-containerid="'.$containerid.'">'.esc_html__('All categories', 'gutencon').'</span></li>';
			foreach ( $terms as $term ) {
				$term_link = get_term_link( $term );
				if ( is_wp_error( $term_link ) ) {
					continue;
				}    
				if(!empty($containerid)){
					$sort_array=array();
					$sort_array['filtertype'] = 'tax';
					$sort_array['filtertaxkey'] = $taxdrop;
					$sort_array['filtertaxtermslug'] = $term->slug;
					$json_filteritem = json_encode($sort_array);
					$output .='<li class="gc_drop_item"><span data-sorttype=\''.$json_filteritem.'\' class="gc_filtersort_btn" data-containerid="'.$containerid.'">';
						$output .= $term->name;
					$output .= '</span></li>';
				}    
				else{
					$output .= '<li class="gc_drop_item"><span><a href="' . esc_url( $term_link ) . '">' . $term->name . '</a></span></li>';                
				}            
			}
			$output .= '</ul>';
		}
		return $output;
	}

	public function gc_vc_filterpanel_render( $filterpanel='', $containerid='', $taxdrop='', $taxdroplabel='', $taxdropids = '', $filterheading='' ) {
		if(!$filterpanel){
			return;
		}
		$filterpanel = (array) json_decode( urldecode( $filterpanel ), true );
		$output = '';
		if (!empty($filterpanel[0])){
			wp_enqueue_style('rhfilterpanel'); wp_enqueue_script('rhfilterpanel');
			$tax_enabled_div = (!empty($taxdrop)) ? ' tax_enabled_drop' : '';
			$heading_enabled_div = (!empty($filterheading)) ? ' heading_enabled' : '';
			$output .= '<div class="gc_filter_panel'.$tax_enabled_div.$heading_enabled_div.'">';
				if($filterheading){
					$output .= '<div class="gc_filter_heading">'.wp_kses_post($filterheading).'</div>';
				}
				$output .= '<ul class="gc_filter_ul">';
				foreach ( $filterpanel as $k => $v ) {
					$output .= '<li class="inlinestyle">';
						$label = '';
						if (!empty($v['filtertitle'])) {
							$label = $v['filtertitle'];
							unset ($v['filtertitle']);		
						}
						$json_filteritem = json_encode($v);	
						$class = ($k==0) ? ' class="active gc_filtersort_btn resort_'.$k.'"' : ' class="gc_filtersort_btn resort_'.$k.'"';								
						$output .= '<span data-sorttype=\''.$json_filteritem.'\''.$class.' data-containerid="'.$containerid.'">';
							$output .= $label;						
						$output .= '</span>';					
					$output .= '</li>';				
				}
				$output .= '</ul>';
	
				if($taxdrop){
					$output .= '<div class="rh-flex-right-align">';
					$output .= $this->gc_custom_taxonomy_dropdown($taxdrop, '40', 'gc_tax_dropdown', $taxdroplabel, $containerid,$taxdropids);
					$output .='</div>';
				}
	
			$output .= '</div>';
		}
		echo ''.$output;
	
	}

	public function gc_list_constructor( $settings, $content = null ) {
		$defaults = array(
			'data_source' => 'cat',
			'cat' => '',
			'cat_name' => '',
			'tag' => '',
			'cat_exclude' => '',
			'tag_exclude' => '',	
			'ids' => '',	
			'orderby' => '',
			'order' => 'DESC',	
			'meta_key' => '',
			'show' => 10,
			'user_id' => '',
			'type' => '',
			'offset' => '',
			'show_date' => '',	
			'post_type' => '',
			'tax_name' => '',
			'tax_slug' => '',
			'tax_slug_exclude' => '',
			'enable_pagination' => '',
			'price_range' => '',		
			'filterpanel' => '',
			'filterheading' => '',
			'taxdrop' => '',
			'taxdroplabel' => '',
			'taxdropids' => '',
			'listargs' => '',
		
		); 
		$build_args = wp_parse_args($settings, $defaults);  
		extract($build_args);   
		if ($enable_pagination =='2'){
			$infinitescrollwrap = ' gc_aj_pag_auto_wrap';
		}     
		elseif ($enable_pagination =='3') {
			$infinitescrollwrap = ' gc_aj_pag_clk_wrap';
		} 
		else {
			$infinitescrollwrap = '';
		}   
		$containerid = 'gc_filterid_' . mt_rand(); 
		$ajaxoffset = (int)$show + (int)$offset;
		ob_start(); 
		?>
		<?php $this->gc_vc_filterpanel_render($filterpanel, $containerid, $taxdrop, $taxdroplabel, $taxdropids, $filterheading);?>
		<?php
			global $wp_query; 
			$argsfilter = new \GC_Postfilters($build_args);
			$args = $argsfilter->extract_filters();
		
			$args = apply_filters('gc_module_args_query', $args);
			$wp_query = new \WP_Query($args);
			do_action('gc_after_module_args_query', $wp_query);
		
		?>
		<?php if ( $wp_query->have_posts() ) : ?>
			<?php 
				if(!empty($args['paged'])){unset($args['paged']);}
				$jsonargs = json_encode($args);
				$json_innerargs = $listargs;
			?>
			<div class="gc_list_builder review_visible_circle <?php echo ''.$infinitescrollwrap;?>" data-filterargs='<?php echo ''.$jsonargs.'';?>' data-template="listbuilder" id="<?php echo esc_attr($containerid);?>" data-innerargs='<?php echo ''.$json_innerargs.'';?>' data-perpage='<?php echo ''.$show.'';?>'>
				
				<?php $i=0; while ( $wp_query->have_posts() ) : $wp_query->the_post(); $i++;  ?>
				
					<?php include(GUTENCON_PLUGIN_DIR.'parts/listbuilder.php'); ?>
				<?php endwhile; ?>
				<?php if ($enable_pagination == '1') :?>
					<div class="clearfix"></div>
					<div class="pagination"><?php the_posts_pagination();?></div>
				<?php elseif ($enable_pagination == '2' || $enable_pagination == '3' ) :?>
					<?php  wp_enqueue_script('gcajaxpagination');?> 
					<div class="gc_ajax_pagination"><span data-offset="<?php echo esc_attr($ajaxoffset);?>" data-containerid="<?php echo esc_attr($containerid);?>" class="gc_ajax_pagination_btn def_btn"><?php esc_html_e('Show next', 'gutencon') ?></span></div>      
				<?php endif ;?>
		
			</div>
			<div class="clearfix"></div>
		<?php endif; wp_reset_query(); ?>
		
		<?php 
		$output = ob_get_contents();
		ob_end_clean();
		return $output;
	}

	public function render_block($settings = array(), $inner_content=''){
		extract($settings);
		if(!empty($settings['listargs'])){
			
			if(!empty( $settings['listargs']['section'])){
				foreach($settings['listargs']['section'] as $index=>$section){
					if(!empty($section['imageMapper'])){
						$imagearray = array();
						foreach($section['imageMapper'] as $image){
							$imageindex = $image['image']['id'];
							$valueindex = $image['value'];
							$imagearray[$imageindex] = $valueindex;
						}
						$settings['listargs']['section'][$index]['imageMapper'] = $imagearray;
					}
				}
			}
			
			if(!empty($settings['listargs']['section'][0]['t'])){
				foreach($settings['listargs']['section'] as $index=>$section){
					unset($settings['listargs']['section'][$index]['t']);
				}
			}
			$settings['listargs'] = json_encode( $settings['listargs']);
		}
		$this->normalize_arrays( $settings );
		
		if ( !empty( $settings['filterpanel'] ) ) {
            $settings['filterpanel'] = $this->filter_values( $settings['filterpanel'] );
            $settings['filterpanel'] = rawurlencode( json_encode( $settings['filterpanel'] ) );
        }
		$output = str_replace( "{{ content }}", $this->gc_list_constructor( $settings ), $inner_content );
		return $output;
	}
}

ListingQuery::instance();