<?php
namespace AIOSEO\Plugin\Addon\LinkAssistant\Suggestions;

use AIOSEO\Plugin\Addon\LinkAssistant\Models;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers and executes the Link Suggestions scan.
 *
 * @since 1.0.0
 */
class Suggestions {
	/**
	 * The base URL for the Link Suggestions microservice.
	 *
	 * @since 1.0.0
	 *
	 * @var string
	 */
	private $baseUrl = 'https://link-suggestions.aioseo.com/v2/';

	/**
	 * The action name of the action that starts a suggestion scan.
	 *
	 * @since 1.0.3
	 *
	 * @var string
	 */
	private $registerScanActionName = 'aioseo_link_assistant_register_suggestions_scan';

	/**
	 * The action name of the main suggestions scan.
	 *
	 * @since 1.0.3
	 *
	 * @var string
	 */
	private $scanActionName = 'aioseo_link_assistant_suggestions_scan';

	/**
	 * Class constructor.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		$this->data = new Data;

		add_action( $this->registerScanActionName, [ $this, 'registerScan' ], 10, 1 );
		add_action( $this->scanActionName, [ $this, 'scanPosts' ], 10, 1 );

		if ( ! is_admin() ) {
			return;
		}

		add_action( 'init', [ $this, 'scheduleRegisterScan' ] );
		add_action( 'init', [ $this, 'scheduleMainScan' ] );
	}

	/**
	 * Schedules a new suggestions scan if there is no ongoing one.
	 *
	 * @since 1.0.3
	 *
	 * @return void
	 */
	public function scheduleRegisterScan() {
		$scanId = aioseoLinkAssistant()->internalOptions->internal->scanId;
		if (
			! empty( $scanId ) ||
			aioseo()->helpers->isScheduledAction( $this->registerScanActionName ) ||
			aioseo()->cache->get( 'link_assistant_no_scan' )
		) {
			return;
		}

		aioseo()->helpers->scheduleAsyncAction( $this->registerScanActionName );
	}

	/**
	 * Schedules a suggestions scan if there is no ongoing one.
	 *
	 * @since 1.0.3
	 *
	 * @return void
	 */
	public function scheduleMainScan() {
		$scanId = aioseoLinkAssistant()->internalOptions->internal->scanId;
		if (
			empty( $scanId ) ||
			aioseo()->helpers->isScheduledAction( $this->scanActionName )
		) {
			return;
		}

		aioseo()->helpers->scheduleSingleAction( $this->scanActionName, 10 );
	}

	/**
	 * Kicks off the initial scan for the link suggestions.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function registerScan() {
		$transientName = 'aioseo_link_assistant_registering_suggestions_scan';
		$scanId        = aioseoLinkAssistant()->internalOptions->internal->scanId;
		if ( ! empty( $scanId ) || aioseo()->cache->get( $transientName ) ) {
			return;
		}

		$arePostsToScan = $this->data->arePostsToScan();
		if ( ! $arePostsToScan ) {
			aioseo()->cache->update( 'link_assistant_no_scan', true, 15 * MINUTE_IN_SECONDS );

			return;
		}

		$posts = $this->data->getAllPosts();
		if ( empty( $posts ) ) {
			return;
		}

		$requestBody = array_merge(
			$this->data->getBaseData(),
			[
				'posts'  => $posts,
				'totals' => [
					'posts' => aioseoLinkAssistant()->helpers->getTotalScannablePosts()
				]
			]
		);

		// Set a transient while the scan is being registered to prevent the data from being uploaded multiple times.
		aioseo()->cache->update( $transientName, true, 5 * MINUTE_IN_SECONDS );

		$response = $this->doPostRequest( 'suggestions/scan/start', $requestBody );

		aioseo()->cache->delete( $transientName );

		if (
			! $response ||
			is_wp_error( $response ) ||
			empty( $response->scanId )
		) {
			return;
		}

		aioseoLinkAssistant()->internalOptions->internal->scanId = $response->scanId;
	}

	/**
	 * Scans posts for link suggestions.
	 *
	 * @since 1.0.3
	 *
	 * @return void
	 */
	public function scanPosts() {
		$scanId = aioseoLinkAssistant()->internalOptions->internal->scanId;
		if ( empty( $scanId ) ) {
			return;
		}

		$postsToScan = $this->data->getPostsToScan( true );
		if ( empty( $postsToScan ) ) {
			$this->endScan();

			return;
		};

		Models\Suggestion::deleteNonDismissedSuggestions( $postsToScan );

		$requestBody = [ 'postsToScan' => $postsToScan ];
		$response    = $this->doPostRequest( "suggestions/scan/{$scanId}", $requestBody );
		if ( ! $response ) {
			return;
		}

		// If the JSON file with the scan data cannot be found on the server, wipe the scan ID so the scan restarts.
		if ( is_wp_error( $response ) && 'missing-scan-data' === strtolower( $response->get_error_code() ) ) {
			aioseoLinkAssistant()->internalOptions->internal->scanId = '';

			return;
		}

		if ( empty( $response->scannedPostsWithSuggestions ) ) {
			return;
		}

		$scannedPostIds = array_keys( (array) $response->scannedPostsWithSuggestions );
		$this->markPostsAsScanned( $scannedPostIds );

		$this->data->parseSuggestions( $response->scannedPostsWithSuggestions );

		aioseo()->helpers->scheduleSingleAction( $this->scanActionName, 60, [], true );
	}

	/**
	 * Ends the scan and deletes the scan ID.
	 *
	 * @since 1.0.3
	 *
	 * @return void
	 */
	private function endScan() {
		$scanId = aioseoLinkAssistant()->internalOptions->internal->scanId;
		if ( empty( $scanId ) ) {
			return;
		}

		wp_remote_request( $this->getUrl() . "suggestions/scan/$scanId/", [
			'headers' => [
				'X-AIOSEO-License' => aioseo()->options->general->licenseKey,
				'Content-Type'     => 'application/json'
			],
			'method'  => 'DELETE',
			'timeout' => 60
		] );

		// Reset the scan ID.
		aioseoLinkAssistant()->internalOptions->internal->scanId = null;
	}

	/**
	 * Refreshes the link suggestions for the given post.
	 *
	 * @since 1.0.3
	 *
	 * @param  WP_Post $postToScan The post that needs to be scanned.
	 * @return void
	 */
	public function refresh( $postToScan ) {
		$posts = $this->data->getAllPosts();
		if ( empty( $posts ) ) {
			return;
		}

		Models\Suggestion::deleteNonDismissedSuggestions( $postToScan );

		$postToScan->phrases = $this->data->getPhrases( $postToScan );
		unset( $postToScan->post_content );

		$requestBody = array_merge(
			$this->data->getBaseData(),
			[
				'postToScan' => $postToScan,
				'posts'      => $posts
			]
		);

		$response = $this->doPostRequest( 'suggestions/refresh/', $requestBody );
		if (
			! $response ||
			is_wp_error( $response ) ||
			empty( $response->scannedPostsWithSuggestions )
		) {
			return;
		}

		$this->markPostsAsScanned( $postToScan->ID );

		$this->data->parseSuggestions( $response->scannedPostsWithSuggestions );
	}

	/**
	 * Marks the given posts as scanned.
	 *
	 * @since 1.0.3
	 *
	 * @param  array|int $scannedPosts The posts that were scanned.
	 * @return void
	 */
	private function markPostsAsScanned( $scannedPostIds ) {
		if ( ! is_array( $scannedPostIds ) ) {
			$scannedPostIds = [ $scannedPostIds ];
		}

		$tableName          = aioseo()->core->db->prefix . 'aioseo_posts';
		$postIdPlaceholders = aioseo()->helpers->implodePlaceholders( $scannedPostIds, '%d' );

		aioseo()->core->db->execute(
			aioseo()->core->db->db->prepare(
				"UPDATE $tableName
				SET `link_suggestions_scan_date`=%s
				WHERE `post_id` IN ( $postIdPlaceholders )",
				array_merge(
					[ gmdate( 'Y-m-d H:i:s' ) ],
					$scannedPostIds
				)
			)
		);
	}

	/**
	 * Sends a POST request to the microservice.
	 *
	 * @since 1.0.3
	 *
	 * @param  string               $path        The path.
	 * @param  array                $requestBody The request body.
	 * @return array|WP_Error|false              Returns the response body or false if the request failed.
	 */
	private function doPostRequest( $path, $requestBody = [] ) {
		$requestData = [
			'headers' => [
				'X-AIOSEO-License' => aioseo()->options->general->licenseKey,
				'Content-Type'     => 'application/json'
			],
			'timeout' => 60
		];

		if ( ! empty( $requestBody ) ) {
			$requestData['body'] = wp_json_encode( $requestBody );
		}

		$baseUrl      = $this->getUrl();
		$response     = wp_remote_post( $baseUrl . $path, $requestData );
		$responseBody = json_decode( wp_remote_retrieve_body( $response ) );

		if ( 200 !== wp_remote_retrieve_response_code( $response ) || empty( $responseBody->success ) ) {
			if ( ! empty( $responseBody->error ) ) {
				$message = ! empty( $responseBody->message ) ? $responseBody->message : '';

				return new \WP_Error( $responseBody->error, $message );
			}

			return false;
		}

		return $responseBody;
	}

	/**
	 * Returns the URL for the Link Suggestions microservice.
	 *
	 * @since 1.0.0
	 *
	 * @return string The URL.
	 */
	public function getUrl() {
		if ( defined( 'AIOSEO_LINK_SUGGESTIONS_URL' ) ) {
			return AIOSEO_LINK_SUGGESTIONS_URL;
		}

		return $this->baseUrl;
	}
}