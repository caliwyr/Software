<?php
namespace AIOSEO\Plugin\Addon\LinkAssistant\Api;

use AIOSEO\Plugin\Addon\LinkAssistant\Models;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Handles all endpoints for the inner Links Report.
 *
 * @since 1.0.0
 */
class LinksReportInner extends Common {
	/**
	 * The links limit.
	 *
	 * @since 1.0.0
	 *
	 * @var int
	 */
	protected static $linksLimit = 5;
}