<aside class="otw_portfolio_manager-sidebar otw-pm-list-section" id="otw-pm-list-<?php echo $this->listOptions['id'];?>">
	<ul class="pm_clearfix">
		<li class="widget otw_portfolio_manager-widget-carousel pm_clearfix">
			<?php echo $this->loadWidgetComp( 'list_title' ); ?>
			<div class="otw_portfolio_manager-slider otw_portfolio_manager-carousel" data-type="widget" data-animation="slide" data-item-per-page="3" data-item-margin="10" data-nav="<?php echo esc_attr( $this->listOptions['slider_nav'] );?>" data-auto-slide="<?php echo esc_attr( $this->listOptions['slider-auto-scroll'] );?>">
				<ul class="slides">
					<?php foreach( $otw_pm_posts->posts as $widgetPost ){?>
						<?php 
							$widgetAsset = $this->getPostAsset( $widgetPost );
							$imgAsset = parse_url( $widgetAsset );
							$widgetPostLink = $this->getLink($widgetPost, 'media');
							$this->getMediaProportions();
						?>
						<li class="slider_item">
							<?php $postMetaData = get_post_meta( $widgetPost->ID, 'otw_pm_meta_data', true );?>
							<?php echo $this->getMedia( $widgetPost, $postMetaData, 'simple_media' );?>
						</li>
					<?php }?>
				</ul>
			</div>
		</li>
	</ul>
</aside>