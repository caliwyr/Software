<?php get_header()?>
	<!-- Wrapper with sidebar -->
	<div class="otw-row"<?php echo $otw_pm_posts['custom_style']?>>
		<section class="otw-twentyfour otw-columns">
			<?php if( post_password_required() ){?>
				<?php echo get_the_password_form();?>
			<?php }else{ ?>
			<?php
				$this->grid_manager_component_object->portfolio_item_id = $otw_pm_posts['post']->ID;
				$template_content = $this->grid_manager_component_object->decode_grid_content( 'otwct_'.$otw_pm_posts['post']->ID, otw_stripslashes( $otw_pm_posts['otw_custom_template']['grid_content'] ) );
				echo $this->grid_manager_component_object->otw_shortcode_remove_wpautop( $template_content );
			?>
			<?php }?>
		</section>
	</div>
	<!-- End Wrapper with sidebar -->
<?php get_footer()?>