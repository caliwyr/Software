<?php ( $this->listOptions['horizontal-space-tiles'] )? $spacer = '' : $spacer = 'without-space' ?>
<?php ( $this->listOptions['horizontal-space-tiles'] )? $margin = 4 : $margin = 0 ?>
<?php $imageHover = $this->listOptions['image_hover'];?>
<section class="otw-pm-list-section otw-twentyfour otw-columns" id="otw-pm-list-<?php echo $this->listOptions['id'];?>">
	<?php echo $this->getViewAll(); ?>
	<div class="otw_portfolio_manager-horizontal-layout-wrapper pm_clearfix">
		<div class="otw_portfolio_manager-portfolio-items-holder otw_portfolio_manager-horizontal-layout-items <?php echo $spacer;?> <?php echo $this->getInfiniteScrollHorizontal();?>" data-item-margin="<?php echo esc_attr( $margin ); ?>">
			<?php
				$this->getMediaProportions();
				$imageHeight = $this->imageHeight;
				
				$itemIndex = 0;
				$row = 0;
				$randomWidth = array(244, 345, 246, 478, 264, 600, 172, 130, 391, 738 );
				
				for( $cC = 0; $cC < count( $randomWidth ); $cC++ ){
					if( isset( $this->listOptions['horizontal-cell-width-'.$cC] ) && intval( $this->listOptions['horizontal-cell-width-'.$cC] ) ){
						$randomWidth[ $cC ] = $this->listOptions['horizontal-cell-width-'.$cC];
					}
				}
				
				foreach( $otw_pm_posts->posts as $post ):
					$postAsset = $this->getPostAsset( $post );
					$imgAsset = parse_url( $postAsset );
					
					$postLink = $this->getLink($post, 'media');
					
					if( $itemIndex > 9 ) { $itemIndex = 0; }
					if( $itemIndex % 5 == 0 ) { $row++; }
					
					$this->getMediaProportions();
					
			?>
			<div class="otw_portfolio_manager-horizontal-item otw_portfolio_manager-portfolio-item-holder" data-original-width="<?php echo $randomWidth[ $itemIndex ];?>" data-original-height="<?php echo esc_attr( $imageHeight );?>" data-row="<?php echo esc_attr( $row );?>">
				<div class="otw_portfolio_manager-portfolio-full icon__small <?php echo $imageHover?>">
						<?php $postMetaData = get_post_meta( $post->ID, 'otw_pm_meta_data', true );?>
						<?php $postMetaData['_otw_force_imageWidth'] = $randomWidth[ $itemIndex ];?>
						<?php $postMetaData['_otw_slider_image'] = 1;?>
						<?php echo $this->getMedia( $post, $postMetaData, 'media' );?>
				</div>
			</div>
			<?php
				$itemIndex++;
				endforeach;
			?>
		</div>
	</div>
	<?php echo $this->getPagination( $otw_pm_posts ); ?>
</section>