<?php
  ( $this->listOptions['meta_type_align'] == 'vertical' )? $portfolioInfoClass = 'few-lines' : $portfolioInfoClass = '';
?>
<div class="otw_portfolio_manager-portfolio-meta-wrapper <?php echo $portfolioInfoClass;?>">
	<?php echo $metaData; ?>
</div>