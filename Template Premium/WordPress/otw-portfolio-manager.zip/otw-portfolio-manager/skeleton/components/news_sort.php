<!-- Portfolio Newspaper Sort -->
<div class="otw_portfolio_manager-portfolio-newspaper-sort">
	<ul class="option-set otw_portfolio_manager-portfolio-sort pm_clearfix" data-option-key="sortBy">
		<li><a href="#" data-option-value="original-order" class="selected"><?php esc_html_e('Original', 'otw-portfolio-manager' )?></a></li>
		<li><a href="#" data-option-value="random"><?php esc_html_e('Mixed', 'otw-portfolio-manager' )?></a></li>
		<li><a href="#" data-option-value="date"><?php esc_html_e('Date', 'otw-portfolio-manager' )?></a></li>
		<li><a href="#" data-option-value="alphabetical"><?php esc_html_e('Alphabetical', 'otw-portfolio-manager' )?></a></li>
	</ul>
</div>