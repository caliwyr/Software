<?php if( !empty( $postMetaData[1] ) ){?>
<div class="otw_portfolio_manager-portfolio-meta-item">
	<?php if( !$this->listOptions['meta_icons'] ) : ?>
		<span class="head"><?php echo esc_html( $postMetaData[0] );?>:</span>
	<?php else: ?>
		<span class="head"><i class="icon-folder-open"></i></span>
	<?php endif; ?>
	<?php echo $postMetaData[1];?>
</div>
<?php } ?>