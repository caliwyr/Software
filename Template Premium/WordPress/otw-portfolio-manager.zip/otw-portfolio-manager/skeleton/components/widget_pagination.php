<!-- Widget Load More Pagination -->
<?php 
  $uniqueHash = wp_create_nonce("otw_pm_get_posts_nonce"); 
  $listID = $this->listOptions['id'];
  ( !isset($paginationPage) )? $page = 2 : $page = $paginationPage;

  $ajaxURL = admin_url( 'admin-ajax.php?action=get_pm_posts&page='. $page.'&post_id='. $listID .'&nonce='. $uniqueHash );
?>
<div class="js-widget-pagination_container">
  <div class="otw_portfolio_manager-pagination hide">
    <a href="<?php echo esc_attr( $ajaxURL );?>" class="js-pagination-no"><?php echo esc_html( $page );?></a>
  </div>
  <div class="otw_portfolio_manager-load-more js-widget-otw_portfolio_manager-load-more">
    <a href="<?php echo esc_attr( $ajaxURL );?>" data-empty="<?php esc_html_e('No more pages to load.', 'otw-portfolio-manager');?>" data-isotope="true">
      <?php esc_html_e('Load More', 'otw-portfolio-manager');?>
    </a>
  </div>
</div>
<!-- End Widget Load More Pagination -->

