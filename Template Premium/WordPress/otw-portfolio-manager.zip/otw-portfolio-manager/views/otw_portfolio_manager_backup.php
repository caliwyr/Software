<div class="wrap">
	<div id="icon-options-general" class="icon32"></div>
	<h2><?php esc_html_e('Export/Import (Backup)', 'otw-portfolio-manager'); ?></h2>
	<?php if( isset( $otw_pm_validate_messages ) && count( $otw_pm_validate_messages ) ){?>
		<div id="message" class="error">
			<?php foreach( $otw_pm_validate_messages as $v_message ){
				echo '<p>'.esc_html( $v_message ).'</p>';
			}?>
		</div>
	<?php }?>
	<?php if( otw_get( 'imported', false ) && ( otw_get( 'imported', '' ) ) ){?>
		<div class="updated">
			<p><?php esc_html_e( 'Backup imported!', 'otw-portfolio-manager' )?></p>
		</div>
	<?php }?>
	<form name="otw-pm-list-style" method="post" action="" class="validate">
		<br />
		<h3><?php esc_html_e('Export', 'otw-portfolio-manager'); ?></h3>
		<div class="otw_pm_sp_settings">
			<table class="form-table">
				<tr>
					<th scope="row"><label for="otw_pm_export_pm_posts"><?php esc_html_e('Export PM Posts', 'otw-portfolio-manager'); ?></label></th>
					<td>
						<select id="otw_pm_export_pm_posts" name="otw_pm_export_pm_posts">
							<option value="yes"<?php echo ( $otw_backup_values['otw_pm_export_pm_posts'] == 'yes' )?' selected="selected"':''?>><?php esc_html_e( 'Yes', 'otw-portfolio-manager' )?></option>
							<option value="no"<?php echo ( $otw_backup_values['otw_pm_export_pm_posts'] == 'no' )?' selected="selected"':''?>><?php esc_html_e( 'No', 'otw-portfolio-manager' )?></option>
						</select>
						<p class="description"><?php esc_html_e( 'This will export all PM posts.', 'otw-portfolio-manager' )?></p>
					</td>
				</tr>
				
				<tr>
					<th scope="row"><label for="otw_pm_export_pm_categories"><?php esc_html_e('Export PM Categories', 'otw-portfolio-manager'); ?></label></th>
					<td>
						<select id="otw_pm_export_pm_categories" name="otw_pm_export_pm_categories">
							<option value="yes"<?php echo ( $otw_backup_values['otw_pm_export_pm_categories'] == 'yes' )?' selected="selected"':''?>><?php esc_html_e( 'Yes', 'otw-portfolio-manager' )?></option>
							<option value="no"<?php echo ( $otw_backup_values['otw_pm_export_pm_categories'] == 'no' )?' selected="selected"':''?>><?php esc_html_e( 'No', 'otw-portfolio-manager' )?></option>
						</select>
						<p class="description"><?php esc_html_e( 'This will export all PM post categories and relations to the PM posts.', 'otw-portfolio-manager' )?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="otw_pm_export_pm_tags"><?php esc_html_e('Export PM Tags', 'otw-portfolio-manager'); ?></label></th>
					<td>
						<select id="otw_pm_export_pm_tags" name="otw_pm_export_pm_tags">
							<option value="yes"<?php echo ( $otw_backup_values['otw_pm_export_pm_tags'] == 'yes' )?' selected="selected"':''?>><?php esc_html_e( 'Yes', 'otw-portfolio-manager' )?></option>
							<option value="no"<?php echo ( $otw_backup_values['otw_pm_export_pm_tags'] == 'no' )?' selected="selected"':''?>><?php esc_html_e( 'No', 'otw-portfolio-manager' )?></option>
						</select>
						<p class="description"><?php esc_html_e( 'This will export all PM post tags and relations to the PM posts.', 'otw-portfolio-manager' )?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="otw_pm_export_pm_details"><?php esc_html_e('Export PM Details', 'otw-portfolio-manager'); ?></label></th>
					<td>
						<select id="otw_pm_export_pm_details" name="otw_pm_export_pm_details">
							<option value="yes"<?php echo ( $otw_backup_values['otw_pm_export_pm_details'] == 'yes' )?' selected="selected"':''?>><?php esc_html_e( 'Yes', 'otw-portfolio-manager' )?></option>
							<option value="no"<?php echo ( $otw_backup_values['otw_pm_export_pm_details'] == 'no' )?' selected="selected"':''?>><?php esc_html_e( 'No', 'otw-portfolio-manager' )?></option>
						</select>
						<p class="description"><?php esc_html_e( 'This will export all PM post details.', 'otw-portfolio-manager' )?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="otw_pm_export_pm_lists"><?php esc_html_e('Export PM Lists', 'otw-portfolio-manager'); ?></label></th>
					<td>
						<select id="otw_pm_export_pm_lists" name="otw_pm_export_pm_lists">
							<option value="yes"<?php echo ( $otw_backup_values['otw_pm_export_pm_lists'] == 'yes' )?' selected="selected"':''?>><?php esc_html_e( 'Yes', 'otw-portfolio-manager' )?></option>
							<option value="no"<?php echo ( $otw_backup_values['otw_pm_export_pm_lists'] == 'no' )?' selected="selected"':''?>><?php esc_html_e( 'No', 'otw-portfolio-manager' )?></option>
						</select>
						<p class="description"><?php esc_html_e( 'This will export all PM lists.', 'otw-portfolio-manager' )?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="otw_pm_export_pm_settings"><?php esc_html_e('Export PM Options', 'otw-portfolio-manager'); ?></label></th>
					<td>
						<select id="otw_pm_export_pm_settings" name="otw_pm_export_pm_settings">
							<option value="yes"<?php echo ( $otw_backup_values['otw_pm_export_pm_settings'] == 'yes' )?' selected="selected"':''?>><?php esc_html_e( 'Yes', 'otw-portfolio-manager' )?></option>
							<option value="no"<?php echo ( $otw_backup_values['otw_pm_export_pm_settings'] == 'no' )?' selected="selected"':''?>><?php esc_html_e( 'No', 'otw-portfolio-manager' )?></option>
						</select>
						<p class="description"><?php esc_html_e( 'This will export all PM settings.', 'otw-portfolio-manager' )?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="otw_pm_export_pm_custom_templates"><?php esc_html_e('Export PM Custom Templates', 'otw-portfolio-manager'); ?></label></th>
					<td>
						<select id="otw_pm_export_pm_custom_templates" name="otw_pm_export_pm_custom_templates">
							<option value="yes"<?php echo ( $otw_backup_values['otw_pm_export_pm_custom_templates'] == 'yes' )?' selected="selected"':''?>><?php esc_html_e( 'Yes', 'otw-portfolio-manager' )?></option>
							<option value="no"<?php echo ( $otw_backup_values['otw_pm_export_pm_custom_templates'] == 'no' )?' selected="selected"':''?>><?php esc_html_e( 'No', 'otw-portfolio-manager' )?></option>
						</select>
						<p class="description"><?php esc_html_e( 'This will export all PM single post custom templates.', 'otw-portfolio-manager' )?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="otw_pm_export_pages"><?php esc_html_e('Export Pages', 'otw-portfolio-manager'); ?></label></th>
					<td>
						<select id="otw_pm_export_pages" name="otw_pm_export_pages">
							<option value="no"<?php echo ( $otw_backup_values['otw_pm_export_pages'] == 'no' )?' selected="selected"':''?>><?php esc_html_e( 'No (default)', 'otw-portfolio-manager' )?></option>
							<option value="yes"<?php echo ( $otw_backup_values['otw_pm_export_pages'] == 'yes' )?' selected="selected"':''?>><?php esc_html_e( 'All Pages', 'otw-portfolio-manager' )?></option>
							<option value="yes_opm"<?php echo ( $otw_backup_values['otw_pm_export_pages'] == 'yes_opm' )?' selected="selected"':''?>><?php esc_html_e( 'All Pages with PM lists', 'otw-portfolio-manager' )?></option>
						</select>
						<p class="description"><?php esc_html_e( 'All Pages will export all pages on your installation. All Pages with PM lists will export all pages that have PM lists in the page editor or in the OTW Grid Manager.', 'otw-portfolio-manager' )?></p>
					</td>
				</tr>
			</table>
			<p class="submit">
				<input type="hidden" name="otw_pm_export_backup" value="1" />
				<input type="hidden" name="otw_pm_action" value="otw_pm_export_backup"/>
				<input type="submit" value="<?php esc_html_e( 'Export', 'otw-portfolio-manager') ?>" name="submit" class="button button-primary button-hero"/>
			</p>
		</div>
	</form>
	<form name="otw-pm-list-style" method="post" action="" class="validate" enctype="multipart/form-data">
		<h3><?php esc_html_e('Import', 'otw-portfolio-manager'); ?></h3>
		<div class="otw_pm_sp_settings">
			<?php if( $files_size_warning ){?>
				<div class="otw_info_block"><?php echo esc_html( $files_size_warning )?></div>
			<?php }?>
			<table class="form-table">
				<tr>
					<th scope="row"><label for="otw_pm_import_pm_file"><?php esc_html_e('Select file', 'otw-portfolio-manager'); ?></label></th>
					<td>
						<input type="file" id="otw_pm_import_pm_file" name="otw_pm_import_pm_file" />
						<p class="description"><?php esc_html_e( 'Select .ser file to be imploded.', 'otw-portfolio-manager' )?></p>
					</td>
				</tr>
			</table>
			<p class="submit">
				<input type="hidden" name="otw_pm_import_backup" value="1" />
				<input type="hidden" name="otw_pm_action" value="otw_pm_import_backup"/>
				<input type="submit" value="<?php esc_html_e( 'Import', 'otw-portfolio-manager') ?>" name="submit" class="button button-primary button-hero"/>
			</p>
		</div>
	</form>
</div>