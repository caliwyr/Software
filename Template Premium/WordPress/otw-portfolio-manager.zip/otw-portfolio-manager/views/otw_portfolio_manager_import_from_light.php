<div class="wrap">
	<div id="icon-options-general" class="icon32"></div>
	<h2><?php esc_html_e('Import from OTW Portfolio Light', 'otw-portfolio-manager'); ?>
	<a class="button add-new-h2" href="admin.php?page=otw-pm-settings"><?php esc_html_e('Back to options page', 'otw-portfolio-manager') ?></a>
	</h2>
	<div class="form-wrap" id="poststuff">
		<form method="post" action="" class="validate">
			<input type="hidden" name="otw_pm_action" value="import_from_light" />
			<div id="post-body">
				<div id="post-body-content">
					<div id="col-left">
						<?php if( isset( $light_items->posts ) && count( $light_items->posts ) ) {?>
							<p class="description"><?php esc_html_e('There are', 'otw-portfolio-manager' )?> <?php echo count( $light_items->posts )?> <?php esc_html_e( 'items to import from the OTW Portfolio Light plugin.', 'otw-portfolio-manager'); ?></p>
							<p class="description"><?php esc_html_e('Please confirm to import or cancel?', 'otw-portfolio-manager' ) ?></p>
						
						<?php }else{ ?>
							<p class="description"><?php esc_html_e('There are no items to import from the OTW Portfolio Light plugin.', 'otw-portfolio-manager'); ?></p>
						<?php }?>
						<p class="submit">
							<input type="submit" value="<?php esc_html_e( 'Confirm', 'otw-portfolio-manager') ?>" name="submit" class="button"/>
							<input type="submit" value="<?php esc_html_e( 'Cancel', 'otw-portfolio-manager' ) ?>" name="cancel" class="button"/>
						</p>
					</div>
				</div>
			</div>
		</form>
	</div>

</div>