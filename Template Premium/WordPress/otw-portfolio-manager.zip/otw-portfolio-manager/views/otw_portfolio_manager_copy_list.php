<div class="wrap">
	<div id="icon-edit" class="icon32"></div>
	<h2>
		<?php	echo __( 'Duplicate Portfolio List', 'otw-portfolio-manager' ); ?>
		<a class="add-new-h2" href="admin.php?page=otw-pm"><?php esc_html_e('Back', 'otw-portfolio-manager');?></a>
	</h2>
	<form name="otw-pm-copy-list" method="post" action="" class="validate">
		<?php
			if( !empty($this->errors) ){
				$errorMsg = esc_html__('Oops! Please check form for errors.', 'otw-portfolio-manager');
				echo '<div class="error"><p>'.$errorMsg.'</p></div>';
			}
		?>
		<input type="hidden" name="id" value="<?php echo esc_attr( $listID );?>" />
		<table class="form-table">
			<tbody>
				<tr valign="top">
					<th scope="row"><label for="list_name" class="required"><?php esc_html_e('Source Portfolio List Name', 'otw-portfolio-manager');?></label></th>
					<td><?php echo esc_html( $content['list_name'] );?>
						<div class="inline-error">
							<?php 
								( !empty($this->errors['source_list_name']) )? $errorMessage = $this->errors['source_list_name'] : $errorMessage = ''; 
								echo $errorMessage;
							?>
						</div>
					</td>
				</tr>
				<tr valign="top">
					<th scope="row"><label for="list_name" class="required"><?php esc_html_e('New Portfolio List Name', 'otw-portfolio-manager');?></label></th>
					<td>
						<input type="text" name="list_name" id="list_name" size="53" value="<?php echo esc_attr( $content['new_list_name'] );?>" />
						<p class="description"><?php esc_html_e( 'Note: The List Name is going to be used ONLY for the admin as a reference.', 'otw-portfolio-manager');?></p>
						<div class="inline-error">
							<?php 
								( !empty($this->errors['list_name']) )? $errorMessage = $this->errors['list_name'] : $errorMessage = ''; 
								echo $errorMessage;
							?>
						</div>
					</td>
				</tr>
			</tbody>
		</table>
		<p class="submit">
			<input type="submit" value="<?php esc_html_e( 'Duplicate', 'otw-portfolio-manager') ?>" name="submit-otw-pm-copy" class="button button-primary button-hero"/>
		</p>
	</form>
</div>
