<?php

	global $otw_pm_validate_messages;
?>
<div class="wrap">
	<div id="icon-options-general" class="icon32"></div>
	<h2><?php echo esc_html( $page_title ) ?>
		<a class="button add-new-h2" href="admin.php?page=otw-pm-details"><?php esc_html_e('Back to details list', 'otw-portfolio-manager') ?></a>
	</h2>
	<?php if( isset( $otw_pm_validate_messages ) && count( $otw_pm_validate_messages ) ){?>
		<div id="message" class="error">
			<?php foreach( $otw_pm_validate_messages as $v_message ){
				echo '<p>'.esc_html( $v_message ).'</p>';
			}?>
		</div>
	<?php }?>
	<div class="form-wrap" id="poststuff">
		<form method="post" action="" class="validate">
			<input type="hidden" name="otw_pm_action" value="manage_otw_pm_detail" />
			<div id="post-body">
				<div class="form-field form-required">
					<label for="pm_detail_title"><?php esc_html_e( 'Detail title', 'otw-portfolio-manager' );?></label>
					<input type="text" id="pm_detail_title" value="<?php echo esc_attr( $otw_pm_detail_values['title'] )?>" tabindex="1" size="30" name="pm_detail_title"/>
					<p><?php esc_html_e( 'The name is how it appears on your site.', 'otw-portfolio-manager' );?></p>
				</div>
				<div class="form-field form-required">
					<label for="pm_detail_order"><?php esc_html_e( 'Detail order', 'otw-portfolio-manager' );?></label>
					<input type="text" id="pm_detail_order" value="<?php echo esc_attr( $otw_pm_detail_values['order'] )?>" tabindex="2" size="4" name="pm_detail_order"/>
					<p><?php esc_html_e( 'The order.', 'otw-portfolio-manager' );?></p>
				</div>
				<p class="submit">
					<input type="submit" value="<?php esc_html_e( 'Save Detail', 'otw-portfolio-manager') ?>" name="submit" class="button"/>
				</p>
			</div>
		</form>
	</div>
</div>