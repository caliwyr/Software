<div class="wrap">
	<div id="icon-options-general" class="icon32"></div>
	<h2><?php echo esc_html( $page_title ) ?>
		<a class="button add-new-h2" href="admin.php?page=otw-pm-details"><?php esc_html_e('Back to details list', 'otw-portfolio-manager') ?></a>
	</h2>
	<div class="form-wrap" id="poststuff">
		<form method="post" action="" class="validate">
			<input type="hidden" name="otw_pm_action" value="<?php echo esc_attr( $otw_action )?>" />
			<?php wp_original_referer_field(true, 'previous'); wp_nonce_field('otw-pm-action'); ?>
			<div id="post-body">
				<div id="post-body-content">
					<div id="col-right">
						<div class="form-field form-required">
							<?php esc_html_e( 'Detail title', 'otw-portfolio-manager' );?>:
							<strong><?php echo esc_html( $otw_detail_values['title'] )?></strong>
						</div>
					</div>
					<div id="col-left">
						<p>
							<?php echo $confirm_text;?>
						</p>
						<p class="submit">
							<input type="submit" value="<?php esc_html_e( 'Confirm', 'otw-portfolio-manager') ?>" name="submit" class="button"/>
							<input type="submit" value="<?php esc_html_e( 'Cancel', 'otw-portfolio-manager' ) ?>" name="cancel" class="button"/>
						</p>
					</div>
				</div>
			</div>
		</form>
	</div>
</div>