<input type="hidden" name="otw_pm_meta_options" value="1" />
<table class="form-table otw_pm_options_table">
	<tbody>
		<tr>
			<th><label for="otw_pm_options_type"><?php esc_html_e( 'Select default or custom options:', 'otw-portfolio-manager' );?></label></th>
			<td>
				<select id="otw_pm_options_type" name="otw_pm_options_type">
					<option value="default"<?php echo ( $otw_pm_options_meta_data['otw_pm_options_type']=='default' )?' selected="selected"':''?> ><?php esc_html_e( 'Default', 'otw-portfolio-manager' );?></option>
					<option value="custom"<?php echo ( $otw_pm_options_meta_data['otw_pm_options_type']=='custom' )?' selected="selected"':''?> ><?php esc_html_e( 'Custom', 'otw-portfolio-manager' );?></option>
				</select>
    				<p class="description"><?php esc_html_e( 'Default means that you want to apply the default options set in Portfolio Manager -> Options -> Portfolio items single page. Custom means the options that will apply for this portfolio post is what you set bellow.', 'otw-portfolio-manager' );?></p>
			</td>
		</tr>
	</tbody>
</table>
<table class="form-table" id="otw_pm_custom_options_table">
	<tr>
		<th scope="row"><label for="otw_pm_template"><?php esc_html_e('Template', 'otw-portfolio-manager'); ?></label></th>
		<td>
			<select id="otw_pm_template" name="otw_pm_template">
			<?php foreach( $otw_pm_templates as $template_key => $template_name ){?>
				<?php
					$selected = '';
					if( isset( $otw_pm_options_meta_data['options']['otw_pm_template'] ) && ( $otw_pm_options_meta_data['options']['otw_pm_template'] == $template_key ) ){
						$selected = ' selected="selected"';
					}
				?>
				<?php if( $template_key == '-' ){ ?>
					<option disabled="disabled">------------------------------------------</option>
				<?php }else{ ?>
					<option value="<?php echo esc_attr( $template_key )?>"<?php echo $selected?>><?php echo esc_html( $template_name )?></option>
				<?php } ?>
			<?php }?>
			</select>
			<p class="description"><?php esc_html_e( 'This is the template for your single portfolio page.', 'otw-portfolio-manager' )?></p>
		</td>
	</tr>
	<tr>
		<th scope="row"><label for="otw_pm_item_title"><?php esc_html_e('Show Post Title', 'otw-portfolio-manager'); ?></label></th>
		<td>
			<select id="otw_pm_item_title" name="otw_pm_item_title">
			<?php foreach( $otw_pm_item_title_options as $key => $name ){?>
				<?php
					$selected = '';
					if( isset( $otw_pm_options_meta_data['options']['otw_pm_item_title'] ) && ( $otw_pm_options_meta_data['options']['otw_pm_item_title'] == $key ) ){
						$selected = ' selected="selected"';
					}
				?>
				<option value="<?php echo esc_attr( $key )?>"<?php echo $selected?>><?php echo esc_html( $name )?></option>
			<?php }?>
			</select>
			<p class="description"><?php esc_html_e( 'This will show the post title.', 'otw-portfolio-manager' )?></p>
		</td>
	</tr>
	<tr>
		<th scope="row"><label for="otw_pm_social_icons"><?php esc_html_e('Social Icons', 'otw-portfolio-manager'); ?></label></th>
		<td>
			<select id="otw_pm_social_icons" name="otw_pm_social_icons">
			<?php foreach( $otw_pm_social_icons as $icon_key => $icon_name ){?>
				<?php
					$selected = '';
					if( isset( $otw_pm_options_meta_data['options']['otw_pm_social_icons'] ) && ( $otw_pm_options_meta_data['options']['otw_pm_social_icons'] == $icon_key ) ){
						$selected = ' selected="selected"';
					}
				?>
				<option value="<?php echo esc_attr( $icon_key )?>"<?php echo $selected?>><?php echo esc_html( $icon_name )?></option>
			<?php }?>
			</select>
			<p class="description"><?php esc_html_e( 'Show Social Icons for Portfolio items single page.', 'otw-portfolio-manager' )?></p>
		</td>
	</tr>
	<tr>
		<th scope="row"><label for="otw_pm_prev_next_nav"><?php esc_html_e('Enable Previous / Next Post Navigation', 'otw-portfolio-manager'); ?></label></th>
		<td>
			<select id="otw_pm_prev_next_nav" name="otw_pm_prev_next_nav">
			<?php foreach( $otw_pm_prev_next_nav_options as $key => $name ){?>
				<?php
					$selected = '';
					if( isset( $otw_pm_options_meta_data['options']['otw_pm_prev_next_nav'] ) && ( $otw_pm_options_meta_data['options']['otw_pm_prev_next_nav'] == $key ) ){
						$selected = ' selected="selected"';
					}
				?>
				<option value="<?php echo esc_attr( $key )?>"<?php echo $selected?>><?php echo esc_html( $name )?></option>
			<?php }?>
			</select>
			<p class="description"><?php esc_html_e( 'Enable Previous / Next Post Navigation for Portfolio items single page.', 'otw-portfolio-manager' )?></p>
		</td>
	</tr>
	<tr>
		<th scope="row"><label for="otw_pm_related_posts"><?php esc_html_e('Enable Related Posts', 'otw-portfolio-manager'); ?></label></th>
		<td>
			<select id="otw_pm_related_posts" name="otw_pm_related_posts">
			<?php foreach( $otw_pm_related_posts_options as $key => $name ){?>
				<?php
					$selected = '';
					if( isset( $otw_pm_options_meta_data['options']['otw_pm_related_posts'] ) && ( $otw_pm_options_meta_data['options']['otw_pm_related_posts'] == $key ) ){
						$selected = ' selected="selected"';
					}
				?>
				<option value="<?php echo esc_attr( $key )?>"<?php echo $selected?>><?php echo esc_html( $name )?></option>
			<?php }?>
			</select>
			<p class="description"><?php esc_html_e( 'Enable Related Posts for Portfolio items single page. Related Posts selection is based on Portfolio category.', 'otw-portfolio-manager' )?></p>
		</td>
	</tr>
	<tr>
		<th scope="row"><label for="otw_pm_related_posts_criteria"><?php esc_html_e('Related Post Criteria', 'otw-portfolio-manager'); ?></label></th>
		<td>
			<select id="otw_pm_related_posts_criteria" name="otw_pm_related_posts_criteria">
			<?php foreach( $otw_pm_related_posts_criteria_options as $key => $name ){?>
				<?php
					$selected = '';
					if( isset( $otw_pm_options_meta_data['options']['otw_pm_related_posts_criteria'] ) && ( $otw_pm_options_meta_data['options']['otw_pm_related_posts_criteria'] == $key ) ){
						$selected = ' selected="selected"';
					}
				?>
				<option value="<?php echo esc_attr( $key )?>"<?php echo $selected?>><?php echo esc_html( $name )?></option>
			<?php }?>
			</select>
			<p class="description"><?php esc_html_e( 'Select the Related Post Criteria.', 'otw-portfolio-manager' )?></p>
		</td>
	</tr>
	<tr>
		<th scope="row"><label for="otw_pm_related_posts_number"><?php esc_html_e('Related Posts Count per Slide', 'otw-portfolio-manager'); ?></label></th>
		<td>
			<input type="text" name="otw_pm_related_posts_number" id="otw_pm_related_posts_number" value="<?php echo esc_attr( $otw_pm_options_meta_data['options']['otw_pm_related_posts_number'] )?>" />
			<p class="description"><?php esc_html_e( 'This is how many related posts will be visible per slide of the carousel. Default is 4.', 'otw-portfolio-manager' )?></p>
		</td>
	</tr>
	<tr>
		<th scope="row"><label for="otw_pm_description_title_text"><?php esc_html_e('Project Description Title Text', 'otw-portfolio-manager'); ?></label></th>
		<td>
			<input type="text" name="otw_pm_description_title_text" id="otw_pm_description_title_text" value="<?php echo otw_htmlentities( $otw_pm_options_meta_data['options']['otw_pm_description_title_text'] )?>" />
			<p class="description"><?php esc_html_e( 'Enter custom Project Description Title Text. If empty "Project Description" will be used.', 'otw-portfolio-manager' )?></p>
		</td>
	</tr>
	<tr>
		<th scope="row"><label for="otw_pm_details_title_text"><?php esc_html_e('Project details Title Text', 'otw-portfolio-manager'); ?></label></th>
		<td>
			<input type="text" name="otw_pm_details_title_text" id="otw_pm_details_title_text" value="<?php echo otw_htmlentities( $otw_pm_options_meta_data['options']['otw_pm_details_title_text'] )?>" />
			<p class="description"><?php esc_html_e( 'Enter custom Project Details Title Text. If empty "Project Details" will be used.', 'otw-portfolio-manager' )?></p>
		</td>
	</tr>
	<tr>
		<th scope="row"><label for="otw_pm_social_title_text"><?php esc_html_e('Social Icons Title Text', 'otw-portfolio-manager'); ?></label></th>
		<td>
			<input type="text" name="otw_pm_social_title_text" id="otw_pm_social_title_text" value="<?php echo otw_htmlentities( $otw_pm_options_meta_data['options']['otw_pm_social_title_text'] )?>" />
			<p class="description"><?php esc_html_e( 'Enter custom Project Social Icons Title Text. If empty "Hey, like this? Why not share it with a buddy?" will be used.', 'otw-portfolio-manager' )?></p>
		</td>
	</tr>
	<tr>
		<th scope="row"><label for="otw_pm_moreinfo_title_text"><?php esc_html_e('More Project Info Title Text', 'otw-portfolio-manager'); ?></label></th>
		<td>
			<input type="text" name="otw_pm_moreinfo_title_text" id="otw_pm_moreinfo_title_text" value="<?php echo otw_htmlentities( $otw_pm_options_meta_data['options']['otw_pm_moreinfo_title_text'] )?>" />
			<p class="description"><?php esc_html_e( 'Enter custom More Project Info Title Text. If empty "More Project Info" will be used.', 'otw-portfolio-manager' )?></p>
		</td>
	</tr>
	<tr>
		<th scope="row"><label for="otw_pm_related_title_text"><?php esc_html_e('Project related Title Text', 'otw-portfolio-manager'); ?></label></th>
		<td>
			<input type="text" name="otw_pm_related_title_text" id="otw_pm_related_title_text" value="<?php echo otw_htmlentities( $otw_pm_options_meta_data['options']['otw_pm_related_title_text'] )?>" />
			<p class="description"><?php esc_html_e( 'Enter custom Related Projects Title Text. If empty "Related Projects" will be used.', 'otw-portfolio-manager' )?></p>
		</td>
	</tr>
	<tr>
		<th scope="row"><label for="otw_pm_item_media_width"><?php esc_html_e('Media Width', 'otw-portfolio-manager'); ?></label></th>
		<td>
			<input type="text" name="otw_pm_item_media_width" id="otw_pm_item_media_width" value="<?php echo esc_attr( $otw_pm_options_meta_data['options']['otw_pm_item_media_width'] )?>" />
			<p class="description"><?php esc_html_e( 'Default 650px. Use -1 if you want to disable cropping and use the original image upload.', 'otw-portfolio-manager' )?></p>
		</td>
	</tr>
	<tr>
		<th scope="row"><label for="otw_pm_item_media_height"><?php esc_html_e('Media Height', 'otw-portfolio-manager'); ?></label></th>
		<td>
			<input type="text" name="otw_pm_item_media_height" id="otw_pm_item_media_height" value="<?php echo esc_attr( $otw_pm_options_meta_data['options']['otw_pm_item_media_height'] )?>" />
			<p class="description"><?php esc_html_e( 'Default 580px. Use -1 if you want to disable cropping and use the original image upload.', 'otw-portfolio-manager' )?></p>
		</td>
	</tr>
	<tr>
		<th scope="row"><label for="otw_pm_item_media_format"><?php esc_html_e('Media Format', 'otw-portfolio-manager'); ?></label></th>
		<td>
			<select id="otw_pm_item_media_format" name="otw_pm_item_media_format">
			<?php foreach( $otw_pm_item_media_format_options as $key => $name ){?>
				<?php
					$selected = '';
					if( isset( $otw_pm_options_meta_data['options']['otw_pm_item_media_format'] ) && ( $otw_pm_options_meta_data['options']['otw_pm_item_media_format'] == $key ) ){
						$selected = ' selected="selected"';
					}
				?>
				<option value="<?php echo esc_attr( $key )?>"<?php echo $selected?>><?php echo esc_html( $name )?></option>
			<?php }?>
			</select>
			<p class="description"><?php esc_html_e( 'Cropping images formats.', 'otw-portfolio-manager' )?></p>
		</td>
	</tr>
	<tr valign="top">
		<th scope="row"><label for="otw_pm_item_media_alt_attr"><?php esc_html_e('Add alt tag', 'otw-portfolio-manager');?></label></th>
		<td>
			<?php ( empty($otw_pm_options_meta_data['options']['otw_pm_item_media_alt_attr']) )? $otw_pm_item_media_alt_attr = 'no' : $otw_pm_item_media_alt_attr = $otw_pm_options_meta_data['options']['otw_pm_item_media_alt_attr']; ?>
			<select name="otw_pm_item_media_alt_attr" id="otw_pm_item_media_alt_attr">
				<option value="no" <?php echo ( $otw_pm_item_media_alt_attr == 'no' )?'selected="selected"':'';?> ><?php esc_html_e( 'No (default)', 'otw-portfolio-manager');?></option>
				<option value="media_settings" <?php echo ( $otw_pm_item_media_alt_attr == 'media_settings' )?'selected="selected"':'';?> ><?php esc_html_e( 'Use what is set in the Media Library', 'otw-portfolio-manager');?></option>
			</select>
			<p class="description"><?php esc_html_e('The alt tag helps position your images in search engines.', 'otw-portfolio-manager');?></p>
		</td>
	</tr>
	<tr valign="top">
		<th scope="row"><label for="otw_pm_item_media_title_attr"><?php esc_html_e('Add title tag', 'otw-portfolio-manager');?></label></th>
		<td>
			<?php ( empty($otw_pm_options_meta_data['options']['otw_pm_item_media_title_attr']) )? $otw_pm_item_media_title_attr = 'no' : $otw_pm_item_media_title_attr = $otw_pm_options_meta_data['options']['otw_pm_item_media_title_attr']; ?>
			<select name="otw_pm_item_media_title_attr" id="otw_pm_item_media_title_attr">
				<option value="no" <?php echo ( $otw_pm_item_media_title_attr == 'no' )?'selected="selected"':'';?> ><?php esc_html_e( 'No (default)', 'otw-portfolio-manager');?></option>
				<option value="media_settings" <?php echo ( $otw_pm_item_media_title_attr == 'media_settings' )?'selected="selected"':'';?> ><?php esc_html_e( 'Use what is set in the Media Library', 'otw-portfolio-manager');?></option>
			</select>
			<p class="description"><?php esc_html_e('The title tag helps position your images in search engines and is displayed on hover of the image.', 'otw-portfolio-manager');?></p>
		</td>
	</tr>
	<tr>
		<th scope="row"><label for="otw_pm_related_media_width"><?php esc_html_e('Related Posts Media Width', 'otw-portfolio-manager'); ?></label></th>
		<td>
			<input type="text" name="otw_pm_related_media_width" id="otw_pm_related_media_width" value="<?php echo esc_attr( $otw_pm_options_meta_data['options']['otw_pm_related_media_width'] )?>" />
			<p class="description"><?php esc_html_e( 'Default 220px. Use -1 if you want to disable cropping and use the original image upload.', 'otw-portfolio-manager' )?></p>
		</td>
	</tr>
	<tr>
		<th scope="row"><label for="otw_pm_related_media_height"><?php esc_html_e('Related Posts Media Height', 'otw-portfolio-manager'); ?></label></th>
		<td>
			<input type="text" name="otw_pm_related_media_height" id="otw_pm_related_media_height" value="<?php echo esc_attr( $otw_pm_options_meta_data['options']['otw_pm_related_media_height'] )?>" />
			<p class="description"><?php esc_html_e( 'Default 150px. Use -1 if you want to disable cropping and use the original image upload.', 'otw-portfolio-manager' )?></p>
		</td>
	</tr>
	<tr>
		<th scope="row"><label for="otw_pm_related_media_format"><?php esc_html_e('Related Posts Media Format', 'otw-portfolio-manager'); ?></label></th>
		<td>
			<select id="otw_pm_related_media_format" name="otw_pm_related_media_format">
			<?php foreach( $otw_pm_item_media_format_options as $key => $name ){?>
				<?php
					$selected = '';
					if( isset( $otw_pm_options_meta_data['options']['otw_pm_related_media_format'] ) && ( $otw_pm_options_meta_data['options']['otw_pm_related_media_format'] == $key ) ){
						$selected = ' selected="selected"';
					}
				?>
				<option value="<?php echo esc_attr( $key )?>"<?php echo $selected?>><?php echo esc_html( $name )?></option>
			<?php }?>
			</select>
			<p class="description"><?php esc_html_e( 'Cropping images formats.', 'otw-portfolio-manager' )?></p>
		</td>
	</tr>
	<tr>
		<th scope="row"><label for="otw_pm_media_lightbox"><?php esc_html_e('Enable Media Lightbox', 'otw-portfolio-manager'); ?></label></th>
		<td>
			<select id="otw_pm_media_lightbox" name="otw_pm_media_lightbox">
			<?php foreach( $otw_pm_media_lightbox_options as $key => $name ){?>
				<?php
					$selected = '';
					if( isset( $otw_pm_options_meta_data['options']['otw_pm_media_lightbox'] ) && ( $otw_pm_options_meta_data['options']['otw_pm_media_lightbox'] == $key ) ){
						$selected = ' selected="selected"';
					}
				?>
				<option value="<?php echo esc_attr( $key )?>"<?php echo $selected?>><?php echo esc_html( $name )?></option>
			<?php }?>
			</select>
			<p class="description"><?php esc_html_e( 'Enables a lightbox on click on the media.', 'otw-portfolio-manager' )?></p>
		</td>
	</tr>
	<tr>
		<th scope="row"><label for="otw_pm_item_media_lightbox_width"><?php esc_html_e('Media Lightbox Width', 'otw-portfolio-manager'); ?></label></th>
		<td>
			<input type="text" name="otw_pm_item_media_lightbox_width" id="otw_pm_item_media_lightbox_width" value="<?php echo esc_attr( $otw_pm_options_meta_data['options']['otw_pm_item_media_lightbox_width'] )?>" />
			<p class="description"><?php esc_html_e( 'Default 1024px. Use -1 if you want to disable cropping and use the original image upload.', 'otw-portfolio-manager' )?></p>
		</td>
	</tr>
	<tr>
		<th scope="row"><label for="otw_pm_item_media_lightbox_height"><?php esc_html_e('Media Lightbox Height', 'otw-portfolio-manager'); ?></label></th>
		<td>
			<input type="text" name="otw_pm_item_media_lightbox_height" id="otw_pm_item_media_lightbox_height" value="<?php echo esc_attr( $otw_pm_options_meta_data['options']['otw_pm_item_media_lightbox_height'] )?>" />
			<p class="description"><?php esc_html_e( 'Default 640px. Use -1 if you want to disable cropping and use the original image upload.', 'otw-portfolio-manager' )?></p>
		</td>
	</tr>
	<tr>
		<th scope="row"><label for="otw_pm_item_media_lightbox_format"><?php esc_html_e('Media Lightbox Format', 'otw-portfolio-manager'); ?></label></th>
		<td>
			<select id="otw_pm_item_media_lightbox_format" name="otw_pm_item_media_lightbox_format">
			<?php foreach( $otw_pm_item_media_format_options as $key => $name ){?>
				<?php
					$selected = '';
					if( isset( $otw_pm_options_meta_data['options']['otw_pm_item_media_lightbox_format'] ) && ( $otw_pm_options_meta_data['options']['otw_pm_item_media_lightbox_format'] == $key ) ){
						$selected = ' selected="selected"';
					}
				?>
				<option value="<?php echo esc_attr( $key )?>"<?php echo $selected?>><?php echo esc_html( $name )?></option>
			<?php }?>
			</select>
			<p class="description"><?php esc_html_e( 'Cropping images formats.', 'otw-portfolio-manager' )?></p>
		</td>
	</tr>
</table>