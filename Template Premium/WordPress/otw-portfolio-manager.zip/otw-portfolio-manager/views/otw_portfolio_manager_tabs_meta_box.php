<input type="hidden" name="otw_pm_meta_tabs" value="1" />
<i><?php esc_html_e( 'Tabs are optional. Tabs apply only to the "With Tabs" Portfolio items single page template and your custom templates. HTML and shortcodes are enabled in Tab Content areas.', 'otw-portfolio-manager' );?></i>
<table class="form-table" id="otw_pm_tabs_table">
	<tbody>
		<?php for( $cT = 0; $cT < $total_tabs; $cT++ ){?>
			<tr valign="top">
				<th>
					<label for="otw_pm_tab_title_<?php echo esc_attr( $cT )?>"><?php esc_html_e( 'Tab Title', 'otw-portfolio-manager' );?></label>
				</th>
				<td>
					<input type="text" id="otw_pm_tab_title_<?php echo esc_attr( $cT )?>" name="otw_pm_tab_title[<?php echo $cT?>]" value="<?php echo $otw_pm_tabs_meta_data[ $cT ]['title']?>" size="63"/>
				</td>
			</tr>
			<tr valign="top">
				<th>
					<label for="otw_pm_tab_content_<?php echo esc_attr( $cT )?>"><?php esc_html_e( 'Tab Content', 'otw-portfolio-manager' );?></label>
				</th>
				<td>
					<textarea  id="otw_pm_tab_content_<?php echo esc_attr( $cT )?>" name="otw_pm_tab_content[<?php echo $cT ?>]" rows="10" cols="63"><?php echo otw_stripslashes( $otw_pm_tabs_meta_data[ $cT ]['content'] ) ?></textarea>
				</td>
			</tr>
		<?php }?>
	</tbody>
</table>
<table class="form-table otw_pm_tabs_add_table" id="otw_pm_tabs_add_table">
	<tbody>
		<tr valign="top">
			<th>
				<label for="otw_pm_tab_title_next_row_id"><?php esc_html_e( 'Tab Title', 'otw-portfolio-manager' );?></label>
			</th>
			<td>
				<input type="text" id="otw_pm_tab_title_next_row_id" name="otw_pm_tab_title[next_row_id]" value="" size="63"/>
			</td>
		</tr>
		<tr valign="top">
			<th>
				<label for="otw_pm_tab_content_next_row_id"><?php esc_html_e( 'Tab Content', 'otw-portfolio-manager' );?></label>
			</th>
			<td>
				<textarea  id="otw_pm_tab_content_next_row_id" name="otw_pm_tab_content[next_row_id]" rows="10" cols="63"></textarea>
			</td>
		</tr>
	</tbody>
</table>
<input type="button" value="<?php esc_html_e( 'Add Tab', 'otw-portfolio-manager' )?>" class="button" id="otw_pm_add_tab" name="otw_pm_add_tab" />
