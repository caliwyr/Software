<?php
$otw_pm_factory_object->labels['License Details']=esc_html__('License Details', 'otw-portfolio-manager');
$otw_pm_factory_object->labels['Domain']=esc_html__('Domain', 'otw-portfolio-manager');
$otw_pm_factory_object->labels['Version']=esc_html__('Version', 'otw-portfolio-manager');
$otw_pm_factory_object->labels['No information available']=esc_html__('No information available', 'otw-portfolio-manager');
$otw_pm_factory_object->labels['Expires']=esc_html__('Expires', 'otw-portfolio-manager');
$otw_pm_factory_object->labels['Product Code']=esc_html__('Product Code', 'otw-portfolio-manager');
$otw_pm_factory_object->labels['Please confirm to deregister the code?']=esc_html__('Please confirm to deregister the code?', 'otw-portfolio-manager');
$otw_pm_factory_object->labels['Delete Code']=esc_html__('Delete Code', 'otw-portfolio-manager');
$otw_pm_factory_object->labels['Have a code, paste it here']=esc_html__('Have a code, paste it here', 'otw-portfolio-manager');
$otw_pm_factory_object->labels['Submit Code']=esc_html__('Submit Code', 'otw-portfolio-manager');
$otw_pm_factory_object->labels['No plugin information found.']=esc_html__('No plugin information found.', 'otw-portfolio-manager');
?>