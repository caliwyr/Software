<?php
/**
Component Name: OTW Portfolio Template Shortcode
Plugin URI: http://OTWthemes.com
Description:  OTW Portfolio Template Shortcode
Author: OTWthemes.com
Version: 3.1
Author URI: http://themeforest.net/user/OTWthemes
*/

$otw_component = array();
$otw_component['name']       = 'OTW Portfolio Template Shortcode';
$otw_component['version']    = '3000.1';
$otw_component['class_name'] = 'OTW_Portfolio_Template_Shortcode';

?>