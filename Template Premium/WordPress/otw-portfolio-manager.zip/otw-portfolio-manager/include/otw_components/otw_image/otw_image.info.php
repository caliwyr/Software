<?php
/**
Component Name: OTW Image
Plugin URI: http://OTWthemes.com
Description:  OTW Form
Author: OTWthemes.com
Version: 5.4
Author URI: http://themeforest.net/user/OTWthemes
*/

$otw_component = array();
$otw_component['name']       = 'OTW Image';
$otw_component['version']    = '5000.4';
$otw_component['class_name'] = 'OTW_Image';
?>