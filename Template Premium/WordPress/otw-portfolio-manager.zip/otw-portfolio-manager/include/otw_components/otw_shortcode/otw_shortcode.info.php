<?php
/**
Component Name: OTW Shortcode
Plugin URI: http://OTWthemes.com
Description:  OTW Shortcode
Author: OTWthemes.com
Version: 5.7
Author URI: http://themeforest.net/user/OTWthemes
*/

$otw_component = array();
$otw_component['name']       = 'OTW Shortcode';
$otw_component['version']    = '5000.7';
$otw_component['class_name'] = 'OTW_Shortcode';

?>