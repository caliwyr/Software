<?php
/**
Component Name: OTW Portfolio Template Grid Manager
Plugin URI: http://OTWthemes.com
Description:  OTW Portfolio Template Grid Manager
Author: OTWthemes.com
Version: 2.1
Author URI: http://themeforest.net/user/OTWthemes
*/

$otw_component = array();
$otw_component['name']       = 'OTW Portfolio Template Grid Manager';
$otw_component['version']    = '2000.3';
$otw_component['class_name'] = 'OTW_Portfolio_Template_Grid_Manager';

?>