#!/usr/bin/env python
# -*- coding:utf-8 -*-

def general_multiplespaces(payload):
	# -- general -- #
	return payload.replace(' ','  ') if payload else payload