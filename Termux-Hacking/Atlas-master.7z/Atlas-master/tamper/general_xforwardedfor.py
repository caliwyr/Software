#!/usr/bin/env python
# -*- coding:utf-8 -*-


def general_xforwardedfor(payload):
	# -- generic -- 
    # https://github.com/sqlmapproject/sqlmap/blob/master/tamper/xforwardedfor.py
    # add headers manually
    return payload