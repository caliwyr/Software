from core.config import Config

config_object = Config('config.json')
