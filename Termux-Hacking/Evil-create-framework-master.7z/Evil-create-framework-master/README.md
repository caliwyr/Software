# Evil-create-framework
# (C)Copyright 2018 LOoLzeC Scurity
<br>
tools to make viruses simple
<br>
$ git clone https://github.com/LOoLzeC/Evil-create-framework.git
<br>
$ cd Evil-create-framework
<br>
$ sh install.sh
<br>
<br>
# Simple commands
<br>
vcrt > show options
<br>
<>
REPORT ME BUG ON INSTAGRAM
# Contact
<br>
instagram : @yungreyyxrist
<br>
facebook : facebook.com/ctl.gaul
<br>
# Thanks to
# Blackhole Scurity
