# Check-Number

## Api web
```
{

      "status": "success",
      "phone": "+6281288572373",
      "phone_valid": true,
      "phone_type": "mobile",
      "phone_region": "Indonesia",
      "country": "Indonesia",
      "country_code": "ID",
      "country_prefix": "62",
      "international_number": "+62 812-8857-2373",
      "local_number": "0812-8857-2373",
      "e164": "+6281288572373",
      "carrier": "Telkomsel"

}
```
## Install
```
pkg install git
pkg install python
pkg install nano
pkg install MC
pip install requests

git clone https://github.com/Aldi098/Check-Number

cd Check-Number
```

## jalankan SC
```
python phone.py
```
