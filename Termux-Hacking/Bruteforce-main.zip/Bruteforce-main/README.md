# Bruteforce

```git clone https://github.com/Aldi098/Bruteforce ```

```cd Bruteforce```
 
```python2 Brute.py```
