# emoji-bash
``` install sendiri😘 ```

``` Enc Kusus python python2 ```
# install

```git clone https://github.com/Aldi098/emoji-bash```

```cd emoji-bash```

```bash run```

```bisa juga```

```bash emoji```
