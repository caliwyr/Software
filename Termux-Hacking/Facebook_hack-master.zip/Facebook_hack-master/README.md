# Facebook_hack
# Note 
Find me....for username and password

# Find me on 

Instagram account
👉[![Instagram  ](https://img.shields.io/badge/INSTAGRAM-FOLLOW-red?style=for-the-badge&logo=instagram)](https://www.instagram.com/shubhamg0sain)👈



### screenshot
![ ](https://raw.githubusercontent.com/ShuBhamg0sain/Facebook_hack/master/Screenshot/IMG_20200925_195618.jpg)

# [ Installation ]
```
 apt update && apt upgrade
 apt install git python2
 git clone https://github.com/ShuBhamg0sain/Facebook_hack.git
 cd Facebook_hack
```

# [ Setup ]
```
$ pip2 install -r requirements.txt
```
# [ Running ]
```
$ python2 ShuBham.py
```


* if you are confused how to use it, please type 'help' to display the help menu
* [Warn] please turn off your VPN before using this program !!!
* [Tips] do not overuse this program !!!

![]()
