## fungsi
````
> Bruteforce Gmail menggunakan wordlist
> Mudah di gunakan
> No ribet dah
````
## Script
````
> pkg install update
> pkg install upgrade
> pkg install nano
> pkg install git
> pkg install figlet
> pkg install toilet
> git clone https://github.com/Aldi098/Bruteforce-gmail
> cd Bruteforce-gmail
> python enc_gmail.py
````
## Thanks You
````
> Teman²
> Allah SWT
> Ibu
> Bapak
> Kaka
````
