<html>
<body>
<h1 align="center">ATSCAN SCANNER</h1>
<p align="center"> 
  <a title="Version 17.0.0" href="https://github.com/AlisamTechnology/ATSCAN/releases">
     <img src="https://img.shields.io/badge/V%207.0.1-Stable-blue.svg">
  </a>
  <a title="No issue known"href="https://github.com/AlisamTechnology/ATSCAN/issues">
    <img src="https://img.shields.io/badge/Issues-None-brightgreen.svg">
  </a>
  <a title="MIT License" href="https://github.com/AlisamTechnology/ATSCAN/blob/master/License.txt">
    <img src="https://img.shields.io/badge/License-MIT-blue.svg">
  </a>  
  <a title="Perl Download" href="https://www.perl.org/get.html">
    <img src="https://img.shields.io/badge/Perl-Required-yellow.svg">
  </a>
    <img title="Works in all platforms" src="https://img.shields.io/badge/Platform-All-green.svg">
  <a title="Follow us in Facebook" href="https://www.facebook.com/Alisam.Technology/">
    <img src="https://img.shields.io/badge/Facebook-Follow-blue.svg">
  </a>
</p> 
<p align="center"> <b>Advanced Mass Search / Dork / Exploitation Scanner  </b></p>
<table border="0" cellpadding="2" cellspacing="2" width="100%">
  <tr>
    <td align="center"><img title="Legal desclaimer" src="https://imgur.com/7OzJEBI.png"></td>
     <td align="center"> <b><a href="https://github.com/AlisamTechnology/">Alisam Technology</a> is not responsible for any misuse, damage caused by this script or attacking targets without prior mutual consent! It is your responsibility to obey laws!</b>
    </td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2" width="100%">
  <tr>
    <td width="100px" class="main2"><b>Codename:</b></td><td width="780px">4n0n4t</td>
  </tr>
  <tr>
    <td width="100px" class="main2"><b>AUTHOR:</b></td><td width="780px">Ali MEHDIOUI</td>
  </tr>
  <tr>
    <td width="100px" class="main2"><b>GROUP:</b></td><td width="780px">Alisam@Technology</td>
  </tr>
</table>
<table border="0" cellpadding="2" cellspacing="5" width="100%">
  <tr>
	&#9733; <b>Description:</b>
  </tr>
  <tr>
    <td class="main" width="546px"><p>
	    &#x25cf; Engines: [Google apis cache] Bing Ask Yandex Sogou Exalead Shodan<br />
        &#x25cf; Mass Dork Search<br/>
		&#x25cf; Multiple instant scans. <br/>
		&#x25cf; Mass Exploitation <br/>
		&#x25cf; Use proxy. <br/>
        &#x25cf; Random user agent. <br/>
		&#x25cf; Random engine.<br/> 
		&#x25cf; Mass Extern commands execution.<br/>
		&#x25cf; Exploits and issues search.<br/>
        &#x25cf; XSS / SQLI / LFI / AFD scanner.<br /> 
		&#x25cf; Filter wordpress & Joomla sites. <br />
		&#x25cf; Wordpress theme and plugin detection. <br />
        &#x25cf; Find Admin page.<br />
		&#x25cf; Decode / Encode Base64 / MD5<br/> 
    </p></td>
    <td class="main" width="340px"><p>
		&#x25cf; Ports scan. <br/>
		&#x25cf; Collect IPs<br/>
		&#x25cf; Collect E-mails. <br/>
        &#x25cf; Auto detect errors. <br/> 
        &#x25cf; Auto detect forms. <br/> 		
		&#x25cf; Auto detect Cms.<br/>
		&#x25cf; Post data.<br/>
		&#x25cf; Auto sequence repeater.<br/>
        &#x25cf; Validation.<br/>
		&#x25cf; Post and Get method<br/>
		&#x25cf; IP Localisation<br/>
		&#x25cf; Issues and Exploit search<br/>
		&#x25cf; Interactive and Normal interface.<br/>
		&#x25cf; And more...
    </p></td>
  </tr>
</table>
<table border="0" cellpadding="2" cellspacing="5" width="100%">
  <tr>
    <td class="main3" width="890px"> <b>&#9733; Libreries to install:</b></td>
  </tr>
  <tr>
    <td class="main">
      <a title="Perl Download" href="https://www.perl.org/get.html">Perl</a> Required. <br/>
      Works in all platforms.
      Disponible in <a href="https://blackarch.org/">Blackarch</a> and <a href="https://dracos-linux.org/">Dracos</a> Linux.
    </td>
  </tr>
</table>
<table border="0" cellpadding="2" cellspacing="5" width="100%">
  <tr>
    <td class="main3" width="890px">&#9733; <b>Download:</b></td>
  </tr>
  <tr>
    <td class="main">
      &#x25cf; git clone https://github.com/AlisamTechnology/ATSCAN <br/>
      &#x25cf; direct link: https://github.com/AlisamTechnology/ATSCAN
    </td>
  </tr>
</table>
<table border="0" cellpadding="2" cellspacing="5" width="100%">
  <tr>
    <td class="main3" width="890px">&#9733; <b>Permissions:</b></td>
  </tr>
  <tr>
    <td class="main">
      cd ATSCAN <br/>
      chmod +x ./atscan.pl
    </td>
  </tr>
</table>
<table border="0" cellpadding="2" cellspacing="5" width="100%">
  <tr>
    <td class="main3" width="890px">&#9733; <b>Installation:</b></td>
  </tr>
  <tr>
    <td class="main">chmod +x ./install.sh <br/>./install.sh </td>
  </tr>
</table>

<table border="0" cellpadding="2" cellspacing="5" width="100%">
  <tr>
    <td class="main3" width="890px">&#9733; <b>Execution:</b></td>
  </tr>
  <tr>
    <td class="main">
      Portable Execution: perl ./atscan.pl<br/>
      Installed Tool Execution: atscan<br/>
      Menu: Applications >  Web Application analysis > atscan </td>
  </tr>
</table>
<table border="0" cellpadding="2" cellspacing="5" width="100%">
  <tr>
    <td class="main3" width="890px">&#9733; <b>Repair Tool:</b></td>
  </tr>
  <tr>
    <td class="main">
      atscan --repair<br/>
    </td>
  </tr>
</table>
<table border="0" cellpadding="2" cellspacing="5" width="100%">
  <tr>
    <td class="main3" width="890px">&#9733; <b>Uninstall Tool:</b></td>
  </tr>
  <tr>
    <td class="main">
      atscan --uninstall<br/>
    </td>
  </tr>
</table>
<table border="0" cellpadding="2" cellspacing="5" width="100%">
  <tr>
    <td class="main3" width="890px">&#9733; <b>Commands:</b></td>
  </tr>
  <tr>
    <td class="main"><table border="0" cellpadding="2" cellspacing="5" width="100%">
      <tr>
        <td width="200px" class="main">--help / -h </td>
        <td class="main">Help.</td>
      </tr> 
      <tr>
        <td width="200px" class="main">--proxy</td>
        <td class="main">
          Set tor proxy for scans [EX: --proxy "socks4://localhost:9050"]<br>
          Set proxy [EX: --proxy "http://12.45.44.2:8080"] <br>
          Set proxy list [EX: --proxy file] </td>
      </tr> 
      <tr>
        <td width="200px" class="main">--prandom</td>
        <td class="main">Random proxy [EX: --prandom file] or --prandom "socks://localhost:9050"]</td>
      </tr>
      <tr>
        <td width="200px" class="main">--motor / -m</td>
        <td class="main">bing google ask yandex sogou exalead googleapis googlecache or all</td>
      </tr>
      <tr>
        <td width="200px" class="main">--apikey</td>
        <td class="main">Apikey</td>
      </tr> 
      <tr>
        <td width="200px" class="main">--cx</td>
        <td class="main">Googleapis ID</td>
      </tr> 
      <tr>
        <td width="200px" class="main">--mrandom</td>
        <td class="main">Random of given engines</td> 
      </tr> 
      <tr>
        <td width="200px" class="main">--brandom</td>
        <td class="main">Random all disponibles agents </td>
      </tr>
      <tr>
        <td width="200px" class="main">--freq</td>
        <td class="main">Random time frequency (in seconds) </td>
      </tr>
      <tr>
        <td width="200px" class="main">--time</td>
        <td class="main">set browser time out</td> 
      </tr> 
      <tr>
        <td width="200px" class="main">--dork / -d </td>
        <td class="main"> Dork to search [Ex: house [OTHER]cars [OTHER]hotel] 
      </tr> 
      <tr>
        <td width="200px" class="main">--target / -t</td>
        <td class="main">Target </td>
      </tr> 
      <tr>
        <td width="200px" class="main">--level / -l</td>
        <td class="main"> Scan level (Number of results pages to scan) </td>
      </tr>
      <tr>
        <td width="200px" class="main">--zone </td>
        <td class="main"> Search engine country.</td>
      </tr>
      <tr>
        <td width="200px" class="main">--param / -p </td>
        <td class="main"> Set test parameter EX:id,cat,product_ID </td>
      </tr> 
      <tr>
        <td width="200px" class="main">--save / -s </td>
        <td class="main"> Output.</td>
      </tr>
      <tr>
        <td width="200px" class="main">--source</td>
        <td class="main"> Html output file</td>
      </tr>
      <tr>
        <td width="200px" class="main">--bugtraq</td>
        <td class="main"> Serach exploits and issues</td>
      </tr>
      <tr>
        <td width="200px" class="main">--content</td>
        <td class="main"> Print request content</td>
      </tr>
      <tr>
        <td width="200px" class="main">--data</td>
        <td class="main"> Post and Get forms. See examples </td>
      </tr>
      <tr>
        <td width="200px" class="main">--vshell</td>
        <td class="main"> Validate by url ex: --HOST/shell.php or file</td>
      </tr>
      <tr>
        <td width="200px" class="main">--post</td>
        <td class="main"> Use post method </td>
      </tr>
      <tr>
        <td width="200px" class="main">--get</td>
        <td class="main"> Use get method </td>
      </tr>      
      <tr>
        <td width="200px" class="main">--header</td>
        <td class="main"> Set headers </td>
      </tr>
      <tr>
        <td width="200px" class="main">--fullHeaders</td>
        <td class="main"> Print full request headers </td>
      </tr>      
      <tr>
        <td width="200px" class="main">--host </td>
        <td class="main"> Domain name [Ex: site.com] </td>
      </tr> 
      <tr>
        <td width="200px" class="main">--nobanner </td>
        <td class="main"> Hide tool banner</td>
      </tr> 
      <tr>
        <td width="200px" class="main">--beep </td>
        <td class="main"> Produce beep sound if positive scan found.</td>
      </tr> 
      <tr>
        <td width="200px" class="main">--ifend</td>
        <td class="main"> Produce beep sound when scan process is finished.</td>
      </tr> 
      <tr>
        <td width="200px" class="main">--noverbose </td>
        <td class="main"> No scan verbose.</td>
      </tr>
      <tr>
        <td width="200px" class="main">--ping </td>
        <td class="main"> Host ping.</td>
      </tr>
      <tr>
        <td width="200px" class="main">--limit </td>
        <td class="main"> Limit max positive scan results.</td>
      </tr> 
      <tr>
        <td width="200px" class="main">--valid / -v   </td>
        <td class="main"> Validate by string at least 1 is matching</td>
      </tr>
      <tr>
        <td width="200px" class="main">--validAll </td>
        <td class="main"> Validate all given strings </td>
      </tr>
      <tr>
        <td width="200px" class="main">--status  </td>
        <td class="main"> Validate by http header status </td>
      </tr> 
      <tr>
        <td width="200px" class="main">--server  </td>
        <td class="main"> Validate by server</td>
      </tr> 	  
      <tr>
        <td width="200px" class="main">--ifinurl </td>
        <td class="main"> Get targets with exact string matching</td>
      </tr> 
      <tr>
        <td width="200px" class="main">--sregex </td>
        <td class="main"> Get targets with exact regex matching</td>
      </tr>
      <tr>
        <td width="200px" class="main">--exclude </td>
        <td class="main"> Get targets where strings do not exist in html</td>
      </tr>
      <tr>
        <td width="200px" class="main">--excludeAll </td>
        <td class="main"> Get targets where all strings do not exist in html</td>
      </tr>	  
      <tr>
        <td width="200px" class="main">--unique  </td>
        <td class="main"> Get targets with exact dork matching</td>
      </tr> 
      <tr>
        <td width="200px" class="main">--replace</td>
        <td class="main"> Replace exact string </td>
      </tr> 
      <tr>
        <td width="200px" class="main">--replaceFROM  </td>
        <td class="main"> Replace from string to the end of target </td>
      </tr>
      <tr>
        <td width="200px" class="main">--exp / -e </td>
        <td class="main"> Exploit/Payload will be added to full target </td>
      </tr>
      <tr>
        <td width="200px" class="main">--expHost </td>
        <td class="main"> Exploit will be added to the host </td>
      </tr>
      <tr>
        <td width="200px" class="main">--expIp</td>
        <td class="main"> Exploit will be added to the host ip</td>
      </tr>
      <tr>
        <td width="200px" class="main">--xss </td>
        <td class="main"> Xss scan </td>
      </tr> 
      <tr>
      <tr>
        <td width="200px" class="main">--sql </td>
        <td class="main"> Sqli scan </td>
      </tr> 
      <tr>
        <td width="200px" class="main">--lfi </td>
        <td class="main"> Local file inclusion</td> 
      </tr> 
      <tr>
        <td width="200px" class="main">--joomrfi </td>
        <td class="main"> Scan for joomla local file inclusion.</td>
      </tr> 
      <tr>
        <td width="200px" class="main">--shell </td>
        <td class="main"> Shell link [Ex: http://www.site.com/shell.txt] </td>
      </tr> 
      <tr>
        <td width="200px" class="main">--wpafd  </td>
        <td class="main"> Scan wordpress sites for arbitrary file download</td>
      </tr> 
      <tr>
        <td width="200px" class="main">--admin </td>
        <td class="main"> Get site admin page </td>
      </tr> 
      <tr>
        <td width="200px" class="main">--shost  </td>
        <td class="main"> Get site subdomains </td>
      </tr>
      <tr>
        <td width="200px" class="main">--port </td>
        <td class="main"> port </td>
      </tr> 
      <tr>
        <td width="200px" class="main">--tcp </td>
        <td class="main"> TCP port </td>
      </tr> 
      <tr>
        <td width="200px" class="main">--udp </td>
        <td class="main"> UDP port</td> 
      </tr> 
      <tr>
        <td width="200px" class="main">--getlinks  </td>
        <td class="main"> Get target html links </td>
      </tr> 	  
      <tr>
        <td width="200px" class="main">--wp</td>
        <td class="main"> Wordpress site</td>
      </tr> 
      <tr>
        <td width="200px" class="main">--joom  </td>
        <td class="main"> Joomla site</td>
      </tr> 
      <tr>
        <td width="200px" class="main">--zip  </td>
        <td class="main"> Get zip files </td>
      </tr> 
      <tr>
        <td width="200px" class="main">--md5</td>
        <td class="main"> Convert to md5 </td>
      </tr> 
      <tr>
        <td width="200px" class="main">--encode64  </td>
        <td class="main"> Encode base64 string </td>
      </tr> 
      <tr>
        <td width="200px" class="main">--decode64  </td>
        <td class="main"> decode base64 string 
      </tr> 
      <tr>
        <td width="200px" class="main">--TARGET </td>
        <td class="main"> Will be replaced by target in extern command </td>
      </tr> 
      <tr>
        <td width="200px" class="main">--HOST  </td>
        <td class="main"> Will be replaced by host in extern command </td>
      </tr> 
      <tr>
        <td width="200px" class="main">--HOSTIP </td>
        <td class="main"> Will be replaced by host IP in extern command </td>
      </tr> 
      <tr>
        <td width="200px" class="main">--PORT </td>
        <td class="main"> Will be replaced by open port in extern command </td>
      </tr> 
      <tr>
        <td width="200px" class="main">--ips  </td>
        <td class="main"> Collect Ips</td>
      </tr> 
      <tr>
        <td width="200px" class="main">--geoloc  </td>
        <td class="main"> Ip geolocalisation</td>
      </tr> 
      <tr>
        <td width="200px" class="main">--regex</td>
        <td class="main"> Crawl to get strings matching regex</td>
      </tr> 
      <tr>
        <td width="200px" class="main">--noquery  </td>
        <td class="main"> Remove string value from Query url [ex: site.com/index.php?id=string]  </td> 
      </tr> 
      <tr>
        <td width="200px" class="main">--command / -c  </td>
        <td class="main"> Extern Command to execute</td>
      </tr>
      <tr>
        <td width="200px" class="main">--popup  </td>
        <td class="main"> Execute Extern Command in new terminal window</td>
      </tr>
      <tr>
        <td width="200px" class="main">--zoneH  </td>
        <td class="main"> Upload to Zone-H</td>
      </tr>
      <tr>
        <td width="200px" class="main">--saveCookie</td>
        <td class="main">Cookies output file</td>
      </tr>
      <tr>
        <td width="200px" class="main">--setCookies</td>
        <td class="main">Cookie file</td>
      </tr>
      <tr>
        <td width="200px" class="main">--email  </td>
        <td class="main"> Collect emails </td>
      </tr> 
      <tr>
        <td width="200px" class="main"> rang(x-y) </td>
           <td class="main">EX: --expHost "/index.php?id=rang(1-9)" --sql OR -t "site.com/index.php?id=rang(1-9)" --sql<br>
           site.com/index.php?id=1 -> 9.</td>
      </tr> 
      <tr>
        <td width="200px" class="main"> repeat(txt-y) </td>
           <td class="main">EX: --expHost "/index.php?id=repeat(../-9)wp-config.php" --status 200 OR -t "site.com/index.php?id=../wp-config.php"<br>
           In site.com/index.php?id=../wp-config.php then site.com/index.php?id=../../wp-config.php 9 times </td>
      </tr>       
      <tr>
        <td width="200px" class="main">[OTHER]</td>
        <td class="main">To separate values ex: dork1 [OTHER]DORK2 [OTHER]DORK3</td>
      </tr>
      <tr>
        <td width="200px" class="main">--googleapi</td>
        <td class="main">Google Apis</td>
      </tr>
      <tr>
        <td width="200px" class="main">--shodan</td>
        <td class="main">Shodan search</td>
      </tr>
      <tr>
        <td width="200px" class="main">--count</td>
        <td class="main">Search Shodan without Results</td>
      </tr>
      <tr>
        <td width="200px" class="main">--count</td>
        <td class="main">Search Shodan</td>
      </tr>
      <tr>
        <td width="200px" class="main">--dnsreverset</td>
        <td class="main">Shodan Reverse DNS Lookup</td>
      </tr>
      <tr>
        <td width="200px" class="main">--dnsresolve</td>
        <td class="main">Shodan Resolve DNS Lookup</td>
      </tr>
      <tr>
        <td width="200px" class="main">--tokens</td>
        <td class="main">String filters and parameters</td>
      </tr>
      <tr>
        <td width="200px" class="main">--querysearch</td>
        <td class="main">Search the directory of saved Shodan search queries</td>
      </tr>
      <tr>
        <td width="200px" class="main">--query</td>
        <td class="main">List the saved Shodan search queries</td>
      </tr>
      <tr>
        <td width="200px" class="main">--querytags</td>
        <td class="main">List the most popular Shodan tags</td>
      </tr>
      <tr>
        <td width="200px" class="main">--myip</td>
        <td class="main">List all services that Shodan crawls</td>
      </tr>
      <tr>
        <td width="200px" class="main">--services</td>
        <td class="main">List all services that Shodan crawls</td>
      </tr>
      <tr>
        <td width="200px" class="main">--apinfo</td>
        <td class="main">My Shodan API Plan Information</td>
      </tr>
      <tr>
        <td width="200px" class="main">--ports</td>
        <td class="main"> List of port numbers that the crawlers are looking for</td>
      </tr>
      <tr>
        <td width="200px" class="main">--protocols</td>
        <td class="main"> List all protocols that can be used when performing on-demand Internet scans via Shodan.</td>
      </tr>
      <tr>
        <td width="200px" class="main">--honeyscore</td>
        <td class="main"> Calculates honeypot score ranging from 0 (not a honeypot) to 1.0 (is a honeypot) in shodan</td>
      </tr>
      <tr>
        <td width="200px" class="main">--facets</td>
        <td class="main">Shodan search facets</td>
      </tr>
      <tr>
        <td width="200px" class="main">--update</td>
        <td class="main"> Update tool</td>
      </tr>
      <tr>
        <td width="200px" class="main">--repair</td>
        <td class="main">Repair or force tool update.</td>
      </tr>
      <tr>
        <td width="200px" class="main">--tool / -?</td>
        <td class="main">Tool info.</td>
      </tr>
      <tr>
        <td width="200px" class="main">--config</td>
        <td class="main">User configuration.</td>
      </tr>
      <tr>
        <td width="200px" class="main">--interactive / -i</td>
        <td class="main">Interactive mode interface.</td>
      </tr>
      <tr>
        <td width="200px" class="main">--uninstall</td>
        <td class="main">Uninstall Tool.</td>
      </tr> 
    </table></td>
  </tr>
</table>
<table border="0" cellpadding="2" cellspacing="5" width="100%">
  <tr>
    <td width="890px">&#9733; <b>Examples:</b></td>
  </tr>
  <tr>
    <td class="main">
      <table border="0" cellpadding="2" cellspacing="5" width="100%"><tr><td>  
        &#x25cf; <b>PROXY: </b> <br/>
        Tor: --proxy [proxy] [Ex: --proxy socks://localhost:9050].<br/>
        Proxy: Proxy: --proxy [proxy] Ex: http://12.32.1.5:8080 <br/>
        or --proxy file Ex: --proxy my_proxies.txt <br/>
        <hr>
        &#x25cf; <b>RANDOM: </b> <br/>
        Random proxy: --prandom [proxy  file] <br/>
        Random browser: --brandom <br/>
        Random engine: --mrandom [ENGINES]<br/>
        <hr>
       &#x25cf; <b>SET HEADERS:</b> <br>
       atscan --dork [dork / dorks.txt] --level [level] --header "Authorization => 'Basic YWRtaW46YWRtaW4', keep_alive => '1'" <br/>
       atscan -t target --data "name=>username, email=>xxxxxx, pass=>xxxxx" --post --header "Authorization => 'Basic YWRtaW46YWRtaW4', keep_alive => '1'" <br/>
        <hr>
      &#x25cf; <b>SEARCH ENGINE: </b> <br/>
       Search: atscan --dork [dork] --level [level]  <br/>
	   Search: atscan -d [dork] -l [level] --getlinks <br/>
       Set engine: atscan --dork [dork] --level [level] -m bing or google,ask,yandex or all <br/>
       Set selective engines: atscan -d [dork] -l [level] -m google,bing,.. <br/>
       Search with many dorks: atscan --dork dork1 [OTHER]dork2 [OTHER]dork3] --level [level]    <br/>
       Get Server wordpress sites: atscan -t [target] --wp <br/>
       Search + output: atscan --dork [dorks.txt] --level [level] --save <br/>
       Search + get emails: atscan -d [dorks.txt] -l [level] --email  <br/>
       Search + get site emails: atscan --dork site:site.com --level [level] --email  <br/>
       Search + get ips: atscan --dork [dork] --level [level] --ips  <br/>
        <hr>
       &#x25cf; <b>REGULAR EXPRESSIONS: </b> <br/>
       Regex use: atscan [--dork [dork> / -t [target]] --level [level] --regex [regex] <br/>
       IP: ((?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){ 3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)) <br/>
       E-mails: '((([A-Za-z0-9]+_+)|([A-Za-z0-9]+\-+)|([A-Za-z0-9]+\.+)|([A-Za-z0-9]+\++))*[A-Za-z0-9]+@((\w+\-+)|(\w+\.))*\w{1,63}\.[a-zA-Z]{2,6})' <br/>
        <hr>
       &#x25cf; <b>REPEATER:</b> <br/>
       atscan -t site.com?index.php?id=rang(1-10) --sql <br/>
       atscan -t [target] --expHost "/index.php?id=rang(1-10)" --sql <br/>
       atscan -t [target] --expHost "/index.php?id=repeat(../-9)wp-config.php" <br/>
        <hr>
       &#x25cf; <b>PORTS</b> <br/>
       atscan -t [ip] --port [port] [--udp / --tcp] <br/>
       atscan -t (ip start)-(ip end) --port [port] [--udp / --tcp] <br/>
       atscan -t [ip] --port (port start)-(port end) [--udp / --tcp] --command "your extern command" <br/>
        <hr>
       &#x25cf; <b>ENCODE / DECODE:</b> <br/>
       Generate MD5: --md5 [string] <br/>
       Encode base64: --encode64 [string] <br/>
       Decode base64: --decode64 [string] <br/>
        <hr>
       &#x25cf; <b>DATA:</b> <br/>
       Data: atscan -t [target] --data "field1=>value1, field2=>value2, field3=>value3" [--post / --get /]<br/>
       Exploit: --exp/expHost <exploit> --data "field1=>value1, field2=>value2, field3=>value3" --vshell [shell path] -v [string] / --status [code] [--post / --get / --upload] <br/>
       Wordlist: --data "field1=>value1, field2=>WORDLIST:<wordlist path>" --vshell [shell path] -v [string] / --status [code] [--post / --get] <br/>
        <hr>
       &#x25cf; <b>EXTERNAL COMMANDS:</b> <br/>
       atscan --dork [dork / dorks.txt] --level [level] --command "curl -v --TARGET" <br/>
       atscan --dork [dork / dorks.txt] --level [level] --command "file" <br/>
       atscan --dork [dork / dorks.txt] --level [level] --command "curl -v --HOST"  <br/>
       atscan --dork [dork / dorks.txt] --level [level] --command "nmap -sV -p 21,22,80 --HOSTIP"  <br/>
       atscan -d "index of /lib/scripts/dl-skin.php" -l 2 -m bing --command "php WP-dl-skin.php-exploit.php --TARGET" <br/>
       atscan --shodan --search [string] --apikey [API KEY] -command [extern_command]<br/>
        <hr>
       &#x25cf; <b>MULTIPLE SCANS: </b><br/>
       atscan --dork [dork> --level [10] --sql --lfi --wp ..<br/>
       atscan --dork [dork> --level [10] --replace [string => new_string] --exp/expHost [payload] [--sql / --lfi / --wp /...]<br/>
       atscan -t [ip] --level [10] [--sql / --lfi / --wp /...]<br/>
       atscan -t [target] [--sql / --lfi / --wp /...] <br/>
        <hr>
       &#x25cf; <b>IP LOCALISATION: </b><br/>
       atscan -t [ip/target] --geoloc <br/>
        <hr>
       &#x25cf; <b>SEARCH VALIDATION: </b><br/>
       atscan -d [dork / dorks.txt] -l [level] --status [code] / --valid [string/file] <br/>
       atscan -d [dork / dorks.txt] -l [level] --status [code] / --valid [string/file] <br/>
       atscan -d [dork / dorks.txt] -l [level] --status [code] / --exclude [string/file] <br/>
       atscan -d [dork / dorks.txt] -l [level] --ifinurl [string] <br/>
       atscan -d [dork / dorks.txt] -l [level] --sregex [regex] --valid [string] <br/>
       atscan -d [dork / dorks.txt] -l [level] --regex [regex] --valid [string] <br/>
       atscan -d [dork / dorks.txt] -l [level] --unique  <br/>
       atscan -t [target / targets.txt] [--status [code] / --valid [string] <br/>
       atscan -t [target / targets.txt] --vshell [file path] <br/>
       atscan -d [dork / dorks.txt] -l [level] --exp/expHost [payload] --status [code] / --valid [string] <br/>
       atscan -d [dorks.txt] -l [level] --replace [string => new_string] --status [code] / --valid [string] <br/>
       atscan -d [dork / dorks.txt] -l [level] [--admin / --sql ..] --status [code] / --valid [string] <br/>  
       atscan -d [dorks.txt] -l [level] --replace [string => new_string] --status [code] / --valid [string] <br/>
       atscan -d [dorks.txt] -l [level] --replaceFROM [string => new_string] --status [code] / --valid [string] <br/>
       atscan -d [dorks.txt] -l [level] --replace [string => new_string] --exp/expHost [payload] --status [code] / --valid [string] <br/>
       atscan -d [dork / dorks.txt] -l [level] [--sql / --shost ..] --status [code] / --valid [string] <br/>
       atscan -t [target / targets.txt] --valid [string] --exclude [string]<br/>
        <hr>
       &#x25cf; <b>ZONE-H: </b><br/>
       atscan -t [target / targets.txt] -v [string] --zoneH "notifier => --HOST/index.php" <br/>
        <hr>
       &#x25cf; <b>SEARCH EXPLOITS: </b><br/>
       atscan --bugtraq -d [string] -l 1 EX: atscan --bugtraq -d wordpress -l 1<br/> 
       atscan --bugtraq -d file.txt -l 1<br/>
       atscan --bugtraq -d [string] -l 1--limit 10 <br/> 
        <hr>
       &#x25cf; <b>GOOGLEAPIS SEARCH</b> <br/> 
       atscan --dork [string or file] -l 1 --apikey [API KEY] --cx [ID]<br/>
       atscan --dork [string or file] -l 1 --apikey [API KEY] --cx [ID] -v [string]<br/>
       atscan --dork [string or file] -l 1 --apikey [API KEY] --cx [ID] --exp [exploit]<br/>
       atscan --dork [string or file] -l 1 --apikey [API KEY] --cx [ID] [ANY APTION]<br/>
        <hr>
       &#x25cf; <b>SHODAN SEARCH</b> <br/> 
       atscan --shodan --targget [ip or host or file] --apikey [API KEY] <br/>
       atscan --shodan --dork [string or file] --apikey [API KEY] <br/>
       atscan --shodan --dnsresolve [ip or host or file] --apikey [API KEY] <br/>
       atscan --shodan --dnsrevese [ip or host or file] --apikey [API KEY] <br/>
       atscan --shodan --count [query or file] --apikey [API KEY] <br/>
       atscan --shodan --query --apikey [API KEY] <br/>
       atscan --shodan --querysearch [query or file] --apikey [API KEY] <br/>
       atscan --shodan --querytags --apikey [API KEY] <br/>
       atscan --shodan --myip --apikey [API KEY] <br/>
       atscan --shodan --apinfo --apikey [API KEY] <br/>
       atscan --shodan --services --apikey [API KEY] <br/>
       atscan --shodan --ports --apikey [API KEY] <br/>	 
       atscan --shodan --tokens [string or file] --apikey [API KEY] <br/>	 
        <hr>
       &#x25cf; <b>UPDATE TOOL:</b> <br/> 
       atscan --update <br/>
        <hr>
       &#x25cf; <b>UNINSTALL TOOL: </b><br/>     
       atscan --uninstall
        <hr>
       &#x25cf; <b>THANKS TO: </b><br/>     
       Blackarch linux & Dragos Os developers to incorporate my project in their systems.
       </td></tr></table>     
    </td>
  </tr>
</table>  
</body>
</html>
