## FACEBOOK
```
> pkg install git
> pkg install nano
> pkg install python2
> pkg install time
> pkg install datetime
> pip3 install requests
> git clone https://github.com/Aldi098/FACEBOOK
> cd FACEBOOK
> python3 enc_run.py
```
## Fungsi
```
> LOGIN TOKEN FB
> GET ID FRIEND
> GET ID PUBLIC
> GET ID FOLLOWERS
```
## THANK YOU
```
> Allah SWT
> Bapak
> Ibu
> Kaka
> Teman²
```
SUBSCRIBE CHANNEL AING MR.1557
