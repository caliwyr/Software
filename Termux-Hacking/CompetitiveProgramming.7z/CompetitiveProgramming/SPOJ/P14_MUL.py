t = int(input())
while t>0:
  t-=1
  n1, n2 = map(int, input().split())
  print(n1*n2)
