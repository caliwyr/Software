# Competitive Programming
This is my collection of Python Programs that I have solved on various competitive programming websites.<br />

Each file contains a unique problem statement and its corresponding solution/solutions.

For beginners I would recommend:
* Start with [HackerEarth](https://www.hackerearth.com/challenges/)
* Then move on to [SPOJ](http://www.spoj.com/problems/classical/)
* Lastly solve [CodeChef](https://www.codechef.com/problems/easy)

Omkar Pathak,<br />
Pune, Maharashtra, India.<br />
