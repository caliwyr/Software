## CCTV
```
pkg install git
pkg install nano
pkg install python
pkg install update
pip install requests
pip2 install requests
git clone https://github.com/Aldi098/CCTV
cd CCTV
python CCTV.py
```
## Fungsi
```
Hack cctv
Menu 16 CCTV
```
