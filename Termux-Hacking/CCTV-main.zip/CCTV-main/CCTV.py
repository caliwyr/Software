import os,sys,time,json,requests
from datetime import datetime
saat_ini = datetime.now()
tgl = saat_ini.strftime('%d')
bln = saat_ini.strftime('%m')
thn = saat_ini.strftime('%Y')
waktu_new = (tgl+"-"+bln+"-"+thn)
xnxx="\033[85m"
q="\033[00m"
h2="\033[40m"
b2="\033[44m"
c2="\033[46m"
i2="\033[42m"
u2="\033[45m"
m2="\033[41m"
p2="\033[47m"
k2="\033[43m"
b='\033[1;34m'
i='\033[1;32m'
c='\033[1;36m'
m='\033[1;31m'
u='\033[1;35m'
k='\033[1;33m'
p='\033[1;37m'
h='\033[1;90m'
k3="\033[43m\033[1;37m"
b3="\033[44m\033[1;37m"
m3="\033[41m\033[1;37m"
def lo():
    print ("SUBSCRIBE YT AING HELA!")
    time.sleep(1)
    os.system("xdg-open https://youtube.com/channel/UC7ygjAbDjuiN76PqOlJm40A")
    time.sleep(3)
import sys,time
def ketik(teks):
 for i in teks + "\n":
  sys.stdout.write(i)
  sys.stdout.flush()
  time.sleep(0.01)



qu = '\033[0;36m' #aqua
hi = '\033[0;32m' #hijau
pu = '\033[0;37m' #putih
me = '\033[0;31m' #merah
ku = '\033[0;33m'


qu = '\033[0;36m' #aqua
hi = '\033[0;32m' #hijau
pu = '\033[0;37m' #putih
me = '\033[0;31m' #merah
ku = '\033[0;33m'




import json,requests

url = requests.get("https://api.myip.com").text
js = json.loads(url)

os.system("clear")
time.sleep (3)
ketik(m +"        ____ ")
ketik(m +"   _[]_/____\__n_ ")
ketik(m +"  |_____.--.__()_|       "+ k  +"       H A C K  C C T V ")
ketik(m +"  |LI  //# \\     | ")
ketik(p +"  |    \\__//     |      "+ p +"   Creator "+ m +": "+ h +"ALDI BACHTIAR RIFAI ")
ketik(p +"  |     '--'     |       "+ p +"  YouTube "+ m +":"+ h +" MR.1557 / B0C4H ")
ketik(p +"  '--------------'       "+ p +"  Thanks for "+ m +":"+ h +" Panglima jateng / Pejuang kentang")
ketik(p +"────────────────────────────────────────────────────────────────────")
ketik(p +"      ➣"+ k +" DATE "+ m +": "+ p + waktu_new +"    "+ p +"  ➣ "+ k +"YOUR IP"+ m +" :"+ h +" {}".format(js["ip"]))
ketik("")
ketik(k +" ➣"+ m +" ["+ p +"01"+ m +"]"+ p +" CCTV 1           "+ k +"  ➣"+ m +" ["+ p +"06"+ m +"]"+ p +" CCTV 6        "+ k +"    ➣"+ m +" ["+ p +"11"+ m +"]"+ p +" CCTV 11 ")
ketik(k +" ➣"+ m +" ["+ p +"02"+ m +"]"+ p +" CCTV 2            "+ k +" ➣"+ m +" ["+ p +"07"+ m +"]"+ p +" CCTV 7        "+ k +"    ➣"+ m +" ["+ p +"12"+ m +"]"+ p +" CCTV 12 ")
ketik(k +" ➣"+ m +" ["+ p +"03"+ m +"]"+ p +" CCTV 3 	         "+ k +"  ➣"+ m +" ["+ p +"08"+ m +"]"+ p +" CCTV 8        "+ k +"    ➣"+ m +" ["+ p +"13"+ m +"]"+ p +" CCTV 13 ")
ketik(k +" ➣"+ m +" ["+ p +"04"+ m +"]"+ p +" CCTV 4            "+ k +" ➣"+ m +" ["+ p +"09"+ m +"]"+ p +" CCTV 9        "+ k +"    ➣"+ m +" ["+ p +"14"+ m +"]"+ p +" CCTV 14 ")
ketik(k +" ➣"+ m +" ["+ p +"05"+ m +"]"+ p +" CCTV 5            "+ k +" ➣"+ m +" ["+ p +"10"+ m +"]"+ p +" CCTV 10       "+ k +"    ➣"+ m +" ["+ p +"15"+ m +"]"+ p +" CCTV 15 ")
ketik("")
ketik(k +"                       ➣ "+ m +"["+ p +"16"+ m +"]"+ p +" CCTV 16 NO OPEN WEB ")
ketik("")
pil = input(k +" ➣ "+ p +"Choose"+ m +" > "+ i)
print("")
print (k +" ➣ "+ p +"Please wait...")
time.sleep (3)
if pil =='1' or pil =='01':
   os.system("xdg-open http://119.2.50.116:90/#view")
   ent = input (m +"["+ p +" Klik Enter Untuk kembali Ke Menu "+ m +"] ")
   os.system("python CCTV.py")
elif pil =='2' or pil =='02':
     os.system("xdg-open http://119.2.50.116:84/view/viewer_index.shtml?id=1183")
     ent = input (m +"["+ p +" Klik Enter Untuk kembali Ke Menu "+ m +"] ")
     os.system("python CCTV.py")
elif pil =='3' or pil =='03':
     os.system("xdg-open http://202.150.130.137:88/control/userimage.html")
     ent = input (m +"["+ p +" Klik Enter Untuk kembali Ke Menu "+ m +"] ")
     os.system("python CCTV.py")
elif pil =='4' or pil =='04':
     os.system("xdg-open http://118.137.102.29:8001/view/viewer_index.shtml?id=12647")
     ent = input (m +"["+ p +" Klik Enter Untuk kembali Ke Menu "+ m +"] ")
     os.system("python CCTV.py")
elif pil =='5' or pil =='05':
     os.system("xdg-open http://103.217.216.198:8001/#view")
     ent = input (m +"["+ p +" Klik Enter Untuk kembali Ke Menu "+ m +"] ")
     os.system("python CCTV.py")
elif pil =='6' or pil =='06':
     os.system("xdg-open http://103.217.216.197:8001/#view")
     ent = input (m +"["+ p +" Klik Enter Untuk kembali Ke Menu "+ m +"] ")
     os.system("python CCTV.py")
elif pil =='7' or pil =='07':
     os.system("xdg-open http://103.52.16.102:82/live/index.html?Language=0")
     ent = input (m +"["+ p +" Klik Enter Untuk kembali Ke Menu "+ m +"] ")
     os.system("python CCTV.py")
elif pil =='8' or pil =='08':
     os.system("xdg-open http://202.52.50.183:8001/#view")
     ent = input (m +"["+ p +" Klik Enter Untuk kembali Ke Menu "+ m +"] ")
     os.system("python CCTV.py")
elif pil =='9' or pil =='09':
     os.system("xdg-open http://103.217.216.198:8000/#view")
     ent = input (m +"["+ p +" Klik Enter Untuk kembali Ke Menu "+ m +"] ")
     os.system("python CCTV.py")
elif pil =='10':
     os.system("xdg-open http://119.252.169.189:82/mobile.htm")
     ent = input (m +"["+ p +" Klik Enter Untuk kembali Ke Menu "+ m +"] ")
     os.system("python CCTV.py")
elif pil =='11':
     os.system("xdg-open http://119.252.169.189:84/")
     ent = input (m +"["+ p +" Klik Enter Untuk kembali Ke Menu "+ m +"] ")
     os.system("python CCTV.py")
elif pil =='12':
     os.system("xdg-open http://103.119.145.26:8001/live/index.html?Language=0")
     ent = input (m +"["+ p +" Klik Enter Untuk kembali Ke Menu "+ m +"] ")
     os.system("python CCTV.py")
elif pil =='13':
     os.system("xdg-open http://36.91.83.73:8081/")
     ent = input (m +"["+ p +" Klik Enter Untuk kembali Ke Menu "+ m +"] ")
     os.system("python CCTV.py")
elif pil =='14':
     os.system("xdg-open http://119.252.169.189:85/")
     ent = input (m +"["+ p +" Klik Enter Untuk kembali Ke Menu "+ m +"] ")
     os.system("python CCTV.py")
elif pil =='15':
     os.system("xdg-open http://103.245.19.243/live/index.html?Language=0")
     ent = input (m +"["+ p +" Klik Enter Untuk kembali Ke Menu "+ m +"] ")
     os.system("python CCTV.py")
elif pil =='16':
    
     print (k +"➣"+ h +" http://103.4.206.135:83/ui3.htm ")
     time.sleep (1)
     print (k +"➣"+ h +" http://119.2.50.114:88/view/viewer_index.shtml?id=3941 ")
     time.sleep (1)
     print (k +"➣"+ h +"http://65.201.171.70/#view ")
     time.sleep (1)
     print (k +"➣"+ h +" http://205.189.36.99:8082/control/userimage.html ")
     time.sleep (1)
     print (k +"➣"+ h +" http://75.183.181.155/view/viewer_index.shtml?id=200 ")
     time.sleep (1)
     print (k +"➣"+ h +" http://12.34.170.21:8888/view/viewer_index.shtml?id=639 ")
     time.sleep (1)
     print (k +"➣"+ h +" http://128.104.206.15/view/viewer_index.shtml?id=131 ")
     time.sleep (1)
     print (k +"➣"+ h +" http://24.20.101.215:8000/view/viewer_index.shtml?id=44 ")
     time.sleep (1)
     print (k +"➣"+ h +" http://166.168.156.178:81/live/index.html?Language=0 ")
     time.sleep (1)
     print (k +"➣"+ h +" http://166.153.247.80:82/cgi-bin/guestimage.html ")
     time.sleep (1)
     print (k +"➣"+ h +" http://75.112.32.101/view/viewer_index.shtml?id=1185 ")
     time.sleep (1)
     print (k +"➣"+ h +" http://166.247.40.1:82/#view ")
     time.sleep (1)
     print (k +"➣"+ h +" http://67.204.149.29/control/userimage.html ")
     time.sleep (1)
     print (k +"➣"+ h +" http://74.51.217.90:82/view/viewer_index.shtml?id=1968 ")
     time.sleep (1)
     print (k +"➣"+ h +" http://96.237.61.111:81/live/index.html?Language=0 ")
     time.sleep (1)
     print (k +"➣"+ h +" http://50.248.29.158/view/viewer_index.shtml?id=1315 ")
     time.sleep (1)
     print (k +"➣"+ h +" http://152.26.8.85/view/index.shtml ")
     time.sleep (1)
     print (k +"➣"+ h +" http://202.73.139.110:81/live/index.html?Language=1&ViewMode=pull ")
     time.sleep (1)
     print (k +"➣"+ h +" http://58.93.199.162:50001/live/index.html?Language=1 ")
     time.sleep (100000)

else:
    print ("Pilih yg bener")
    time.sleep (2)
    os.system("python CCTV.py")
