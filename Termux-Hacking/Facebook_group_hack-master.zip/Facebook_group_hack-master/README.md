# Facebook_group_hack

# Note
Find me....for username and password

# Find me on 

Instagram account
👉[![Instagram  ](https://img.shields.io/badge/INSTAGRAM-FOLLOW-red?style=for-the-badge&logo=instagram)](https://www.instagram.com/shubhamg0sain)👈

### screenshot

![ ](https://github.com/ShuBhamg0sain/Facebook_group_hack/blob/master/IMG_20200917_074939.jpg)


### installation

 apt update

 apt upgrade

 pkg install python

 pkg install python2

 git clone https://github.com/ShuBhamg0sain/Facebook_group_hack

 cd Facebook_group_hack

 ls 

 python2 Group-hack.py 


