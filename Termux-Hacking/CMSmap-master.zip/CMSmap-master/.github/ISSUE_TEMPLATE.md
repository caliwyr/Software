## Issue Details
CMSmap Version:  
CMS Type:  
CMS Version:  
Plugin Name:  
OS Information:  

## Steps to reproduce the issue

Describe how to reproduce the issue

## Expected behaviour 

Describe how CMSmap should have handled the issue  
