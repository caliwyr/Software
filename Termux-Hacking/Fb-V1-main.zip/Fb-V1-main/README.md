## Fb-V1
```
pkg install git
pkg install update
pkg install nano
pkg install upgrade
pkg install python2
pip install requests
pip install mechanize
pip install bs4
git clone https://github.com/Aldi098/Fb-V1
cd Fb-V1
python2 Fb-brute_enc.py
```
## Fungsi
```
Hack akun fb
Hack menggunakan id/username
Hack menggunakan wordlist
Hack FB no login
```
