## base64
```
Ngga gueh enc asu buat kang ricod
```
## Script 
``` 
pip install Zlib

pip install base64

pip install requests

pip install mechanize

pkg install git

git clone https://github.com/Aldi098/base64

cd base64

python2 base.py
```
## Fungsi
```
> Buat kunci SC
> Base64
> No ricod
> Jangan ricod asu
```
## thank you
```
> Allah SWT
> Bapak
> ibu
> Kaka
> Teman²
```
SUBSCRIBE YT AING ASU MR.1557 🔰
```
