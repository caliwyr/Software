# DDosy

### Installation
```shell 
git clone https://github.com/Sanix-Darker/DDosy

cd DDosy

# Example
python3 ddosy.py -s target -t 300
```

### Usage
```shell
usage : python3 ddosy.py [-s] [-p] [-t]
-h : help
-s : server ip
-p : port default 80
-t : turbo default 135
```