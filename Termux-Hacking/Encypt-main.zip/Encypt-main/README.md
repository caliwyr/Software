## Encypt

```OPEN SOURCE CODE```

```Code By : MR.1557 Aldi Bachtiar rifai```

```Gc : Mafia teknologi Indonesia```

## How to install

```pkg install git```

```pkg install python```

```pkg install python2```

```pkg install nano```

```git clone https://github.com/Aldi098/Encypt```

```cd Encypt```

```py2 enc.py```

```py2 enc.py file.py```

```python2 enc.py file.py```

## Thank you

```Allah SWT```
```Ibu```
```Bapak```
```Kaka```
```Teman Teman```

## Sosial Media

[![](https://img.shields.io/badge/Github-black?logo=Github&logoColor=black&labelColor=white)](https://github.com/Aldi098)

[![](https://img.shields.io/badge/Youtube-red?logo=Youtube&logoColor=red&labelColor=white)](https://youtube.com/channel/UC7ygjAbDjuiN76PqOlJm40A)
