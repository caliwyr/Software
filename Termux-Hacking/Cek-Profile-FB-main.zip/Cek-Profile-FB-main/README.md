# Cek-Profile-FB

## Cek Profile Fb
```

📌 Login Token FB

```
## Fungsi Fungsi
```
📌 liat ID
📌 Tanggal lahir
📌 Lokasi
📌 Jenis kelamin
📌 Link Profile
```
## install
```

Pkg Install python

pkg install git

pip install requests

pip install bs4 

git clone https://github.com/Aldi098/Cek-Profile-FB

cd Cek-Profile-FB

python Cek-profile.py

```

