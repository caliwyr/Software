### WiFi_Profile_Mailer.ino
Use for Windows 7/8/8.1/Older Builds of Windows 10

### WiFi_Profile_Mailer_New.ino
Use for newer builds of Windows 10

### WiFi_Profile_Mailer_Update.ino
Use for newer builds of Windows 10 w/ debug mode & user variables
