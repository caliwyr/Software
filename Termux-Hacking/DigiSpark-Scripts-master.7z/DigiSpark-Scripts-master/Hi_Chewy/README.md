Hi Chewy opens a hidden powershell window, downloads a 60 second wav file of random Chewbacca from Star Wars clips, waits 5 minutes and then plays it.
