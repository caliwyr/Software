# DOS-Scripts
#Simple DDOS Script




SUBSCRIBE TO MY YOUTUBE CHANNEL: https://www.youtube.com/channel/UCKAmv8p_TRvUNrJlfiB8qBQ
