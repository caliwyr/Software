admin-panel-finder
==================

A Python Script to find admin panel of a site
